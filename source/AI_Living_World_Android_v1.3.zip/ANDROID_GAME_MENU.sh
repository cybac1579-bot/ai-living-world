#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")" || exit 2
if [[ "${PREFIX:-}" != *com.termux/files/usr* ]]; then
  echo "[STOP] This runs inside the Android Termux app only."
  exit 2
fi
while true; do
  echo ""
  echo "================ AI Living World v1.1 ================"
  echo "  1) Start story in Android browser (ChatGPT)"
  echo "  2) Sign in with ChatGPT on this phone"
  echo "  3) Offline interface preview (no GPT calls)"
  echo "  4) Export private demo save ZIP to Downloads"
  echo "  5) Environment check"
  echo "  0) Exit"
  read -r -p "Choose: " action
  case "$action" in
    1) python mobile_android.py play ;;
    2) python mobile_android.py login ;;
    3) python mobile_android.py offline ;;
    4) python mobile_android.py backup ;;
    5) python mobile_android.py doctor ;;
    0) exit 0 ;;
    *) echo "Choose a number 0-5." ;;
  esac
done
