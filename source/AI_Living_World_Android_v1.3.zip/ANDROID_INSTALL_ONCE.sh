#!/data/data/com.termux/files/usr/bin/bash
set -e
if [[ "${PREFIX:-}" != *com.termux/files/usr* ]]; then
  echo "[STOP] Install from the Termux Android app, not Windows/PC."
  exit 2
fi
echo "AI Living World Android Termux - one-time free dependencies"
echo "This installs free local packages. It does NOT request any paid API key."
pkg update -y
pkg install -y python python-cryptography unzip
if ! python -m pip --version >/dev/null 2>&1; then
  pkg install -y python-pip
fi
python -m pip install --no-deps 'PyJWT>=2.10,<3'
python - <<'CHECK'
import jwt, cryptography
print('[OK] OAuth Python dependencies available.')
CHECK
echo "[DONE] Run: bash ANDROID_GAME_MENU.sh"
