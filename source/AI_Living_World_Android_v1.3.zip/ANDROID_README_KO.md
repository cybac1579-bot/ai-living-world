# AI Living World v1.1 — 휴대폰 독립 실행 시험판 (Termux + Chrome)

**APK가 아니라 Android 휴대폰 안에서 직접 Python 세계 엔진을 구동하는 기술 시험판**이야. PC, 클라우드 서버, 유료 API 키 없이 동작하도록 구성했어. 실제 AI 요청에는 인터넷과 **휴대폰에서 직접 승인한 ChatGPT 계정**이 필요해. 기존 PC 로그인 토큰은 복사하지 않아.

## 휴대폰 최초 준비 (사용자 기기에서 아직 미검증)

1. [Termux 공식 F-Droid 배포](https://f-droid.org/packages/com.termux/)에서 설치해. 다른 출처의 Termux/플러그인 APK는 혼용하지 마.
2. 이 ZIP 파일을 Android의 **Downloads** 폴더로 다운로드해. 파일 관리자에서 코드를 실행하지 말고, 아래 명령으로 **Termux 개인 폴더에 압축 해제**해. (공용 Downloads 폴더에서 프로그램을 직접 실행하면 다른 앱이 코드를 수정할 위험이 있어.)
3. Termux를 열어 아래 명령을 순서대로 입력해. ZIP 파일 이름을 변경했다면 unzip 행만 실제 파일 이름으로 변경해.

   ```sh
   termux-setup-storage
   pkg install -y unzip
   mkdir -p ~/ai-living-world
   unzip -o ~/storage/downloads/AI_Living_World_Android_독립실행_시험판_v1.1.zip -d ~/ai-living-world
   cd ~/ai-living-world
   bash ANDROID_INSTALL_ONCE.sh
   bash ANDROID_GAME_MENU.sh
   ```

4. 메뉴 **2번**을 눌러 **휴대폰 자체에서** ChatGPT 로그인 및 플랜 사용량 공유 권한을 승인해. Chrome에서 승인 후 Termux로 돌아오면 완료됐는지 확인할 수 있어.
5. 메뉴 **1번**을 선택하면 기기 내부의 HTTP 서버(127.0.0.1:8765)를 실행하고 브라우저가 열려. Chrome이 자동 실행되지 않으면 같은 휴대폰 Chrome 주소창에 `http://127.0.0.1:8765/`를 입력해.
6. 장면을 터치하고 선택지/자유 입력으로 플레이해. 각 GPT 요청 직전에는 확인 창으로 승인받아. **종료는 Termux로 돌아와 Ctrl+C**를 눌러줘.

> 환경에 따라 최신 Termux의 Python/PyJWT 설치 방식이나 Android의 배터리 제한 때문에 앱이 중단될 수 있어. 설치와 실기기 로그인은 아직 사용자의 Galaxy S25+에서 검증하지 않았어. 문제가 생기면 다음 개발에서 대응할게.

## 개인 정보 / 저장

- 로그인 정보: Termux 비공개 홈 `~/.config/ai-living-world/siwc/`에 저장. 이 디렉터리와 `credentials.json`, 호스트 ID, 토큰은 **다른 곳에 복사/공유하지 마**.
- 세계 기록: Termux 비공개 홈 `~/.local/share/ai-living-world/demo-world/`에 저장. ZIP 배포물에 사용자 정보는 없어.
- 메뉴 **4번**을 눌러 게임 기록만 별도 ZIP으로 Downloads에 백업할 수 있어. 인증 토큰은 절대 포함하지 않아.
- 기존 PC에서 진행했던 데모 저장을 Android에 자동으로 가져오지 않아. 서로 다른 실험 세계로 시작하며 공식 레티시아 세계 기록은 바뀌지 않아.
- Android에서 기기 화면을 끄거나 Termux가 백그라운드 종료되면 서버가 중단될 수 있어. 브라우저에 보이는 화면이 자동 저장의 증거는 아니므로 `rev` 표시를 확인해. 확인 전 자동 재호출하지 않아.
- 휴대폰 브라우저나 다른 앱에 로컬 URL을 공유하지 마. 서버는 127.0.0.1로만 열리고 CSRF·Origin·모델·revision을 검증하지만, **같은 휴대폰의 악성 앱과 완전히 격리된 형태는 아니야**.

## 기능과 한계

- v1.0과 같은 대사 UI / 세계 엔진 / GPT 구독 사용량 공유 요청을 재사용.
- APK 설치, 홈 화면 아이콘 앱, 화면 잠금 후 백그라운드 동작 보장, 자동 Google Drive 동기화, Android Keystore 기반 토큰 저장, 실제 Galaxy S25+ 터치 검증은 아직 없음.
- 위 작업은 Android 전용 앱 개발로 옮겨갈 때 필요한 추가 과제야. 구독 공유 경로가 별도 유료 API로 전환되는 코드는 없어.
- 인증/호출이 실패하더라도 플랜 사용량은 소모될 수 있으므로 자동으로 재요청하지 않아.

## 개발자 검증

`python -m unittest discover -s tests -v`로 Python 세계 엔진과 Android 런처의 모의 테스트를 수행할 수 있어. Android 고유 실행 명령은 가짜 subprocess를 써서 테스트했으며 실제 Termux/Chromium 통합은 현재 검증 불가야.
