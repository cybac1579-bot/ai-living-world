# AI Living World v1.1 — Android 로컬 실행 구조 시제품

- **Android Termux + 브라우저 실행기** 추가: 휴대폰의 Python 서버가 127.0.0.1:8765만 바인딩하고 같은 휴대폰 Chrome에서 접속. 컴퓨터나 별도 클라우드 서버가 필요하지 않은 시험 구조.
- **별도 기기 OAuth**: `oauth_login`에 안전한 브라우저 열기 콜백 추가. 기기에서 직접 `termux-open-url`로 공식 SIWC 권한 승인; 사용자의 PC 토큰을 복사하지 않음.
- **기기 내부 세계 저장**: Android Termux 홈의 사용자 개인 폴더를 사용하고, 사건 저널만 Drive-safe ZIP으로 수동 내보내기 기능 추가. 인증 파일/토큰 불포함.
- **서버·화면 재활용**: v1.0 웹 UI, 세계 엔진 v0.9, 검증 로직을 그대로 사용. PC Windows 실행기도 계속 포함.
- **보안 제한**: 정해진 OAuth/127.0.0.1 URL 이외 브라우저 실행 거부, CSRF/Origin/Host/모델 허용 목록/턴 revision 검증 유지, 추론 실패 시 자동 재호출 금지, 유료 API 키 우회 없음.
- **검증**: 오프라인 Python unittest 212/212 PASS (v1.0 197 + Android 신규 15), 실제 루프백 HTTP 시뮬레이션 통과, shell syntax 검사 통과. Android Galaxy S25+ 기기에서 Termux 설치/OAuth/Chromium 실제 턴/백그라운드 동작은 **미검증**.
- **주의**: APK가 아니라 Termux를 이용한 Android 휴대폰 독립 실행 기술 시제품. 원래 v0.8 미연시 UI 디자인 동결 유지. 정식 레티시아 캐논과 Google Drive 사용자 세계 상태 불변.
