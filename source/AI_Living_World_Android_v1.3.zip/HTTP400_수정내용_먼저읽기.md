# ChatGPT 실제 연결 검사 v0.6.3 — HTTP 400 수정

기존 v0.6.2에서 로그인 및 모델 목록 조회 성공 뒤 모델 추론 요청 HTTP 400이 발생했어. OpenAI 공식 Sign in with ChatGPT의 Responses API 규칙은 `input`을 **메시지 배열**로 보내도록 요구하는데, v0.6.2는 문자열을 보냈어. 이번 버전은 `[ {"role":"user","content":"..."} ]` 형태로 수정했어. 이것이 정확한 원인인지는 실제 재시험 전까지는 확정할 수 없어.

공식 안내: https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations

이번 수정:
- 실제 모델 응답 요청의 input 필드를 공식 규격의 배열로 변경. store=false 및 stream=true 유지.
- HTTP 오류가 나면 HTTP 코드 외에 안전한 `error.code`, `error.param`, `x-request-id`만 출력. 서버 원문, 인증 정보, 프롬프트 본문은 출력하지 않음.
- 모델 목록에서 동일한 모델을 다시 선택해도 됨. 인증 파일이 정상 저장돼 있으면 로그인 화면을 반복하지 않아도 됨.
- 유료 API 키·유료 우회 경로 없음. API 사용량은 로그인 시 승인한 ChatGPT 플랜 허용량/크레딧에 따름.
- 통과 기준: 실제 GPT 응답 문장이 나오고 `live_model_response_completed`가 출력되어야 함.

## 실행

1. 이 v0.6.3 ZIP을 완전히 압축 해제해. 이전 폴더 안에 덮어쓰지 마.
2. 새 폴더에서 START_HERE_Windows.cmd를 실행해.
3. 모델 번호를 선택하고 실제 한 문장 응답 요청에 y를 눌러줘.
4. 실패하면 `검사 중단:` 뒤의 한 줄만 복사해서 알려줘. 비밀번호, 토큰, credentials.json, 인증코드 등은 공유하지 마.

이 도구는 독립 게임의 ChatGPT 구독 연결 기능만 확인하는 시험 프로그램이며, 정식 게임·세계 기록에 영향을 주지 않아.
