# AI Living World v1.2 — Android 앱 내부 Python 엔진 원형

**최신 상태: Android Studio 프로젝트 소스까지 구현. APK 파일은 아직 없어.**

- android_native/ : Android Gradle Plugin 9.5 + Chaquopy 17.2(Python 3.11) 소스 프로젝트, Java Activity/WebView, 앱 내부 Python 엔진, 앱 비공개 저장 디렉터리, 외부 시스템 브라우저 OAuth 연결 코드.
- 모바일 UI: 기존 v0.8 디자인에 맞춘 v1.0 미연시 화면을 내장. 서술/대사 분리, NPC 이름표/연한 파란색 대사창, 선택/직접 입력, 이미지 없는 상태의 정직한 표시 유지.
- localhost 인증: 이 Android 셸에서만 서버 부팅 세션 키를 임시 생성하고 HttpOnly/SameSite 쿠키로 장면/행동 API를 보호. PC/Termux 버전에는 API 호환성을 위해 적용하지 않음. 같은 기기 악성 앱 격리의 충분조건으로 단정하지 않음.
- 세계 상태: 기존 Python 엔진 검증 및 해시 연결 사건저널 보존. 앱 내 비공개 filesDir/saves/DEMO; 인증 파일은 filesDir/auth. 두 자료는 APK/정식 레티시아 세계에 포함되지 않음.
- 로그인: 별도 유료 API 키 없이 공식 Sign in with ChatGPT 시스템 브라우저 OAuth. 실제 Android 브라우저 콜백, 암호학 라이브러리 빌드, 유효 모델 목록/실 추론은 *아직 검증하지 않음*.
- 기존 v1.1 Termux 코드/검사도 포함하여 호환성 유지.

## 검증한 내용

**228 / 228 Python 자동 테스트 PASS** (v1.1의 212개 + 신규 16개). 오프라인 로컬 HTTP를 실제 열고 미인증 접근 차단/허용 쿠키 세션/서버 모드 전환/DEMO 저장 보호를 검사했다.
Java 소스는 Android API를 모사한 스텁으로 javac 문법 검사를 통과. AndroidManifest/network-security XML 파싱, JS node 구문 검사, Python AST 검사 PASS.

## 미검증 (완료로 간주 금지)

**Gradle Android SDK 실제 빌드, APK 생성/설치, Galaxy S25+ 시스템 브라우저 OAuth 로그인, 실제 모델 추론/세계 저장 및 장시간 앱 전환 생존은 아직 미검증.**
특히 Chaquopy의 PyJWT[crypto] -> cryptography Android wheel 가용성과 Android OS가 로그인 브라우저 전환 중 프로세스를 유지하는지 확인해야 한다.
배터리 백그라운드 서비스, Android Keystore 암호화, Google Drive 게임 진행 자동 동기화, 정식 레티시아 월드 연결은 아직 미구현.

### Android 빌드 경로

전체 ZIP에서 android_native/ 폴더를 Android Studio Gradle 프로젝트로 열면 돼. Android SDK 36, Gradle 도구 및 JDK 17+, 빌드 연결이 필요해. 다운로드 가능한 APK와 Gradle wrapper JAR는 제공하지 않았어.
지금은 사용자가 직접 설치하거나 PC 작업할 필요 없어. 실제 APK 빌드와 기기 검증 시점에 절차를 따로 안내할게.

상세: android_native/README_BUILD_KO.md · TEST_RESULTS_V12.json
