# AI Living World v1.3 — Android 디버그 APK 빌드 준비

이 버전은 v1.2 소스에 **Android CI 빌드 절차와 오프라인 사전 검증을 추가한 개발 후보**야. **APK가 만들어졌다고 주장하는 버전이 아니야.**

## 이번에 고친 것

1. Chaquopy 17.2.0 / AGP 9.5.0 / Gradle 9.6.0 일치 및 정적 검증.
2. Python 3.11 arm64-v8a 패키지 호환성에 맞춰 `PyJWT[crypto]==2.15.1`, `cryptography==42.0.8`, `cffi==1.17.1` 의존성을 고정. Chaquopy 저장소에서 해당 Android binary wheel의 존재를 웹에서 확인했지만 실제 빌드에 성공한 건 아니야. 이 cryptography 버전은 구형이므로 **배포용으로 전환하기 전에 보안 지원 상태와 대안 검토가 필수**야.
3. `.github/workflows/android-debug-build.yml` 추가: GitHub 저장소에 이 전체 소스를 올리면 Actions가 Python 테스트→Android SDK 설치→Gradle 빌드→APK 압축 내용 점검→디버그 APK 산출물 업로드를 수행하도록 작성.
4. `tools/android_build_preflight.py`: 번들 Python/웹 자산이 원본과 동일한지, OAuth 자격증명·사용자 저장이 제외됐는지, 앱·네트워크 설정이 안전한지 검사.
5. `tools/verify_debug_apk.py`: 빌드에서 생성된 실제 APK의 서명 여부가 아닌 ZIP 무결성·필수 에셋·ARM64 런타임 파일을 검사. 이는 실기기 작동 검증을 대체하지 않아.

## 개발자가 CI에 올릴 때

GitHub에서 별도의 AI Living World 비공개 저장소를 만들어 이 ZIP의 파일을 **저장소 최상위에** 배치하면 `main` 또는 `development` push 후 자동 빌드가 실행돼. (기존 네온 방치단이나 Pocket Pack Arena 저장소에 올리면 **다른 프로젝트가 오염**되므로 금지.) 업로드한 파일 가운데 `.github/workflows/android-debug-build.yml` 경로가 유지되어야 해. 또는 GitHub Actions에서 workflow_dispatch 수동 실행도 가능해.

실행 성공하면 GitHub Actions의 `AI-Living-World-debug-apk` 아티팩트에 `app-debug.apk`가 만들어져. 이 패키지는 개발용 디버그 인증서로 서명되고, **테스트 목적**이며 정식 배포용이 아니야.

현재 실행 환경은 Android SDK, Gradle 및 외부 패키지 다운로드가 차단돼 실제 빌드가 불가능했어. 따라서 GitHub Actions가 성공했다는 주장도 하지 않아.

## 검증 기록

`python tools/android_build_preflight.py --root .` → 사전 검증.
`python -m unittest discover -s tests -q` → 전체 엔진 회귀 테스트.

실제 폰에서 ChatGPT 로그인을 승인하고 모델 응답·세계 기록이 저장되는 단계는 **여전히 별도 검증 필요**. Android Keystore·백그라운드 지속 실행·Google Drive 자동 게임 저장은 구현하지 않았어.
