# Android v1.3 보안 주의사항

- **이 ZIP은 설치 가능한 APK가 아니라 빌드 후보 소스야.** Android 실기기에서 테스트한 것이 아니므로 아직 ChatGPT 계정 로그인을 진행하도록 권장하지 않아.
- Chaquopy Python 3.11 ARM64의 공식 저장소에서 사용 가능한 암호화 wheel이 `cryptography 42.0.8`이라서 오프라인 의존성/빌드 실험 목적으로 고정했어. 하지만 이 버전은 **기존 보안 권고사항의 영향을 받는 구버전**이고, 2026년 말 기준 정식 배포용으로 안전하다고 판단할 수 없어.
- OIDC 서명 검증을 생략하거나 무결성 확인을 건너뛰는 대체 경로는 추가하지 않았어. 보안 패치된 Android 호환 라이브러리를 확보하거나 Android의 검증된 시스템 암호화 API로 교체한 후, 로그인/토큰 처리를 실기기에서 재검증해야 해.
- GitHub Actions 워크플로는 디버그 APK만 산출하도록 설정했으며, 실사용자 배포·자동 게시나 릴리스 서명 작업은 하지 않아.
- ChatGPT 로그인 비밀번호, 토큰 파일(credentials.json), 호스트 ID를 다른 사람이나 GitHub 저장소에 업로드하면 안 돼.

근거: https://github.com/pyca/cryptography/security/advisories/GHSA-79v4-65xg-pq4g
Android wheel 현황: https://chaquo.com/pypi-13.1/cryptography/
