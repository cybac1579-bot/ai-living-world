@echo off
setlocal EnableExtensions DisableDelayedExpansion
title AI Living World - VN Story UI
set "LOG=%~dp0vn_diagnostics.txt"
echo.
echo ==================================================
echo AI Living World - VN Story UI v0.9
echo ==================================================
echo.
> "%LOG%" echo [START] Story Launcher v0.9

pushd "%~dp0" 2>nul
if errorlevel 1 goto folder_error

if not exist "vn_server.py" goto extract_error
if not exist "requirements.txt" goto extract_error

set "PY_EXE="
set "PY_ARGS="
where py >nul 2>&1
if errorlevel 1 goto try_python
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 goto try_python
set "PY_EXE=py"
set "PY_ARGS=-3"
goto found_python

:try_python
where python >nul 2>&1
if errorlevel 1 goto python_error
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 goto python_error
set "PY_EXE=python"
set "PY_ARGS="

:found_python
echo [1/4] Python detected.
%PY_EXE% %PY_ARGS% -c "import sys;print('Python '+sys.version.split()[0])"
>> "%LOG%" echo [OK] Compatible Python found.

if exist ".venv\Scripts\python.exe" goto have_venv
echo [2/4] Creating private Python environment...
%PY_EXE% %PY_ARGS% -m venv ".venv"
if errorlevel 1 goto venv_error
if not exist ".venv\Scripts\python.exe" goto venv_error
:have_venv
>> "%LOG%" echo [OK] Virtual environment exists.

echo [3/4] Installing free Python dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto pip_error
>> "%LOG%" echo [OK] Dependencies installed.

echo [4/4] Starting local visual novel interface...
echo IMPORTANT: Do not share passwords or login tokens.
echo.
".venv\Scripts\python.exe" -B vn_server.py
set "EXIT_CODE=%errorlevel%"
if "%EXIT_CODE%"=="0" goto success

echo.
echo [INFO] VN interface returned error or cancellation: %EXIT_CODE%
>> "%LOG%" echo [STOP] vn_server.py returned %EXIT_CODE%.
goto finish

:success
echo.
echo [OK] VN interface finished normally.
>> "%LOG%" echo [OK] vn_server.py finished normally.
goto finish

:folder_error
echo [ERROR] Cannot open program directory.
>> "%LOG%" echo [ERROR] Cannot open program directory.
goto finish

:extract_error
echo [ERROR] Missing program files.
echo Extract ALL files from the ZIP into a normal folder first.
echo Do not run this file directly inside the ZIP preview.
>> "%LOG%" echo [ERROR] Program files missing. ZIP extraction may be incomplete.
goto finish

:python_error
echo [ERROR] Python 3.10 or newer was not found.
echo Install Python from: https://www.python.org/downloads/windows/
echo Then close and run this launcher again.
>> "%LOG%" echo [ERROR] No Python 3.10+ found via py -3 or python.
goto finish

:venv_error
echo [ERROR] Could not create the private Python environment.
echo Check folder write permissions or install Python with venv support.
>> "%LOG%" echo [ERROR] Virtual environment creation failed.
goto finish

:pip_error
echo [ERROR] Dependency installation failed.
echo Check your internet connection and read the error shown above.
>> "%LOG%" echo [ERROR] Dependency installation failed.
goto finish

:finish
echo.
echo ------------------------------
echo The window will remain open.
echo Diagnostic file: vn_diagnostics.txt
echo Share only the ERROR line, never passwords or tokens.
echo Press any key to close this window.
pause >nul
endlocal
exit /b 0
