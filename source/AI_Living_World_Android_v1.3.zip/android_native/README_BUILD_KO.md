# AI Living World v1.2 — 네이티브 Android 앱 소스 (APK 아님)

## 무엇을 구현했나

- 기존 Python 세계엔진, 검증된 선택지/자유입력 서버, 모바일 VN HTML/CSS/JS를 **APK 안에 포함하도록 구성한 Android Studio 프로젝트**다.
- Java 네이티브 셸에 **화면 시험 / 로그인 / GPT 플레이** 버튼과 WebView, Chaquopy Python 엔진 연결을 작성했다.
- Termux 없이 앱 내부 Python 런타임을 실행하도록 설계했다. Python 엔진은 임의 포트 127.0.0.1에만 바인딩된다.
- 브라우저·WebView에 API 토큰을 전달하지 않는다. OAuth는 외부 시스템 브라우저에서만 승인한다. 앱 데이터는 비공개 filesDir에 저장한다.
- GPT 사용은 게임 UI의 매 요청 동의가 있어야 한다. 별도 유료 API 키/우회 없음.

## 현재 확실하게 검증한 범위

- Python 환경에서 임베디드 서버 시작→오프라인 HTML/API 조회→저널 저장/복원 및 중복 실행 제어 테스트를 통과했다.
- AndroidManifest.xml, Gradle 설정, Java WebView 셸 및 로컬 접근 제한은 정적 점검했다.
- **Android SDK/Gradle/실제 Android 기기가 이 빌드 환경에 없어 APK 컴파일·설치·OAuth 콜백·인앱 브라우저 연동은 아직 검증하지 못했다.**
- Chaquopy의 PyJWT[crypto] 종속 패키지 Android wheel 가용성은 실제 Android Studio 빌드에서 확인해야 한다.
- Android 버전/제조사별 외부 브라우저 로그인 후 Activity 생존, 백그라운드/화면 잠금은 보장하지 않는다. 별도 포그라운드 서비스 미구현.
- **이 프로젝트는 설치 가능한 APK 완성본이 아니라 APK 생성을 위한 소스이며, 빌드·실기기 검증 통과 전에는 사용자에게 설치를 권장하지 않는다.**

## 나중에 개발자가 빌드할 때

1. Android Studio에서 이 android_native 폴더를 Gradle 프로젝트로 연다.
2. JDK 17 이상, Android SDK 36과 Android Gradle Plugin 9.5, Chaquopy 17.2 호환성을 확인한다.
3. 필요한 Gradle distribution/wrapper가 프로젝트에 포함되어 있지 않다. Android Studio/Gradle 환경이 준비되어야 한다.
4. Chaquopy는 Python 3.11, 기기 arm64-v8a로 설정했다. `PyJWT[crypto]` 설치에서 Android용 cryptography wheel을 구할 수 없는 경우 앱 빌드는 중단된다. 검증을 건너뛰는 비보안 우회는 금지한다.
5. APK 서명/설치 뒤 오프라인→외부 브라우저 OAuth→실제 GPT 턴→저널 재시작 복원을 실기기 검증한다.

## 이후 필수 수정

- 로그인 브라우저 전환 중 Android 프로세스 종료/복귀 복구
- Android Keystore 자격증명 암호화 및 잠금 화면/앱 전환 대응
- Play/직접 배포의 서명·패키지/권한 검증
- 원거리 세계 사건/관측 UI, 실제 이미지 전환과 Google Drive 자동 게임 저장
- 사용자 공식 세계·레티시아 설정을 가져오기 전 검증 및 분리
