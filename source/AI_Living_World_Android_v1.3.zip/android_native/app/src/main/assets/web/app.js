/* Visual novel layer for a validated, server-owned world. No tokens in browser. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const preview = {
    world: {
      revision:0, region:{id:'DEMO-FOREST',name:'테스트 숲'},
      image:{id:'DEMO-IMG-FOREST',src:'assets/forest.jpg',kind:'region'},
      beats:[
        {kind:'narration',text:'오솔길에는 이른 햇빛이 길게 쏟아진다. 바람이 나뭇잎을 스칠 때마다 누군가 지도를 접는 소리가 들린다. 그러나 숲길은 멀리 갈수록 방향을 가늠하기 어려워 보인다.'},
        {kind:'dialogue',speaker:{id:'DEMO-GUIDE',name:'시험 안내인',name_color:'#345D91'},text:'야영지는 동쪽에 있어. 하지만 이 길은 최근에 달라졌어. 앞으로 어떻게 할지는 네가 정해.'}
      ],
      choices:[{id:'choice_move',label:'야영지로 이동한다'}, {id:'choice_stay',label:'잠시 숲에 남는다'}], awaiting_player:true,
    }, models:[],connected:false,csrf:null,mode:'DEMO'
  };
  let app = preview;
  let pages = [], currentPage = 0, sheet = '', sending = false, messageTimeout = null;

  function notify(text) {
    $('message').textContent = text;
    $('message').hidden = false;
    clearTimeout(messageTimeout);
    messageTimeout = setTimeout(() => { $('message').hidden = true; }, 4900);
  }
  function splitText(text, maxLen=210) {
    // Split long model text into short readable VN pages. Never omit text.
    const paragraphs = String(text).split(/\n+/);
    const out = [];
    for (const para of paragraphs) {
      const sentences = para.match(/[^.!?。！？]+[.!?。！？]*\s*/g) || [para];
      let acc = '';
      for (const sent of sentences) {
        if (acc && acc.length + sent.length > maxLen) {
          out.push(acc.trim()); acc = '';
        }
        if (sent.length <= maxLen) { acc += sent; continue; }
        const pieces = sent.match(new RegExp('.{1,'+maxLen+'}', 'gs')) || [];
        for (const part of pieces) {
          if (acc) { out.push(acc.trim()); acc = ''; }
          out.push(part.trim());
        }
      }
      if (acc.trim()) out.push(acc.trim());
    }
    return out.length ? out : ['…'];
  }
  function makePages(beats) {
    const result=[];
    for (const b of beats || []) {
      if (b.kind !== 'narration' && b.kind !== 'dialogue') continue;
      for (const chunk of splitText(b.text, 195)) result.push({...b,text:chunk});
    }
    return result.length ? result : [{kind:'narration',text:'표시할 장면이 없어.'}];
  }
  function styleSpeaker(speaker) {
    $('speaker-flag').hidden = !speaker;
    if (!speaker) return;
    $('speaker-flag').textContent = String(speaker.name || '인물');
    const color=String(speaker.name_color || '#345D91');
    // Name colors are an engine-owned character attribute, not model-provided HTML.
    $('speaker-flag').style.color = /^#[0-9a-fA-F]{6}$/.test(color) ? color : '#345D91';
  }
  function renderPage() {
    const p=pages[currentPage];
    const dialogue=p.kind === 'dialogue';
    $('panel').classList.toggle('dialogue-panel',dialogue);
    $('panel').classList.toggle('narration-panel',!dialogue);
    styleSpeaker(dialogue ? p.speaker : null);
    $('story-content').textContent=p.text;
    $('panel').scrollTop=0;
    $('page-progress').textContent=`${currentPage+1} / ${pages.length}`;
    const done=currentPage === pages.length-1;
    $('story-hint').textContent=done ? '행동을 선택하거나 직접 입력해' : '대화창을 눌러 계속 읽기';
    $('next-mark').textContent=done?'•':'⌄';
  }
  function renderScene(newData) {
    app=newData;
    pages=makePages(app.world.beats);
    currentPage=0;
    $('place').textContent=app.world.region.name;
    $('rev').textContent=`rev ${app.world.revision}`;
    $('model-tag').textContent=app.connected?'ChatGPT 연결됨':'오프라인 미리보기';
    const asset=app.world.image;
    const src=(asset && typeof asset.src==='string')?asset.src:null;
    $('background').classList.toggle('no-image',!src);
    if (src) $('background').style.backgroundImage=`url(${JSON.stringify(src)})`;
    else $('background').style.backgroundImage='';
    $('missing-art').hidden=!!src;
    $('missing-place').textContent=app.world.region.name;
    const previouslySelected=$('model-select').value;
    $('model-select').replaceChildren();
    for (const model of (app.models || [])) {
      const el=document.createElement('option');el.value=model.slug;el.textContent=model.name||model.slug;
      $('model-select').append(el);
    }
    if (!app.connected) {
      const el=document.createElement('option');el.textContent='미리보기 · AI 요청 불가';el.value='';
      $('model-select').append(el);
      $('model-select').disabled=true;
    } else { $('model-select').disabled=false;
      if ((app.models||[]).some(m=>m.slug===previouslySelected)) $('model-select').value=previouslySelected;
    }
    setSheet('');renderPage();
  }
  function advance() { if (sending || sheet) return; if (currentPage<pages.length-1) { currentPage++; renderPage(); } else { setSheet('choices'); } }
  function setSheet(next) {
    sheet=next;
    $('action-sheet').hidden=!next;
    $('choices-toggle').setAttribute('aria-expanded',next==='choices');
    $('free-toggle').setAttribute('aria-expanded',next==='free');
    if (!next) return;
    const isFree=next==='free';
    $('sheet-title').textContent=isFree?'직접 행동하기':'행동 선택하기';
    $('choices').hidden=isFree;
    $('free-form').hidden=!isFree;
    $('sheet-notice').textContent=app.connected?'실제 GPT 요청은 확인 후 1회만 전송해.':'오프라인 화면 미리보기야. AI 요청은 비활성화됐어.';
    if (!isFree) renderChoices();
  }
  function renderChoices() {
    $('choices').replaceChildren();
    for (const c of app.world.choices||[]) {
      const btn=document.createElement('button');btn.type='button';btn.textContent=c.label;
      btn.disabled=sending||!app.connected;
      btn.addEventListener('click',()=>sendTurn({choice_id:c.id}));
      $('choices').append(btn);
    }
    if (!(app.world.choices||[]).length) {
      const p=document.createElement('p');p.textContent='현재 제안된 선택지는 없어. 직접 입력해줘.';$('choices').append(p);
    }
  }
  async function sendTurn(submission) {
    if (sending) return;
    if (!app.connected) {notify('이 화면은 미리보기야. 앱에서 로그인한 다음 GPT 플레이를 눌러줘.');return;}
    const model=$('model-select').value;
    if (!model) {notify('GPT 모델을 선택해줘.');return;}
    if (!window.confirm('ChatGPT 플랜 사용량으로 이 행동을 1회 요청할까?\n실패해도 사용량이 소모될 수 있어.')) return;
    sending=true;
    $('busy').hidden=false;setSheet('');
    try {
      const response=await fetch('/api/turn',{
        method:'POST',headers:{'Content-Type':'application/json','X-ALW-CSRF':app.csrf},
        body:JSON.stringify({revision:app.world.revision,model,submission,approve:true})
      });
      const result=await response.json();
      if (!response.ok) throw new Error(result.error||'서버 응답 오류');
      renderScene(result);
      $('free-input').value='';
    } catch(err) {
      notify('세계 기록은 재확인해줘: '+String(err.message||err));
      // Network interruption after a commit is ambiguous; reload instead of retrying.
      try {const res=await fetch('/api/state',{cache:'no-store'});if(res.ok)renderScene(await res.json());}catch(_e){}
    } finally { sending=false;$('busy').hidden=true; }
  }
  $('panel').addEventListener('click',advance);
  $('choices-toggle').addEventListener('click',()=>setSheet(sheet==='choices'?'':'choices'));
  $('free-toggle').addEventListener('click',()=>setSheet(sheet==='free'?'':'free'));
  $('close-sheet').addEventListener('click',()=>setSheet(''));
  $('free-form').addEventListener('submit',e=>{e.preventDefault();let text=$('free-input').value.trim();if(!text)return;if(text.length>1000){notify('입력이 너무 길어.');return;}sendTurn({free_text:text});});
  renderScene(preview);
  fetch('/api/state',{cache:'no-store'})
    .then(res=>{if(!res.ok)throw Error('offline');return res.json();})
    .then(renderScene)
    .catch(()=>{renderScene(preview);notify('세계 엔진과 연결되지 않았어. 화면 시험 버튼으로 다시 열어줘.');});
})();
