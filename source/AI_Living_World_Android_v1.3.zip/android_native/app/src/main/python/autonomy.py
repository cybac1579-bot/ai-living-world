"""Deterministic NPC route scheduler. No network, no hidden clock, no player decisions.

Only an explicitly called EventStore.advance_time() advances time. NPC plans
are recorded as events, and deterministic route steps are replayed from the
journal, so the same history always reconstructs the same world.
"""
from __future__ import annotations


def public_recent_events(state: dict, location: str, limit: int = 8) -> list[dict]:
    """Only nearby, observable events; never reveal offscreen NPC activity."""
    now = state.get("world_minutes", 0)
    return [dict(x) for x in state.get("world_events", [])
            if x.get("region") == location and now - x["minute"] <= 120][-limit:]


def advance_clock(state: dict, minutes: int) -> None:
    """In-place deterministic scheduler. The caller must already validate the state.

    A small fixed-time horizon and finite plan lengths bound the computation.
    Route steps from all NPCs are processed in due-time / NPC-ID order.
    """
    if type(minutes) is not int or not 1 <= minutes <= 1440:
        raise ValueError("invalid clock advance")
    now = state.get("world_minutes", 0)
    target = now + minutes
    events = state.setdefault("world_events", [])

    while True:
        ready = []
        for npc_id, npc in state["npcs"].items():
            plan = npc.get("autonomy")
            if plan and plan["next_at"] <= target:
                ready.append((plan["next_at"], npc_id))
        if not ready:
            break
        due, npc_id = min(ready)
        npc = state["npcs"][npc_id]
        plan = npc["autonomy"]
        old = npc["location"]
        destination = plan["path"][plan["step"]]
        # A deterministic fail-closed check, even if the state was corrupted.
        if destination not in state["regions"][old].get("neighbors", []):
            raise ValueError("NPC planned a disconnected move")
        npc["location"] = destination
        plan["step"] += 1
        plan["next_at"] = due + plan["interval_minutes"]
        events.append({"minute": due, "type": "npc_arrival", "npc_id": npc_id,
                       "region": destination, "from_region": old})
        if plan["step"] >= len(plan["path"]):
            goal_id = plan["goal_id"]
            for goal in npc.get("goals", []):
                if goal["id"] == goal_id:
                    goal["status"] = "completed"
                    break
            npc["autonomy"] = None
            events.append({"minute": due, "type": "npc_goal_completed", "npc_id": npc_id,
                           "region": destination, "goal_id": goal_id})
        if len(events) > 60:
            del events[:-60]
    state["world_minutes"] = target
