"""First live ChatGPT-plan inference check for AI Living World.
No API key. Does not change official game state. Credentials stay on this PC.
"""
from __future__ import annotations
import json
import re
import os
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request

from siwc_client import (
    SIWCError, SCOPE_REQUIRED, oauth_login, read_credentials,
    refresh_credentials, list_models, collect_response_events,
)

CREDENTIALS_DIR = Path.home() / '.config' / 'ai-living-world' / 'siwc'

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        raise SIWCError('예상하지 못한 응답 경로 변경. 요청을 중단했어.')

# Read only structured error code/param and request ID; NEVER print server messages,
# authorization headers or response bodies (which may contain sensitive content).
_SAFE_CODES = frozenset({
    'subscription_sharing_unsupported_capability', 'subscription_sharing_usage_limit_exceeded',
    'subscription_sharing_usage_unavailable', 'subscription_sharing_route_not_supported',
    'subscription_sharing_invalid_user', 'chatpass_v2_scope_not_authorized',
    'chatpass_v2_invalid_authorization_context', 'invalid_request_error',
    'invalid_parameter', 'invalid_model', 'model_not_found', 'invalid_value',
    'missing_required_parameter', 'unsupported_value', 'invalid_json',
})
_SAFE_PARAMS = frozenset({
    'input', 'model', 'instructions', 'store', 'stream', 'tools', 'tool_choice',
    'service_tier', 'reasoning', 'text', 'response_format', 'max_output_tokens',
    'temperature', 'top_p', 'conversation', 'background', 'previous_response_id',
})

def _safe_http_error(error: urllib.error.HTTPError) -> str:
    status = error.code if isinstance(error.code, int) else 'unknown'
    detail = [f'HTTP {status}']
    try:
        raw = error.read(8192)  # only for extracting structured error metadata
        parsed = json.loads(raw)
        info = parsed.get('error') if isinstance(parsed, dict) else None
        if isinstance(info, dict):
            code = info.get('code')
            param = info.get('param')
            if isinstance(code, str) and code in _SAFE_CODES:
                detail.append('code=' + code)
            if isinstance(param, str) and param in _SAFE_PARAMS:
                detail.append('param=' + param)
    except (ValueError, TypeError, OSError, UnicodeDecodeError):
        pass
    try:
        request_id = error.headers.get('x-request-id', '') if error.headers else ''
        if isinstance(request_id, str) and re.fullmatch(r'req_[a-zA-Z0-9_-]{1,70}', request_id):
            detail.append('request_id=' + request_id)
    except (AttributeError, TypeError):
        pass
    return ', '.join(detail)

def send_probe(access_token: str, model_slug: str, *, urlopen=None) -> str:
    """One user-confirmed call via OAuth token; no API key/billing fallback."""
    if not access_token or not isinstance(access_token, str):
        raise SIWCError('로그인 권한이 없어 요청을 중단했어.')
    if not model_slug or not isinstance(model_slug, str):
        raise SIWCError('모델 선택이 없어 요청을 중단했어.')
    payload = {
        'model': model_slug,
        'instructions': '연결 확인용 테스트야. 한국어로 한 문장으로 간결하게 대답해.',
        'input': [{'role': 'user', 'content': 'AI Living World 연결 확인. 안녕! 게임을 시작할 준비가 됐는지 한 문장으로 답해줘.'}],
        'store': False,
        'stream': True,
    }
    req = urllib.request.Request(
        'https://api.openai.com/v1/responses',
        data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),
        headers={
            'Authorization': 'Bearer ' + access_token,
            'Content-Type': 'application/json',
            'Accept': 'text/event-stream',
        },
        method='POST',
    )
    opener = urlopen or urllib.request.build_opener(_NoRedirect()).open
    try:
        with opener(req, timeout=90) as response:
            result = collect_response_events(response)
            if not result.strip():
                raise SIWCError('응답 내용이 비어 있어.')
            return result
    except urllib.error.HTTPError as err:
        # Keep structured API error code/parameter/request ID; never expose raw body.
        safe_detail = _safe_http_error(err)
        if err.code == 429:
            raise SIWCError(f'ChatGPT 사용 한도 관련 오류 ({safe_detail}). 유료 API 전환 없음.') from None
        if err.code == 403:
            raise SIWCError(f'구독 사용량 연결 권한/경로 오류 ({safe_detail}). 유료 API 전환 없음.') from None
        if err.code == 401:
            raise SIWCError(f'로그인 권한 오류 ({safe_detail}). 유료 API 전환 없음.') from None
        raise SIWCError(f'AI 요청 거부 ({safe_detail}). 유료 API 전환 없음.') from None
    except urllib.error.URLError:
        raise SIWCError('네트워크 오류로 AI 요청을 완료하지 못했어.') from None

def choose_model(models: list[dict], prompt=input) -> str | None:
    valid = [x for x in models if isinstance(x,dict) and isinstance(x.get('slug'),str) and x['slug']]
    if not valid:
        raise SIWCError('로그인한 계정에서 선택 가능한 모델을 찾지 못했어.')
    print('\n[사용 가능한 모델]')
    for i, x in enumerate(valid, 1):
        print(f'  {i}. {x.get("display_name") or x["slug"]} ({x["slug"]})')
    while True:
        answer = prompt('테스트할 모델 번호 (취소: 0): ').strip()
        if answer == '0':
            return None
        try:
            n=int(answer)
        except ValueError:
            n=-1
        if 1<=n<=len(valid):
            return valid[n-1]['slug']
        print('표시된 번호 중에서 선택해줘.')

def connect_once(*, private_dir=CREDENTIALS_DIR, input_func=input, sign_in=None,
                 models_getter=None, sender=None, ask_login=True):
    private_dir = Path(private_dir)
    path = private_dir / 'credentials.json'
    sign_in = sign_in or oauth_login
    models_getter = models_getter or list_models
    sender = sender or send_probe
    print('\nAI Living World — 실제 ChatGPT 연결 검사 v0.6.3')
    print('유료 API 키를 받거나 사용하지 않아. 공식 ChatGPT 로그인 권한만 사용해.')
    print('연결 정보는 이 PC의 사용자 전용 폴더에 저장되며 이 채팅으로 전송되지 않아.\n')
    if not path.is_file():
        answer=input_func('브라우저를 열고 ChatGPT 로그인/권한 승인을 진행할까? (y/N): ').strip().lower()
        if answer not in ('y','yes'):
            return {'outcome':'cancelled_before_login'}
        auth=sign_in(private_dir)
        if not auth.get('plan_usage_permission'):
            raise SIWCError('ChatGPT 사용량 공유 권한이 승인되지 않았어.')
        print('로그인과 구독 사용량 공유 권한 확인 완료.')
    creds = read_credentials(path)
    if SCOPE_REQUIRED not in creds.get('scopes',[]):
        raise SIWCError('플랜 사용량 공유 권한이 없어 중단했어.')
    if creds.get('expires_at', 0) <= time.time()+60:
        creds=refresh_credentials(path, creds)
    models=models_getter(creds['access_token'])
    print('ChatGPT 플랜 사용량 사용 권한이 확인됐어.')
    slug=choose_model(models, input_func)
    if slug is None:
        return {'outcome':'authenticated_models_only', 'model_count':len(models)}
    confirm=input_func('선택한 모델로 한 문장만 실제 AI 요청할까? (y/N): ').strip().lower()
    if confirm not in ('y','yes'):
        return {'outcome':'cancelled_before_inference', 'selected_model':slug}
    result=sender(creds['access_token'],slug)
    print('\n===== 실제 GPT 응답 =====')
    print(result)
    print('========================\n')
    print('이 응답은 실제 모델에서 완료됐지만, 게임 세계 기록은 변경하지 않았어.')
    print('API 키/유료 과금 대체 경로는 이용하지 않았어.')
    return {'outcome':'live_model_response_completed', 'selected_model':slug, 'response_chars':len(result)}

def main():
    try:
        result=connect_once()
        print('결과:', result['outcome'])
        return 0 if result['outcome'] in ('live_model_response_completed','authenticated_models_only') else 1
    except (SIWCError, ValueError, OSError, TimeoutError) as ex:
        print('검사 중단:', str(ex))
        print('추가 유료 API 호출은 하지 않았어. 로그인 토큰이나 비밀번호를 채팅에 붙여넣지 마.')
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
