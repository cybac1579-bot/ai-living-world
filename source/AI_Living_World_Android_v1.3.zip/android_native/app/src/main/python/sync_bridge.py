"""Transport-independent export/import for Drive-safe, append-only game saves.

This module creates a portable ZIP, but does not silently connect to Google Drive.
Use the authorized Drive connector to upload/download the ZIP. On import, only
an exactly matching genesis and a byte-for-byte journal extension is accepted.
Divergent histories require explicit human reconciliation; never silently merge.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import zipfile
from world_engine import EventStore, WorldError, _canonical, _require, validate_state

FILES = ("initial_state.json", "events.jsonl", "manifest.json")
MAX_INITIAL = 4 * 1024 * 1024
MAX_JOURNAL = 20 * 1024 * 1024
MAX_MANIFEST = 32 * 1024
BUNDLE_VERSION = 1


def _sha(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _read_bundle(path: str | Path) -> tuple[dict, bytes, bytes, dict]:
    with zipfile.ZipFile(path, "r") as z:
        infolist = z.infolist()
        _require(len(infolist) == 3 and {i.filename for i in infolist} == set(FILES), "unexpected ZIP bundle members")
        _require(all(not i.is_dir() for i in infolist), "ZIP contains folder")
        max_size = {"initial_state.json": MAX_INITIAL, "events.jsonl": MAX_JOURNAL, "manifest.json": MAX_MANIFEST}
        for info in infolist:
            _require(info.file_size <= max_size[info.filename], "bundle entry too large")
        raw = {name: z.read(name) for name in FILES}
    try:
        manifest = json.loads(raw["manifest.json"].decode("utf-8"))
        initial = json.loads(raw["initial_state.json"].decode("utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise WorldError("invalid bundle JSON") from exc
    _require(isinstance(manifest, dict) and set(manifest) == {"format", "version", "world_id", "revision", "initial_sha256", "journal_sha256"}, "invalid bundle manifest")
    _require(manifest["format"] == "AI-LIVING-WORLD-JOURNAL" and manifest["version"] == BUNDLE_VERSION, "bundle format not supported")
    _require(manifest["initial_sha256"] == _sha(raw["initial_state.json"]), "initial checksum mismatch")
    _require(manifest["journal_sha256"] == _sha(raw["events.jsonl"]), "journal checksum mismatch")
    _require(type(manifest["revision"]) is int and manifest["revision"] >= 0, "invalid revision")
    validate_state(initial)
    _require(initial["revision"] == 0 and initial.get("world_id") == manifest["world_id"], "bundle world mismatch")
    # Recompute all journal transitions; digest alone is not enough.
    with tempfile.TemporaryDirectory(prefix="alw-bundle-verify-") as tmp:
        temp = EventStore(tmp)
        temp.initial.write_bytes(raw["initial_state.json"])
        temp.journal.write_bytes(raw["events.jsonl"])
        state = temp.load()
    _require(state["revision"] == manifest["revision"], "bundle revision mismatch")
    return manifest, raw["initial_state.json"], raw["events.jsonl"], state


def export_bundle(store: EventStore, path: str | Path) -> dict:
    """Consistent archive of the entire journal; safe during concurrent commit."""
    with store._lock():
        state = store._load_unlocked()
        initial, journal = store.initial.read_bytes(), store.journal.read_bytes()
    _require(len(initial) <= MAX_INITIAL and len(journal) <= MAX_JOURNAL, "save exceeds bundle limit")
    manifest = {"format": "AI-LIVING-WORLD-JOURNAL", "version": BUNDLE_VERSION,
                "world_id": state.get("world_id"), "revision": state["revision"],
                "initial_sha256": _sha(initial), "journal_sha256": _sha(journal)}
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, staged = tempfile.mkstemp(prefix=".alw-export-", suffix=".zip", dir=target.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(staged, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name, content in (("initial_state.json", initial), ("events.jsonl", journal),
                                  ("manifest.json", _canonical(manifest))):
                z.writestr(name, content)
        # Avoid publishing a ZIP that cannot restore the game.
        _read_bundle(staged)
        os.replace(staged, target)
    finally:
        if os.path.exists(staged): os.unlink(staged)
    return manifest


def inspect_bundle(path: str | Path) -> dict:
    manifest, _, _, _ = _read_bundle(path)
    return manifest


def apply_bundle(store: EventStore, path: str | Path) -> dict:
    """Restore new game or fast-forward matching game; refuse unrelated/divergent saves.

    This operation never overwrites a save whose journal differs, even when the
    incoming archive claims a larger revision. It is not a conflict merge.
    """
    manifest, initial, journal, new_state = _read_bundle(path)
    with store._lock():
        if store.initial.exists() != store.journal.exists():
            raise WorldError("incomplete local save; manual recovery required")
        if not store.initial.exists():
            # Journal is the source of truth. A crash before cache write can be recovered.
            _atomic_bytes(store.initial, initial)
            _atomic_bytes(store.journal, journal)
            store._atomic_json(store.cache, new_state)
            return {"status": "restored", "revision": new_state["revision"], "world_id": manifest["world_id"]}
        local_state = store._load_unlocked()
        _require(_sha(store.initial.read_bytes()) == manifest["initial_sha256"], "different genesis; refusing overwrite")
        existing_journal = store.journal.read_bytes()
        _require(journal.startswith(existing_journal), "divergent or older history; refusing overwrite")
        if len(existing_journal) == len(journal):
            return {"status": "unchanged", "revision": local_state["revision"], "world_id": manifest["world_id"]}
        _require(new_state["revision"] > local_state["revision"], "invalid future revision")
        _atomic_bytes(store.journal, journal)
        store._atomic_json(store.cache, new_state)
        return {"status": "fast_forward", "revision": new_state["revision"], "world_id": manifest["world_id"]}


def _atomic_bytes(path: Path, payload: bytes):
    fd, staged = tempfile.mkstemp(prefix=".alw-import-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush(); os.fsync(f.fileno())
        os.replace(staged, path)
    finally:
        if os.path.exists(staged): os.unlink(staged)
