"""AI Living World world-state engine v0.5 (stdlib only; no network/API calls).

The model MAY propose scenes and NPC/world events, but NEVER player actions.
Only actual player input can commit a player action. Illustrations are references,
not generated or modified by this engine.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import tempfile
import contextlib
if os.name == "nt":
    import msvcrt
else:
    import fcntl
import re
from pathlib import Path
from typing import Any

PALETTE = ["#345D91", "#9C3E36", "#7A46AD", "#17715D", "#A05520", "#A63D70", "#3F638A", "#286B80", "#72601A", "#8A4C64"]
ALLOWED_EVENTS = {"npc_move", "npc_learn", "npc_mood", "world_flag", "npc_remember", "npc_goal_set", "npc_goal_complete", "npc_plan_set", "npc_plan_cancel", "clue_discover", "clue_share"}
ALLOWED_IMAGE_TYPES = {"region", "character", "event"}
# Explicit first-/second-person commitments in narration may override player agency.
# This deliberately conservative guard cannot replace a semantic model review.
PLAYER_AGENCY_RE = re.compile(
    r"(?:당신|플레이어|주인공|너)(?:은|는|이|가)\s*[^.!?\n]{0,45}?"
    r"(?:도망쳤|공격했|결심했|선택했|사랑에 빠졌|두려움에 떨었|고개를 끄덕였|검을 뽑았|웃었다|울었다)"
)

SCHEMA_VERSION = 1

# Intentionally conservative: ONLY short, standalone, explicit travel commands
# are eligible for deterministic movement. A narrative sentence containing a
# place name must not silently move the player. No destination is inferred.
DIRECTION_TOKENS = frozenset({"동쪽", "서쪽", "남쪽", "북쪽", "북동쪽", "북서쪽", "남동쪽", "남서쪽", "동", "서", "남", "북"})
TRAVEL_COMMAND_RE = re.compile(
    r"^\s*(?P<target>[가-힣A-Za-z0-9_ -]{1,80}?)\s*(?:으로|로)\s*"
    r"(?:계속\s*)?(?:이동한다|이동해|이동하자|이동할게|가자|간다|가겠다|"
    r"가겠습니다|향한다|돌아간다|돌아가자|돌아가겠다)\s*[.!?]?\s*$"
)


def resolve_explicit_movement(state: dict, text: str) -> str | None:
    """Resolve only unequivocal player-authored travel text; never guess.

    None means no deterministic move (normal free-form turn). A standalone
    attempted move without a registered link raises before spending tokens.
    The engine re-checks the original text during journal replay.
    """
    if not isinstance(text, str):
        raise WorldError("invalid free text")
    match = TRAVEL_COMMAND_RE.fullmatch(text)
    if match is None:
        return None
    target = match.group("target").strip()
    here = state["player"]["location"]
    region = state["regions"][here]
    neighbors = region.get("neighbors", [])
    # Exact region names (or canonical IDs) are authoritative; never fuzzy match.
    named = [rid for rid, record in state["regions"].items()
             if target == record.get("name") or target == rid]
    exit_map = region.get("exits", {})
    if target in DIRECTION_TOKENS:
        if target not in exit_map:
            raise WorldError(f"'{target}' 방향으로 확인된 길이 없어. GPT 요청 없이 이동을 중단했어.")
        dest = exit_map[target]
    elif len(named) == 1:
        dest = named[0]
    elif len(named) > 1:
        raise WorldError("지역 이름이 중복돼 이동 목적지를 확정할 수 없어.")
    else:
        raise WorldError(f"'{target}' 목적지가 등록되지 않아. GPT 요청 없이 이동을 중단했어.")
    if dest not in neighbors:
        raise WorldError("선택한 목적지는 현재 지역과 연결되지 않아. GPT 요청 없이 이동을 중단했어.")
    return dest


SHARE_VERB_RE = re.compile(r"(?:알려준다|알려줘|알려주겠다|알려주자|전해준다|전한다|말해준다|말한다|설명한다|보여준다|공유한다)\s*[.!]?\s*$")
CLUE_STOPWORDS = {"신선한", "새로운", "오래된", "이상한", "수상한", "발견한", "확인한", "단서"}


def resolve_explicit_clue_share(state: dict, free_text: str) -> dict | None:
    """Identify an explicit player-authored transfer of one existing clue.

    This *never* writes knowledge by itself. It only authorizes a structured
    clue_share model event. Vague references are intentionally unrecognized.
    """
    if not isinstance(free_text, str) or not SHARE_VERB_RE.search(free_text):
        return None
    if re.search(r"(?:알려주지|말하지|전하지|보여주지|않는다|아니다)", free_text):
        return None
    here = state["player"]["location"]
    npc_candidates = []
    for npc_id, npc in state["npcs"].items():
        if npc["location"] != here:
            continue
        name = npc["name"]
        aliases = {name}
        if " " in name:
            aliases.add(name.split()[-1])
        if any(alias in free_text for alias in aliases if len(alias) >= 2):
            npc_candidates.append(npc_id)
    if len(npc_candidates) != 1:
        return None
    clues = []
    for clue in state.get("discoveries", []):
        tokens = re.findall(r"[가-힣A-Za-z0-9]{2,}", clue["title"])
        significant = [t for t in tokens if len(t) >= 3 and t not in CLUE_STOPWORDS]
        if any(t in free_text for t in significant) or clue["id"] in free_text:
            clues.append(clue["id"])
    if len(clues) != 1:
        return None
    return {"npc_id": npc_candidates[0], "clue_id": clues[0]}


class WorldError(ValueError):
    pass


def _canonical(x: Any) -> bytes:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _digest(x: Any) -> str:
    return hashlib.sha256(_canonical(x)).hexdigest()


def _require(cond: bool, message: str):
    if not cond:
        raise WorldError(message)


def _bounded(s: Any, label: str, maxlen: int = 4000) -> str:
    _require(isinstance(s, str) and 0 < len(s.strip()) <= maxlen, f"invalid {label}")
    return s.strip()


def validate_state(state: dict):
    _require(isinstance(state, dict), "state must be object")
    _require(state.get("schema_version") == SCHEMA_VERSION, "unknown schema version")
    _require(type(state.get("revision")) is int and state["revision"] >= 0, "invalid revision")
    for k in ("regions", "npcs", "images", "flags", "player", "scene"):
        _require(k in state, f"missing {k}")
    _require(isinstance(state["regions"], dict) and bool(state["regions"]), "regions missing")
    _require(isinstance(state["npcs"], dict) and isinstance(state["images"], dict), "bad registries")
    _require(isinstance(state["flags"], dict) and isinstance(state["player"], dict), "bad flags/player")
    _require(state["player"]["location"] in state["regions"], "unknown player location")
    _require(type(state.get("world_minutes", 0)) is int and state.get("world_minutes", 0) >= 0,
             "invalid world clock")
    evs = state.get("world_events", [])
    _require(isinstance(evs, list) and len(evs) <= 60, "invalid world events")
    for evt in evs:
        _require(isinstance(evt, dict) and evt.get("region") in state["regions"], "bad world event region")
        _require(type(evt.get("minute")) is int and 0 <= evt["minute"] <= state.get("world_minutes", 0), "bad event time")
        _require(evt.get("type") in ("npc_arrival", "npc_goal_completed") and evt.get("npc_id") in state["npcs"], "bad world event")
        if evt["type"] == "npc_arrival":
            _require(set(evt) == {"minute", "type", "npc_id", "region", "from_region"} and
                     evt["from_region"] in state["regions"], "bad arrival event fields")
        else:
            _require(set(evt) == {"minute", "type", "npc_id", "region", "goal_id"} and
                     isinstance(evt["goal_id"], str), "bad goal event fields")
    finds = state.get("discoveries", [])
    _require(isinstance(finds, list) and len(finds) <= 120, "invalid discoveries")
    find_ids = set()
    for finding in finds:
        _require(isinstance(finding, dict) and set(finding) == {"id", "region", "title", "detail", "revision"}, "invalid discovery")
        _bounded(finding["id"], "discovery id", 80)
        _bounded(finding["title"], "discovery title", 160)
        _bounded(finding["detail"], "discovery detail", 800)
        _require(finding["region"] in state["regions"], "invalid discovery region")
        _require(type(finding["revision"]) is int and 0 <= finding["revision"] <= state["revision"], "invalid discovery revision")
        _require(finding["id"] not in find_ids, "duplicate discovery")
        find_ids.add(finding["id"])
    history = state.get("player_action_history", [])
    _require(isinstance(history, list) and len(history) <= 20, "invalid action history")
    for item in history:
        _require(isinstance(item, dict) and set(item) == {"revision", "region", "text", "kind"}, "invalid action history entry")
        _require(type(item["revision"]) is int and 1 <= item["revision"] <= state["revision"], "invalid action history revision")
        _require(item["region"] in state["regions"] and item["kind"] in ("choice", "free_text"), "invalid action history location/kind")
        _bounded(item["text"], "action history text", 1000)
    for region_id, r in state["regions"].items():
        _require(r.get("id") == region_id, "invalid region id")
        neighbors = r.get("neighbors", [])
        _require(isinstance(neighbors, list) and len(neighbors) <= 40, "invalid region links")
        _require(all(isinstance(v, str) and v in state["regions"] and v != region_id for v in neighbors), "unknown neighbor")
        _require(len(neighbors) == len(set(neighbors)), "duplicate region links")
        exits = r.get("exits", {})
        _require(isinstance(exits, dict) and len(exits) <= 16, "invalid region exits")
        _require(all(k in DIRECTION_TOKENS and v in neighbors for k, v in exits.items()), "invalid directional exit")
    for npc_id, n in state["npcs"].items():
        _require(npc_id == n["id"] and n["location"] in state["regions"], "bad npc identity/location")
        _require(isinstance(n["knowledge"], list) and isinstance(n.get("mood"), str), "bad npc state")
        _require(n["name_color"] in PALETTE, "invalid name color")
        memories, goals = n.get("memories", []), n.get("goals", [])
        _require(isinstance(memories, list) and len(memories) <= 60, "invalid npc memories")
        _require(isinstance(goals, list) and len(goals) <= 30, "invalid npc goals")
        mem_ids, goal_ids = set(), set()
        for item in memories:
            _require(isinstance(item, dict) and set(item) == {"id", "text", "priority", "revision"}, "bad npc memory")
            _bounded(item["id"], "memory id", 80)
            _bounded(item["text"], "memory text", 600)
            _require(type(item["priority"]) is int and 1 <= item["priority"] <= 3, "bad memory priority")
            _require(type(item["revision"]) is int and 0 <= item["revision"] <= state["revision"], "bad memory revision")
            _require(item["id"] not in mem_ids, "duplicate memory id")
            mem_ids.add(item["id"])
        plan = n.get("autonomy")
        if plan is not None:
            _require(isinstance(plan, dict) and set(plan) == {"goal_id", "path", "step", "interval_minutes", "next_at"}, "bad NPC route plan")
            _require(any(g["id"] == plan["goal_id"] and g["status"] == "active" for g in goals), "route goal inactive")
            route = plan["path"]
            _require(isinstance(route, list) and 1 <= len(route) <= 12, "bad NPC path")
            _require(type(plan["step"]) is int and 0 <= plan["step"] < len(route), "invalid route step")
            _require(type(plan["interval_minutes"]) is int and 1 <= plan["interval_minutes"] <= 1440, "bad route interval")
            _require(type(plan["next_at"]) is int and plan["next_at"] > state.get("world_minutes", 0), "invalid due time")
            origin = n["location"]
            for destination in route[plan["step"]:]:
                _require(destination in state["regions"][origin].get("neighbors", []), "disconnected NPC route")
                origin = destination
        for item in goals:
            _require(isinstance(item, dict) and set(item) == {"id", "description", "status"}, "bad npc goal")
            _bounded(item["id"], "goal id", 80)
            _bounded(item["description"], "goal description", 300)
            _require(item["status"] in {"active", "completed"}, "bad goal status")
            _require(item["id"] not in goal_ids, "duplicate goal id")
            goal_ids.add(item["id"])
    for img_id, img in state["images"].items():
        _require(img_id == img["id"] and img["type"] in ALLOWED_IMAGE_TYPES, "bad image registry")
        _require(isinstance(img.get("src"), str) and bool(img["src"]), "bad image src")
    validate_scene(state["scene"], state)


def validate_scene(scene: dict, state: dict):
    _require(isinstance(scene, dict) and isinstance(scene.get("beats"), list) and bool(scene["beats"]), "invalid scene beats")
    _require(isinstance(scene.get("id"), str) and scene["id"], "invalid scene id")
    _require(len(scene["beats"]) <= 60, "too many scene beats")
    _require(set(scene) <= {"id", "beats", "choices", "awaiting_player", "event_image_id", "character_image_id"}, "unknown scene field")
    for beat in scene["beats"]:
        _require(set(beat) <= ({"kind", "text", "speaker_id"} if beat.get("kind") == "dialogue" else {"kind", "text"}), "unknown beat field")
        _require(isinstance(beat, dict) and beat.get("kind") in ("narration", "dialogue"), "bad beat kind")
        _bounded(beat.get("text"), "beat text", 3000)
        if beat["kind"] == "narration":
            _require(not PLAYER_AGENCY_RE.search(beat["text"]), "narration asserts unchosen player action/emotion")
        if beat["kind"] == "dialogue":
            _require(beat.get("speaker_id") in state["npcs"], "unknown/non-NPC speaker")
        else:
            _require("speaker_id" not in beat, "narration must not have speaker")
    choices = scene.get("choices", [])
    _require(isinstance(choices, list) and len(choices) <= 6, "invalid choices")
    seen = set()
    for choice_index, choice in enumerate(choices, 1):
        _require(isinstance(choice, dict), "choice must be object")
        _require(set(choice) <= {"id", "label", "effect"}, "unknown choice field")
        cid = _bounded(choice.get("id"), "choice id", 80)
        _bounded(choice.get("label"), "choice label", 200)
        _require(cid not in seen, "duplicate choice id")
        seen.add(cid)
        effect = choice.get("effect")
        if effect is not None:
            _require(isinstance(effect, dict) and effect.get("type") in ("player_move", "none"), f"invalid choice effect (choice {choice_index})")
            _require(set(effect) <= ({"type", "destination"} if effect["type"] == "player_move" else {"type"}), "unknown choice effect")
            if effect["type"] == "player_move":
                _require(effect.get("destination") in state["regions"], "unknown move destination")
    _require(isinstance(scene.get("awaiting_player"), bool), "awaiting_player missing")
    if choices:
        _require(scene["awaiting_player"], "choices require awaiting_player")
    if "event_image_id" in scene:
        _require(scene["event_image_id"] is None or isinstance(scene["event_image_id"], str), "bad event id")
    if "character_image_id" in scene:
        _require(scene["character_image_id"] is None or isinstance(scene["character_image_id"], str), "bad character image")


def select_image(state: dict) -> dict:
    """Priority: event > character > current region > unavailable (never fabricate)."""
    scene, images = state["scene"], state["images"]
    eid = scene.get("event_image_id")
    cid = scene.get("character_image_id")
    region = state["regions"][state["player"]["location"]]
    for kind, key in (("event", eid), ("character", cid), ("region", region.get("background_image_id"))):
        if key in images and images[key]["type"] == kind:
            return {"id": key, "src": images[key]["src"], "kind": kind, "fallback": kind == "region" and bool(eid or cid)}
    return {"id": None, "src": None, "kind": "missing", "fallback": False}


def render_contract(state: dict) -> dict:
    """UI-ready JSON without assuming a specific HTML layout."""
    validate_state(state)
    scene = state["scene"]
    from autonomy import public_recent_events
    return {
        "revision": state["revision"],
        "world_minutes": state.get("world_minutes", 0),
        "visible_world_events": public_recent_events(state, state["player"]["location"]),
        "scene_id": scene["id"],
        "region": {"id": state["player"]["location"], "name": state["regions"][state["player"]["location"]]["name"]},
        "image": select_image(state),
        "beats": [{"kind": b["kind"], "text": b["text"], **({"speaker": {"id": b["speaker_id"], "name": state["npcs"][b["speaker_id"]]["name"], "name_color": state["npcs"][b["speaker_id"]]["name_color"]}} if b["kind"] == "dialogue" else {})} for b in scene["beats"]],
        "choices": [{"id": c["id"], "label": c["label"]} for c in scene.get("choices", [])],
        "awaiting_player": scene["awaiting_player"],
        "free_text_allowed": True,
        "dialogue_background": "#EAF1FB",
        "discovered_clues": copy.deepcopy([f for f in state.get("discoveries", []) if f["region"] == state["player"]["location"]][-15:]),
    }


def validate_model_events(events: list, state: dict):
    _require(isinstance(events, list) and len(events) <= 20, "invalid event list")
    for event in events:
        _require(isinstance(event, dict) and event.get("type") in ALLOWED_EVENTS, "model attempted forbidden event")
        allowed_fields = {"npc_move": {"type", "npc_id", "destination"},
                          "npc_learn": {"type", "npc_id", "fact"},
                          "npc_mood": {"type", "npc_id", "mood"},
                          "npc_remember": {"type", "npc_id", "memory_id", "text", "priority"},
                          "npc_goal_set": {"type", "npc_id", "goal_id", "description"},
                          "npc_goal_complete": {"type", "npc_id", "goal_id"},
                          "npc_plan_set": {"type", "npc_id", "goal_id", "path", "interval_minutes"},
                          "npc_plan_cancel": {"type", "npc_id"},
                          "world_flag": {"type", "flag", "value"},
                          "clue_discover": {"type", "id", "region", "title", "detail"},
                          "clue_share": {"type", "npc_id", "clue_id"}}[event["type"]]
        _require(set(event) <= allowed_fields, "unknown model event field")
        typ = event["type"]
        if typ == "clue_discover":
            _require(set(event) == {"type", "id", "region", "title", "detail"}, "invalid clue fields")
            _bounded(event.get("id"), "clue id", 80)
            _bounded(event.get("title"), "clue title", 160)
            _bounded(event.get("detail"), "clue detail", 800)
            _require(not PLAYER_AGENCY_RE.search(event["title"] + " " + event["detail"]),
                     "clue asserts unchosen player action/emotion")
            _require(event.get("region") in state["regions"], "invalid clue region")
            _require(event["id"] not in {f["id"] for f in state.get("discoveries", [])}, "clue already discovered")
        if typ == "clue_share":
            _require(set(event) == {"type", "npc_id", "clue_id"}, "invalid clue share fields")
            _require(event.get("npc_id") in state["npcs"], "unknown clue recipient")
            _require(any(c["id"] == event.get("clue_id") for c in state.get("discoveries", [])),
                     "cannot share an undiscovered clue")
            marker = f"단서 [{event['clue_id']}]"
            _require(not any(isinstance(fact, str) and fact.startswith(marker + ":")
                             for fact in state["npcs"][event["npc_id"]]["knowledge"]),
                     "clue was already shared with this NPC")
        if typ.startswith("npc_"):
            _require(event.get("npc_id") in state["npcs"], "unknown npc")
        if typ == "npc_move":
            _require(event.get("destination") in state["regions"], "unknown npc destination")
        elif typ == "npc_learn":
            _bounded(event.get("fact"), "knowledge fact", 600)
        elif typ == "npc_mood":
            _bounded(event.get("mood"), "npc mood", 80)
        elif typ == "npc_remember":
            _bounded(event.get("memory_id"), "memory id", 80)
            _bounded(event.get("text"), "memory text", 600)
            _require(type(event.get("priority")) is int and event["priority"] in (1, 2, 3), "bad memory priority")
            _require(event["memory_id"] not in {m["id"] for m in state["npcs"][event["npc_id"]].get("memories", [])}, "memory id already exists")
        elif typ == "npc_goal_set":
            _bounded(event.get("goal_id"), "goal id", 80)
            _bounded(event.get("description"), "goal description", 300)
            _require(event["goal_id"] not in {g["id"] for g in state["npcs"][event["npc_id"]].get("goals", [])}, "goal id already exists")
        elif typ == "npc_plan_set":
            npc = state["npcs"][event["npc_id"]]
            _require(not npc.get("autonomy"), "NPC already has a plan")
            _bounded(event.get("goal_id"), "plan goal", 80)
            _require(any(g["id"] == event["goal_id"] and g["status"] == "active" for g in npc.get("goals", [])), "route goal is not active")
            route = event.get("path")
            _require(isinstance(route, list) and 1 <= len(route) <= 12, "route length invalid")
            current = npc["location"]
            for dest in route:
                _require(isinstance(dest, str) and dest in state["regions"][current].get("neighbors", []), "route not connected")
                current = dest
            interval = event.get("interval_minutes")
            _require(type(interval) is int and 1 <= interval <= 1440, "bad NPC route interval")
        elif typ == "npc_plan_cancel":
            _require(bool(state["npcs"][event["npc_id"]].get("autonomy")), "no active NPC plan")
        elif typ == "npc_goal_complete":
            _bounded(event.get("goal_id"), "goal id", 80)
            _require(any(g["id"] == event["goal_id"] and g["status"] == "active" for g in state["npcs"][event["npc_id"]].get("goals", [])), "unknown or completed goal")
        elif typ == "world_flag":
            _bounded(event.get("flag"), "flag", 80)
            _require(isinstance(event.get("value"), (str, bool, int, float)) and not isinstance(event.get("value"), (dict, list)), "invalid flag value")


def _apply_events(state: dict, events: list):
    for event in events:
        t = event["type"]
        if t == "npc_move":
            state["npcs"][event["npc_id"]]["location"] = event["destination"]
        elif t == "npc_learn":
            k = state["npcs"][event["npc_id"]]["knowledge"]
            if event["fact"] not in k:
                k.append(event["fact"])
        elif t == "clue_share":
            clue = next(f for f in state.get("discoveries", []) if f["id"] == event["clue_id"])
            statement = f"단서 [{clue['id']}]: {clue['title']} — {clue['detail']}"
            state["npcs"][event["npc_id"]]["knowledge"].append(statement)
        elif t == "npc_mood":
            state["npcs"][event["npc_id"]]["mood"] = event["mood"]
        elif t == "npc_remember":
            state["npcs"][event["npc_id"]].setdefault("memories", []).append({
                "id": event["memory_id"], "text": event["text"],
                "priority": event["priority"], "revision": state["revision"] + 1})
        elif t == "npc_goal_set":
            state["npcs"][event["npc_id"]].setdefault("goals", []).append({
                "id": event["goal_id"], "description": event["description"], "status": "active"})
        elif t == "npc_plan_set":
            npc = state["npcs"][event["npc_id"]]
            npc["autonomy"] = {"goal_id": event["goal_id"], "path": list(event["path"]),
                               "step": 0, "interval_minutes": event["interval_minutes"],
                               "next_at": state.get("world_minutes", 0) + event["interval_minutes"]}
        elif t == "npc_plan_cancel":
            state["npcs"][event["npc_id"]]["autonomy"] = None
        elif t == "npc_goal_complete":
            npc = state["npcs"][event["npc_id"]]
            if npc.get("autonomy") and npc["autonomy"]["goal_id"] == event["goal_id"]:
                npc["autonomy"] = None
            for goal in state["npcs"][event["npc_id"]].setdefault("goals", []):
                if goal["id"] == event["goal_id"]:
                    goal["status"] = "completed"
                    break
        elif t == "world_flag":
            state["flags"][event["flag"]] = event["value"]
        elif t == "clue_discover":
            state.setdefault("discoveries", []).append({
                "id": event["id"], "region": event["region"],
                "title": event["title"], "detail": event["detail"],
                "revision": state["revision"] + 1})


def transition(state: dict, submission: dict | None, model_output: dict, *, mode: str = "player") -> dict:
    """Apply a validated AI scene and deterministic player input.

    An NPC tick can happen autonomously, but it cannot replace a pending player decision.
    Player actions are NEVER accepted from model_output. Semantic intent fidelity of free
    text requires review by the model/UI, beyond static schema validation.
    """
    validate_state(state)
    _require(mode in ("player", "npc_tick", "world_tick"), "unknown mode")
    _require(isinstance(model_output, dict), "model output must be object")
    _require(set(model_output) <= {"scene", "events"}, "model supplied unauthorized top-level fields")
    _require("events" in model_output, "missing model events")
    events = model_output["events"]
    if mode == "world_tick":
        _require(submission is None and "scene" not in model_output, "world clock cannot decide a player action")
        _require(len(events) == 1 and isinstance(events[0], dict) and
                 set(events[0]) == {"type", "minutes"} and events[0]["type"] == "world_advance" and
                 type(events[0]["minutes"]) is int and 1 <= events[0]["minutes"] <= 1440,
                 "invalid world tick event")
    else:
        validate_model_events(events, state)
    result = copy.deepcopy(state)
    action_description = None
    action_kind = None

    if mode == "world_tick":
        from autonomy import advance_clock
        advance_clock(result, events[0]["minutes"])
    elif mode == "npc_tick":
        _require(submission is None, "NPC tick must not contain player input")
        _require(not (state["scene"]["awaiting_player"] and "scene" in model_output), "NPC tick cannot dismiss pending choice")
    else:
        _require(isinstance(submission, dict), "explicit player submission required")
        _require(set(submission) in ({"choice_id"}, {"free_text"}, {"free_text", "move_to"}), "submit one player action")
        if "choice_id" in submission:
            cid = _bounded(submission["choice_id"], "choice id", 80)
            choices = {c["id"]: c for c in state["scene"].get("choices", [])}
            _require(cid in choices, "unknown or stale choice")
            effect = choices[cid].get("effect") or {"type": "none"}
            if effect["type"] == "player_move":
                result["player"]["location"] = effect["destination"]
            action_description = choices[cid]["label"]
            action_kind = "choice"
            result["last_player_input"] = {"choice_id": cid, "text": action_description}
        else:
            _require(set(submission) in ({"free_text"}, {"free_text", "move_to"}), "invalid free text submission")
            free_text = _bounded(submission["free_text"], "free text", 1000)
            if "move_to" in submission:
                # New v0.8 app turns use the explicit deterministic marker.
                # Old v0.7.1 journals have free_text alone, even when it says
                # '동쪽으로 이동한다'. Preserve their historic NON-MOVEMENT effect.
                resolved = resolve_explicit_movement(state, free_text)
                _require(isinstance(submission["move_to"], str) and resolved == submission["move_to"],
                         "unapproved free text movement")
                result["player"]["location"] = submission["move_to"]
            action_description = free_text
            action_kind = "free_text"
            result["last_player_input"] = {"free_text": free_text}
        result.setdefault("player_action_history", []).append({
            "revision": state["revision"] + 1,
            "region": result["player"]["location"],
            "text": action_description, "kind": action_kind})
        result["player_action_history"] = result["player_action_history"][-20:]
        _require("scene" in model_output, "player turn requires follow-up scene")

    if mode != "world_tick":
        if mode == "player":
            shared = [e for e in events if e["type"] == "clue_share"]
            if shared:
                if set(submission) == {"free_text"}:
                    stated_action = submission["free_text"]
                elif set(submission) == {"choice_id"}:
                    matching = [c for c in state["scene"].get("choices", [])
                                if c["id"] == submission["choice_id"]]
                    _require(len(matching) == 1, "unknown clue-sharing choice")
                    stated_action = matching[0]["label"]
                else:
                    raise WorldError("clue sharing needs an explicit player action")
                authorized = resolve_explicit_clue_share(state, stated_action)
                _require(len(shared) == 1 and authorized is not None and
                         {"npc_id": shared[0]["npc_id"], "clue_id": shared[0]["clue_id"]} == authorized,
                         "unauthorized clue transfer")
                _require(state["npcs"][shared[0]["npc_id"]]["location"] == result["player"]["location"],
                         "clue recipient is not here")
            local_clue_ids = {f["id"] for f in result.get("discoveries", [])}
            for event in events:
                if event["type"] == "clue_discover":
                    _require(event["region"] == result["player"]["location"], "offscreen clue cannot be discovered")
                    _require(event["id"] not in local_clue_ids, "duplicate clue in turn")
                    local_clue_ids.add(event["id"])
        else:
            _require(all(event["type"] != "clue_discover" for event in events),
                     "NPC tick cannot commit player discovery")
            _require(all(event["type"] != "clue_share" for event in events),
                     "NPC tick cannot fake player clue sharing")
        _apply_events(result, events)
    if "scene" in model_output:
        validate_scene(model_output["scene"], result)
        result["scene"] = copy.deepcopy(model_output["scene"])
    result["revision"] += 1
    validate_state(result)
    return result


class EventStore:
    """Append-only hash-chained journal; state.json is an optional derived cache."""
    def __init__(self, directory: str | Path):
        self.dir = Path(directory)
        self.initial = self.dir / "initial_state.json"
        self.journal = self.dir / "events.jsonl"
        self.cache = self.dir / "state.json"
        self.lockfile = self.dir / ".world.lock"
        self.dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _atomic_json(path: Path, value: dict):
        fd, name = tempfile.mkstemp(prefix=".alw-", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(value, f, ensure_ascii=False, indent=2)
                f.flush(); os.fsync(f.fileno())
            os.replace(name, path)
        finally:
            if os.path.exists(name): os.unlink(name)

    @contextlib.contextmanager
    def _lock(self):
        """Serialize concurrent readers/writers on Linux/macOS test environments."""
        with self.lockfile.open("a+b") as fd:
            if os.name == "nt":
                fd.seek(0, os.SEEK_END)
                if fd.tell() == 0:
                    fd.write(b"0")
                    fd.flush()
                fd.seek(0)
                msvcrt.locking(fd.fileno(), msvcrt.LK_LOCK, 1)
            else:
                fcntl.flock(fd.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if os.name == "nt":
                    fd.seek(0)
                    msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(fd.fileno(), fcntl.LOCK_UN)

    def create(self, initial_state: dict):
        with self._lock():
            _require(not self.initial.exists() and not self.journal.exists(), "store already initialized")
            validate_state(initial_state)
            _require(initial_state["revision"] == 0, "initial revision must be zero")
            self._atomic_json(self.initial, initial_state)
            self.journal.touch(exist_ok=False)
            self._atomic_json(self.cache, initial_state)

    def load(self) -> dict:
        with self._lock():
            return self._load_unlocked()

    def _load_unlocked(self) -> dict:
        _require(self.initial.exists() and self.journal.exists(), "store not initialized")
        state = json.loads(self.initial.read_text(encoding="utf-8"))
        validate_state(state)
        previous_hash = _digest({"genesis": state})
        with self.journal.open(encoding="utf-8") as f:
            for rownum, line in enumerate(f, 1):
                try: item = json.loads(line)
                except json.JSONDecodeError as exc: raise WorldError(f"broken journal JSON line {rownum}") from exc
                _require(item.get("prev_hash") == previous_hash, f"broken hash chain at {rownum}")
                expected = _digest({k: v for k, v in item.items() if k != "hash"})
                _require(item.get("hash") == expected, f"tampered journal row {rownum}")
                _require(item.get("before_revision") == state["revision"], "nonsequential journal revision")
                # Transition is recomputed, rather than trusting a saved state_after.
                recalculated = transition(state, item.get("submission"), item["model_output"], mode=item["mode"])
                _require(recalculated["revision"] == item["after_revision"], "bad journal revision")
                state = recalculated
                previous_hash = item["hash"]
        return state

    def commit(self, expected_revision: int, submission: dict | None, model_output: dict, *, mode: str = "player") -> dict:
        with self._lock():
            return self._commit_unlocked(expected_revision, submission, model_output, mode=mode)

    def advance_time(self, expected_revision: int, minutes: int) -> dict:
        """Advance a bounded simulated clock only on explicit engine invocation.

        This is NOT a background scheduler. It does not advance on actual wall time
        while ChatGPT or the app is closed.
        """
        with self._lock():
            return self._commit_unlocked(expected_revision, None,
                                         {"events": [{"type": "world_advance", "minutes": minutes}]},
                                         mode="world_tick")

    def _commit_unlocked(self, expected_revision: int, submission: dict | None, model_output: dict, *, mode: str = "player") -> dict:
        state = self._load_unlocked()
        _require(type(expected_revision) is int and state["revision"] == expected_revision, "stale revision; reload current state")
        new_state = transition(state, submission, model_output, mode=mode)
        # Uses journal as source of truth. A failed cache write can be recovered by load().
        previous_hash = self._tail_hash(state)
        row = {"before_revision": expected_revision, "after_revision": new_state["revision"], "mode": mode,
               "submission": copy.deepcopy(submission), "model_output": copy.deepcopy(model_output), "prev_hash": previous_hash}
        row["hash"] = _digest(row)
        with self.journal.open("a", encoding="utf-8") as f:
            f.write(_canonical(row).decode("utf-8") + "\n")
            f.flush(); os.fsync(f.fileno())
        # The append-only journal is the source of truth.  The derived cache
        # must never turn an already committed turn into a false failure (e.g.
        # when an antivirus briefly locks state.json on Windows).
        try:
            self._atomic_json(self.cache, new_state)
        except OSError:
            pass
        return new_state

    def _tail_hash(self, state: dict) -> str:
        hash_ = _digest({"genesis": json.loads(self.initial.read_text(encoding="utf-8"))})
        with self.journal.open(encoding="utf-8") as f:
            for line in f:
                if line.strip(): hash_ = json.loads(line)["hash"]
        return hash_
