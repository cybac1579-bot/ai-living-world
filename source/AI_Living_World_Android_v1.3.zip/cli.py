"""Local-only AI Living World CLI: never calls ChatGPT or paid APIs."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from ai_adapter import apply_ai_turn, build_model_context
from world_engine import EventStore, WorldError, render_contract
from sync_bridge import export_bundle, inspect_bundle, apply_bundle

ROOT = Path(__file__).parent


def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def main():
    p = argparse.ArgumentParser(description="AI Living World local system-engine test")
    p.add_argument('command', choices=['init','view','choose','free','tick','export','context','apply-ai','backup','restore','inspect-backup','advance-time'])
    p.add_argument('--store', default=str(ROOT / 'demo_save'))
    p.add_argument('--choice')
    p.add_argument('--text')
    p.add_argument('--model', default=str(ROOT / 'examples/ai_scene_after_choice.json'))
    p.add_argument('--response-file', help='Full JSON response text from a model/client; no network call')
    p.add_argument('--expected', type=int, help='Optimistic revision for apply-ai; required for that command')
    p.add_argument('--minutes', type=int, help='Bounded virtual minutes (1..1440); only for advance-time')
    p.add_argument('--tick', action='store_true', help='Process an autonomous NPC tick with no player submission')
    p.add_argument('--output')
    p.add_argument('--archive', help='ZIP path for backup / restore / inspect-backup')
    args = p.parse_args()
    store = EventStore(args.store)
    submission = ({'choice_id':args.choice} if args.choice is not None else
                  {'free_text':args.text} if args.text is not None else None)
    try:
        if args.command in ('backup', 'restore', 'inspect-backup') and args.archive is None:
            p.error('--archive is required for backup/restore/inspect-backup')
        if args.command == 'backup':
            result = export_bundle(store, args.archive)
        elif args.command == 'restore':
            result = apply_bundle(store, args.archive)
        elif args.command == 'inspect-backup':
            result = inspect_bundle(args.archive)
        elif args.command == 'advance-time':
            if args.minutes is None:
                p.error('--minutes required for advance-time')
            current = store.load()
            result = render_contract(store.advance_time(current['revision'], args.minutes))
        elif args.command == 'init':
            store.create(read(ROOT / 'examples/test_world.json'))
            result = render_contract(store.load())
        elif args.command == 'view':
            result = render_contract(store.load())
        elif args.command == 'export':
            result = store.load()
        elif args.command == 'context':
            result = build_model_context(store.load(), submission=submission,
                                         mode='npc_tick' if args.tick else 'player')
        elif args.command == 'apply-ai':
            if args.expected is None or not args.response_file:
                p.error('--expected and --response-file are required with apply-ai')
            if not args.tick and submission is None:
                p.error('--choice or --text is required unless --tick')
            raw = Path(args.response_file).read_text(encoding='utf-8')
            result = apply_ai_turn(store, expected_revision=args.expected, submission=submission,
                                   ai_response=raw, mode='npc_tick' if args.tick else 'player')
        else:
            state = store.load()
            if args.command == 'choose' and args.choice is None:
                p.error('--choice is required for choose')
            if args.command == 'free' and args.text is None:
                p.error('--text is required for free')
            state = store.commit(state['revision'],
                                 submission if args.command != 'tick' else None,
                                 read(args.model), mode='npc_tick' if args.command == 'tick' else 'player')
            result = render_contract(state)
    except (WorldError, FileNotFoundError, ValueError) as exc:
        p.exit(2, f'검증 실패: {exc}\n')
    if args.output:
        Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
