#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null; then
  echo 'Python 3 설치가 필요해.'; exit 1
fi
if [ ! -f .venv/bin/python ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python connect_once.py
