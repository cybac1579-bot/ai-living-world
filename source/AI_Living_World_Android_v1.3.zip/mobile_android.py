"""Android-phone-only Termux runner. Experimental: not an APK.

Personal save and SIWC OAuth credentials remain inside Termux's private home.
The browser is only an unprivileged UI; actual access tokens stay in Python.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import subprocess
from urllib.parse import urlsplit

from live_story import authorized_catalog, initial_demo_store
from siwc_client import SIWCError, oauth_login
from sync_bridge import export_bundle
from vn_server import ROOT, SAMPLE, StoryBridge, LoopbackServer

VERSION = '1.1-termux-prototype'
PRIVATE_BASE = Path.home() / '.local' / 'share' / 'ai-living-world'
SAVE = PRIVATE_BASE / 'demo-world'
AUTH = Path.home() / '.config' / 'ai-living-world' / 'siwc'
DEFAULT_PORT = 8765


def is_termux(environ=None) -> bool:
    env = os.environ if environ is None else environ
    return '/com.termux/files/' in env.get('PREFIX', '') or '/com.termux/files/' in env.get('HOME', '')


def termux_browser_open(url: str, *, run=None, which=None) -> bool:
    """Open only known OAuth or on-device loopback URLs with Android browser.

    Never print the URL, OAuth code, callback state or other credentials.
    """
    parts = urlsplit(url)
    allowed_auth = (parts.scheme == 'https' and parts.netloc == 'auth.openai.com'
                    and parts.path == '/api/accounts/authorize')
    allowed_local = (parts.scheme == 'http' and parts.hostname == '127.0.0.1'
                     and parts.port in range(1024, 65536) and parts.path in ('/', '/auth/callback'))
    if not (allowed_auth or allowed_local) or parts.username or parts.password or parts.fragment:
        return False
    which = shutil.which if which is None else which
    if not which('termux-open-url'):
        return False
    run = subprocess.run if run is None else run
    try:
        result = run(['termux-open-url', url], check=False, timeout=15,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def private_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path, 0o700)


def save_export_path(downloads: Path, revision: int) -> Path:
    return downloads / f'AI_Living_World_DEMO_rev{revision}_save.zip'


def diagnostic() -> int:
    print('AI Living World Android phone prototype', VERSION)
    print('Termux:', 'detected' if is_termux() else 'not detected')
    print('Browser bridge:', 'available' if shutil.which('termux-open-url') else 'missing')
    try:
        import jwt
        import cryptography
        print('OAuth dependencies: installed')
    except ImportError:
        print('OAuth dependencies: missing (run ANDROID_INSTALL_ONCE.sh)')
    print('Credential file:', 'present' if (AUTH/'credentials.json').exists() else 'not present')
    print('Private save:', 'present' if (SAVE/'initial_state.json').exists() else 'not present')
    print('No credentials, keys, or token contents are printed.')
    return 0


def ensure_termux() -> bool:
    if is_termux():
        return True
    print('[중단] 이 실행기는 Android Termux 전용이야. PC에서는 START_VN_Windows.cmd를 사용해.')
    return False


def run_login(*, opener=termux_browser_open, login=oauth_login) -> int:
    if not ensure_termux():
        return 2
    if not shutil.which('termux-open-url') and opener is termux_browser_open:
        print('[중단] Termux 브라우저 연결 명령이 없어. Termux 설치를 확인해줘.')
        return 2
    print('휴대폰의 ChatGPT 계정으로 로그인과 구독 사용량 권한을 승인해줘.')
    print('PC 인증 파일이나 토큰을 휴대폰에 복사하지 마. 승인 정보는 Termux 비공개 폴더에만 저장돼.')
    try:
        result = login(AUTH, timeout=240, browser_open=opener)
        if not result.get('plan_usage_permission'):
            print('[중단] 플랜 사용량 공유 권한이 승인되지 않았어.')
            return 2
    except (SIWCError, OSError) as exc:
        # SIWCError is credential-free by design; no raw callback/URL printed.
        print('[인증 실패]', str(exc)[:180])
        return 2
    print('[성공] 이 Android 기기용 인증 승인 완료. 별도 API 키는 사용하지 않아.')
    return 0


def serve(*, offline: bool=False, port: int=DEFAULT_PORT, open_browser=termux_browser_open,
          offline_store=None) -> int:
    if not ensure_termux():
        return 2
    private_directory(PRIVATE_BASE)
    target = Path(offline_store) if offline_store is not None else SAVE
    if not offline and not (AUTH / 'credentials.json').exists():
        print('[인증 필요] 메뉴의 2번으로 먼저 이 Android 기기에서 ChatGPT 로그인을 승인해줘.')
        return 2
    if offline:
        token, models = None, []
    else:
        try:
            token, models = authorized_catalog(credentials_dir=AUTH)
        except (SIWCError, OSError) as exc:
            print('[인증 실패]', str(exc)[:180])
            print('유료 API로 자동 전환하지 않아. 메뉴에서 로그인 갱신을 선택해줘.')
            return 2
    store = initial_demo_store(target, sample_file=SAMPLE)
    bridge = StoryBridge(store,token=token,models=models)
    try:
        with LoopbackServer(('127.0.0.1',port), bridge) as server:
            addr = f'http://127.0.0.1:{server.server_port}/'
            print('AI Living World — 휴대폰 로컬 미연시 v1.1')
            print('이 Android 기기 내부 브라우저에서만 열려. 인터넷의 다른 사람에게 공개되지 않아.')
            print('로컬 접속 주소:', addr)
            print('종료하려면 Termux로 돌아와 Ctrl+C를 눌러줘. 화면 전환 시 앱이 종료될 수도 있어.')
            if not open_browser(addr):
                print('자동으로 브라우저를 열지 못했어. 같은 휴대폰 Chrome 주소창에 위 로컬 주소를 입력해줘.')
            try:
                server.serve_forever(poll_interval=0.2)
            except KeyboardInterrupt:
                print('서버를 종료했어. 게임 진행은 기기 내부 저장에 남아 있어.')
    except OSError:
        print('[중단] 로컬 포트를 열 수 없어. 기존 실행 중인 프로그램을 종료한 후 다시 해줘.')
        return 2
    return 0


def backup(*, downloads: Path | None=None, save: Path | None=None) -> int:
    if not ensure_termux(): return 2
    downloads = (Path.home()/'storage'/'downloads') if downloads is None else downloads
    save = SAVE if save is None else save
    if not (save/'initial_state.json').exists():
        print('[중단] 백업할 DEMO 저장이 없어.')
        return 2
    if not downloads.is_dir():
        print('[중단] Downloads 폴더 권한이 없어. Termux에서 termux-setup-storage를 먼저 실행해줘.')
        return 2
    from world_engine import EventStore
    try:
        store = EventStore(save)
        current_rev = store.load()['revision']
        path = save_export_path(downloads,current_rev)
        manifest = export_bundle(store,path)
    except (OSError, ValueError) as exc:
        print('[중단] 검증 가능한 저장 파일을 만들지 못했어:', type(exc).__name__)
        return 2
    print('백업 완료:', path)
    print('저장 rev',manifest['revision'])
    print('백업에는 게임 사건 기록만 포함하고 ChatGPT 계정 정보는 포함하지 않아.')
    return 0


def main(argv=None):
    parser=argparse.ArgumentParser(description='AI Living World Android Termux phone-only prototype')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('doctor')
    sub.add_parser('login')
    play=sub.add_parser('play');play.add_argument('--port',type=int,default=DEFAULT_PORT)
    demo=sub.add_parser('offline');demo.add_argument('--port',type=int,default=DEFAULT_PORT)
    sub.add_parser('backup')
    args=parser.parse_args(argv)
    if args.command=='doctor': return diagnostic()
    if args.command=='login': return run_login()
    if args.command=='play': return serve(port=args.port)
    if args.command=='offline': return serve(offline=True,port=args.port)
    if args.command=='backup': return backup()
    return 2

if __name__=='__main__':
    raise SystemExit(main())
