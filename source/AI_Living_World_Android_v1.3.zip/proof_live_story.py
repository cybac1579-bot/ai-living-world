"""Offline end-to-end run with the exact live interface but an injected fake sender."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from live_story import initial_demo_store, run_turn
from world_engine import render_contract

root=Path(__file__).resolve().parent
sample=root/'examples'/'live_demo_world.json'
reply={
 'events':[{'type':'npc_mood','npc_id':'DEMO-GUIDE','mood':'조심스러움'}],
 'scene':{'id':'DEMO-NEW-SCENE-1',
          'beats':[{'kind':'narration','text':'숲 위로 잔잔한 바람이 지나간다. 길 옆에 떨어진 표식은 누군가 최근 이곳을 지났다는 흔적이다.'},
                   {'kind':'dialogue','speaker_id':'DEMO-GUIDE','text':'저 표식은 보통 야영지로 가는 길에 남겨. 하지만 네가 원한다면 먼저 살펴봐도 좋아.'}],
          'choices':[{'id':'c1','label':'표식을 자세히 살핀다','effect':{'type':'none'}}],
          'event_image_id':None,'character_image_id':None,'awaiting_player':True}
}
with TemporaryDirectory() as temp:
    store=initial_demo_store(Path(temp)/'demo',sample_file=sample)
    before=store.load()
    out=run_turn(store,submission={'choice_id':'choice_stay'},token='offline-fake',model='test-model',
                 sender=lambda *args:json.dumps(reply,ensure_ascii=False))
    after=store.load()
    assert before['revision']==0 and after['revision']==1
    assert out['beats'][1]['speaker']['name']=='시험 안내인'
    assert after['npcs']['DEMO-GUIDE']['mood']=='조심스러움'
    assert after['player']['location']=='DEMO-FOREST'
    assert after['scene']['id']=='DEMO-NEW-SCENE-1'
    store.cache.unlink()
    restored=store.load()
    assert restored==after
    print(json.dumps({'offline_e2e_pass':True,'revision':after['revision'],
                      'npc_mood':after['npcs']['DEMO-GUIDE']['mood'],
                      'player_location_preserved':True,'journal_replay_identical':True,
                      'beats':len(out['beats']),'choices':len(out['choices']),
                      'real_model_called':False},ensure_ascii=False,indent=2))
