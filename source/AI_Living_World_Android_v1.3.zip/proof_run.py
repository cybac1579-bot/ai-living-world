"""Repeatable offline proof: autonomy -> journal -> bundle -> restore -> private contexts.
This proof uses invented DEMO locations and an invented NPC, never official canon.
"""
import json
import tempfile
from pathlib import Path
from ai_adapter import build_model_context
from sync_bridge import export_bundle, apply_bundle
from world_engine import EventStore, render_contract

ROOT=Path(__file__).resolve().parent
seed=json.loads((ROOT/'examples/test_world.json').read_text(encoding='utf-8'))
seed['world_id']='DEMO-AUTONOMY-V05-NONCANON'
seed['regions']['DEMO-FOREST']['neighbors']=['DEMO-CAMP']
seed['regions']['DEMO-CAMP']['neighbors']=['DEMO-FOREST']
# The player remains in the forest; an offscreen NPC follows a plan without
# choosing anything for the player.
seed['npcs']['DEMO-GUIDE']['location']='DEMO-CAMP'
with tempfile.TemporaryDirectory(prefix='alw-v05-proof-') as d:
    dest=Path(d)
    store=EventStore(dest/'world');store.create(seed)
    initial=store.load()
    a=store.commit(0,None,{'events':[{'type':'npc_goal_set','npc_id':'DEMO-GUIDE',
                                       'goal_id':'DEMO-GOAL-01','description':'숲 경계 관찰 후 귀환'}]},mode='npc_tick')
    a=store.commit(a['revision'],None,{'events':[{'type':'npc_plan_set','npc_id':'DEMO-GUIDE',
                                                  'goal_id':'DEMO-GOAL-01','path':['DEMO-FOREST','DEMO-CAMP'],
                                                  'interval_minutes':15}]},mode='npc_tick')
    a=store.advance_time(a['revision'],35)
    self_events=list(a['world_events'])
    archive=dest/'save.zip';export_bundle(store,archive)
    restored=EventStore(dest/'new');restore_result=apply_bundle(restored,archive)
    assert restored.load() == a
    assert a['player']==initial['player']
    assert a['scene']==initial['scene']
    assert a['npcs']['DEMO-GUIDE']['location']=='DEMO-CAMP'
    assert a['npcs']['DEMO-GUIDE']['goals'][0]['status']=='completed'
    assert a['world_minutes']==35
    visible=render_contract(a)['visible_world_events']
    assert all(e['region']=='DEMO-FOREST' for e in visible)
    context=build_model_context(a,submission={'choice_id':'choice_stay'})
    assert context['local_npcs']==[]
    assert all(e['region']=='DEMO-FOREST' for e in context['visible_world_events'])
    output={
       'name':'noncanon-autonomy-proof', 'before_revision':0, 'after_revision':a['revision'],
       'world_minutes':a['world_minutes'], 'player_untouched':a['player']==initial['player'],
       'pending_player_choice_preserved':a['scene']==initial['scene'],
       'npc_location_after':'DEMO-CAMP', 'npc_goal_after':'completed',
       'all_deterministic_events':self_events, 'visible_events_in_forest_only':visible,
       'model_context_offscreen_npcs_hidden':context['local_npcs']==[],
       'restored_state_identical':restored.load()==a, 'restore_status':restore_result['status']
    }
    (ROOT/'AUTONOMY_PROOF.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))
