"""Offline, deterministic 4-turn demo: not real GPT billing or official canon."""
import copy
import json
import tempfile
from pathlib import Path

from live_story import run_turn, initial_demo_store
from world_engine import EventStore, WorldError

ROOT = Path(__file__).resolve().parent


def scene(label, choices, *, dialogue=None, events=None, sid='DEMO-SCENE'):
    beats = [{'kind': 'narration', 'text': label}]
    if dialogue:
        beats.append({'kind': 'dialogue', 'speaker_id': 'DEMO-GUIDE', 'text': dialogue})
    return {'events': events or [], 'scene': {'id': sid, 'beats': beats, 'choices': choices,
             'awaiting_player': True, 'event_image_id': None, 'character_image_id': None}}


def choice(cid, label, effect=None):
    return {'id': cid, 'label': label, 'effect': effect or {'type': 'none'}}


def play():
    with tempfile.TemporaryDirectory() as tmp:
        store = initial_demo_store(Path(tmp), sample_file=ROOT / 'examples' / 'live_demo_world.json')
        trip = []
        camp_choices = [choice('inspect', '화덕 근처 발자국을 자세히 살핀다'),
                        choice('return', '테스트 숲으로 돌아간다', {'type': 'player_move', 'destination': 'DEMO-FOREST'})]
        turns = [
            ({'free_text': '동쪽으로 이동한다'}, scene('야영지에 도착했다. 재와 발자국이 남아 있다.', camp_choices, sid='DEMO-CAMP-ARRIVAL')),
            ({'choice_id': 'inspect'}, scene('그을음 아래 숲으로 향하는 신선한 발자국이 보인다.',
                    [choice('inspect', '발자국을 더 살핀다'), camp_choices[-1]],
                    events=[{'type': 'clue_discover', 'id': 'CLUE-CAMP-FOOTPRINT-01', 'region': 'DEMO-CAMP',
                             'title': '신선한 발자국', 'detail': '화덕 옆에서 숲길 방향으로 이어지는 발자국이 발견됐다.'}],
                    sid='DEMO-CAMP-FOOTPRINT')),
            ({'choice_id': 'inspect'}, scene('추가로 알아낼 단서는 없다. 이미 확인한 발자국은 숲 방향으로 이어진다.',
                    camp_choices, sid='DEMO-CAMP-NOTHING-NEW')),
            ({'choice_id': 'return'}, scene('숲으로 돌아오자 안내인이 길을 살핀다.',
                    [choice('ask', '안내인에게 발자국을 물어본다')],
                    dialogue='돌아왔구나. 야영지에서는 뭔가 달라진 점을 발견했어?',
                    sid='DEMO-FOREST-RETURN')),
            ({'free_text': '안내인에게 야영지의 화덕 옆에서 발견한 발자국을 알려준다'},
                    scene('안내인은 소식을 듣고 숲길 쪽을 살핀다.',
                    [choice('ask', '안내인에게 발자국의 주인을 물어본다')],
                    dialogue='그 방향으로 발자국이 이어졌다면 내 쪽에서도 살펴볼게.',
                    events=[{'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': 'CLUE-CAMP-FOOTPRINT-01'}],
                    sid='DEMO-FOREST-GUIDE-LEARN')),
        ]
        for submission, model in turns:
            seen = []
            def sender(token, selected, context):
                seen.append(context)
                return json.dumps(model, ensure_ascii=False)
            rendered = run_turn(store, submission=submission, model='mock', token='not-real', sender=sender)
            trip.append({'revision': rendered['revision'], 'location': rendered['region']['id'],
                         'submission': submission, 'known_discoveries_sent': len(seen[0]['known_discoveries']),
                         'discovered_clues_here': len(rendered.get('discovered_clues', [])),
                         'beat_preview': rendered['beats'][0]['text'],
                         'npc_knowledge_entries': len(store.load()['npcs']['DEMO-GUIDE']['knowledge'])})
        original = store.load()
        store.cache.unlink()
        restored = store.load()
        assert original == restored, 'cache deletion must not affect replayed state'
        assert restored['revision'] == 5
        assert len(restored['discoveries']) == 1, 'duplicate investigation must not create a second clue'
        assert restored['player']['location'] == 'DEMO-FOREST'
        assert len(restored['player_action_history']) == 5
        assert len(restored['npcs']['DEMO-GUIDE']['knowledge']) == 2
        # Unknown direction from the camp is rejected BEFORE a model call.
        # Test in a fresh camp instance from the same data:
        dummy = copy.deepcopy(restored)
        dummy['player']['location'] = 'DEMO-CAMP'
        # Validity is kept for standalone directional resolution.
        from world_engine import resolve_explicit_movement
        try:
            resolve_explicit_movement(dummy, '동쪽으로 이동한다')
        except WorldError:
            invalid_direction = True
        else:
            invalid_direction = False
        assert invalid_direction
        out = {'note': 'MOCK AI responses only. No ChatGPT/paid API call; test world only.',
               'turns': trip, 'cache_deleted_and_replayed_equal': original == restored,
               'invalid_direction_rejected': invalid_direction,
               'final_revision': restored['revision'],
               'final_discovery_ids': [c['id'] for c in restored['discoveries']]}
        return out


if __name__ == '__main__':
    data = play()
    path = ROOT / 'PROOF_STORY_PROGRESS.json'
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(data, ensure_ascii=False, indent=2))
