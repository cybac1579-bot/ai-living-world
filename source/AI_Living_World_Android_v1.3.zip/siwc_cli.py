"""Optional interactive ChatGPT-plan connector. No command calls a paid API-key path.

Commands that contact OpenAI require explicit CLI invocation by the human.
"""
from __future__ import annotations
import argparse
import json
import os
import time
from pathlib import Path
from ai_adapter import apply_ai_turn, build_model_context
from world_engine import EventStore, WorldError
from siwc_client import (SIWCError, oauth_login, read_credentials, refresh_credentials,
                         list_models, stream_response)

BASE = Path.home() / ".config" / "ai-living-world" / "siwc"

def current_credentials(credentials_file: Path):
    credentials = read_credentials(credentials_file)
    if credentials.get("expires_at", 0) < time.time() + 90:
        credentials = refresh_credentials(credentials_file, credentials)
    return credentials


def one_authenticated_turn(*, credentials_file: Path, store_dir: Path, model: str,
                           submission: dict, expected_revision: int) -> dict:
    """Invariant: nothing enters journal until stream completes and schema validates."""
    store = EventStore(store_dir)
    state = store.load()
    if state["revision"] != expected_revision:
        raise WorldError("outdated turn; reload before inference")
    context = build_model_context(state, submission=submission)
    creds = current_credentials(credentials_file)
    available = {m["slug"] for m in list_models(creds["access_token"])}
    if model not in available:
        raise SIWCError("requested model is not available to this account")
    text = stream_response(creds["access_token"], model, context)
    # apply_ai_turn() performs strict parser validation, calls journal commit
    # with optimistic revision, then returns only the committed rendering.
    return apply_ai_turn(store, expected_revision=expected_revision,
                         submission=submission, ai_response=text)


def main(argv=None):
    parser = argparse.ArgumentParser(description="AI Living World: ChatGPT plan sign-in (optional)")
    parser.add_argument("action", choices=["login", "status", "models", "turn"])
    parser.add_argument("--credentials-dir", type=Path, default=BASE)
    parser.add_argument("--store", type=Path)
    parser.add_argument("--model")
    parser.add_argument("--expected", type=int)
    grp = parser.add_mutually_exclusive_group()
    grp.add_argument("--choice")
    grp.add_argument("--text")
    args = parser.parse_args(argv)
    credentials_file = args.credentials_dir / "credentials.json"
    try:
        if args.action == "login":
            result = oauth_login(args.credentials_dir)
        elif args.action == "status":
            cred = read_credentials(credentials_file)
            result = {"connected": True, "plan_usage_permission": True,
                      "account": cred.get("email", ""), "expires_at": cred.get("expires_at")}
        elif args.action == "models":
            cred = current_credentials(credentials_file)
            result = {"models": list_models(cred["access_token"])}
        else:
            if args.store is None or args.model is None or args.expected is None:
                parser.error("turn requires --store, --model and --expected")
            if (args.choice is None) == (args.text is None):
                parser.error("turn requires exactly one of --choice or --text")
            submission = {"choice_id": args.choice} if args.choice is not None else {"free_text": args.text}
            result = one_authenticated_turn(credentials_file=credentials_file, store_dir=args.store,
                                            model=args.model, submission=submission,
                                            expected_revision=args.expected)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (SIWCError, WorldError, ValueError, FileNotFoundError) as exc:
        # Exceptions are sanitized and do not contain access tokens or callback URLs.
        print("실행 실패:", str(exc))
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
