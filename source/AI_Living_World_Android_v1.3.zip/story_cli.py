"""Console playtest using actual ChatGPT-plan OAuth, DEMO data only."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

from connect_once import CREDENTIALS_DIR, choose_model
from siwc_client import SIWCError, oauth_login
from world_engine import WorldError
from live_story import authorized_catalog, initial_demo_store, run_turn

ROOT = Path(__file__).resolve().parent
DEFAULT_STORE = ROOT / 'my_demo_save'
SAMPLE = ROOT / 'examples' / 'live_demo_world.json'


def _show(rendered: dict):
    print('\n' + '=' * 55)
    print(f"{rendered['region']['name']} | rev {rendered['revision']} | 이미지: {rendered['image']['kind']}")
    for b in rendered['beats']:
        if b['kind'] == 'dialogue':
            s=b['speaker']
            print(f"\n[{s['name']}] {b['text']}")
        else:
            print('\n' + b['text'])
    print('\n-- 행동 선택 --')
    for i, c in enumerate(rendered['choices'], 1):
        print(f"  {i}. {c['label']}")
    print('  t. 직접 입력    0. 종료')


def main(argv=None, input_func=input):
    parser=argparse.ArgumentParser(description='AI Living World 실제 GPT 연결 세계 테스트. 비공식 DEMO 전용.')
    parser.add_argument('--store',type=Path,default=DEFAULT_STORE)
    parser.add_argument('--model',help='사용 가능한 모델 중 정확한 slug. 지정 안 하면 목록에서 선택')
    args=parser.parse_args(argv)
    if not (args.store / 'initial_state.json').is_file():
        print('\n[저장 확인] 현재 폴더에 이전 DEMO 저장이 없어.')
        print('v0.7에서 진행한 rev 1을 계속하려면 종료한 뒤,')
        print('기존 v0.7 폴더의 my_demo_save 폴더를 이 폴더로 복사해줘.')
        print('로그인 정보나 credentials.json은 옮기지 않아도 돼.')
        if input_func('새로운 비공식 테스트 세계를 만들까? (y/N): ').strip().lower() not in ('y', 'yes'):
            print('저장 파일을 새로 만들지 않고 종료했어.')
            return 0
    store=initial_demo_store(args.store,sample_file=SAMPLE)
    try:
        token, models=authorized_catalog(credentials_dir=CREDENTIALS_DIR)
    except SIWCError as error:
        print('인증 정보 확인 실패:',str(error))
        print('기존 성공한 로그인 검사 프로그램으로 다시 로그인해줘. 토큰은 채팅에 공유하지 마.')
        return 2
    ids=[m['slug'] for m in models if isinstance(m,dict) and m.get('slug')]
    if args.model:
        if args.model not in ids:
            print('요청한 모델이 실제 사용 가능 모델 목록에 없어 중단했어.')
            return 2
        selected=args.model
    else:
        selected=choose_model(models,input_func)
    if not selected:
        return 0
    print('\n비공식 테스트 세계만 변경해. 매 GPT 요청마다 ChatGPT 구독 사용량을 소모할 수 있어.')
    print('선택지와 자유 입력은 실제로 전송되지만, 그래픽 모바일 UI는 아직 연결되지 않았어.')
    from world_engine import render_contract
    while True:
        state=store.load()
        rendered=render_contract(state)
        _show(rendered)
        answer=input_func('선택 번호 / t / 0: ').strip()
        if answer == '0':
            return 0
        if answer.lower() == 't':
            val=input_func('자유롭게 입력: ').strip()
            if not val:
                continue
            submission={'free_text':val}
        elif answer.isdecimal() and 1 <= int(answer) <= len(rendered['choices']):
            submission={'choice_id':rendered['choices'][int(answer)-1]['id']}
        else:
            print('올바른 번호 또는 t를 입력해줘.');continue
        if input_func('이 행동으로 GPT 실제 요청을 보낼까? (y/N): ').strip().lower() not in ('y','yes'):
            print('취소했어. 세계 기록은 바뀌지 않았어.'); continue
        try:
            output=run_turn(store,submission=submission,model=selected,token=token)
            print(f"\n[완료] 세계 기록 rev {output['revision']}에 안전하게 저장했어.")
        except (WorldError, SIWCError, ValueError, OSError) as exc:
            print('\n[중단] 모델 출력이나 저장 검증 실패:',str(exc))
            print('세계 기록은 변경되지 않았어. 다시 시도하려면 새로운 승인 후 요청해야 해.')


if __name__=='__main__':
    raise SystemExit(main())
