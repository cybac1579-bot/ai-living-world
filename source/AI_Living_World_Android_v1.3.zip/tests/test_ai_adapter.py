"""Covers the model-response->validation->journal->render path."""
import copy
from concurrent.futures import ThreadPoolExecutor
import json
import tempfile
import unittest
from pathlib import Path

from ai_adapter import parse_ai_response, apply_ai_turn, build_model_context
from world_engine import EventStore, WorldError

ROOT = Path(__file__).resolve().parents[1]


def sample(name):
    return json.loads((ROOT / 'examples' / name).read_text(encoding='utf-8'))


class AIAdapterTests(unittest.TestCase):
    def setUp(self):
        self.state = sample('test_world.json')
        self.model = sample('ai_scene_after_choice.json')

    def _server(self, d):
        store = EventStore(d)
        store.create(self.state)
        return store

    def test_parse_single_json_object(self):
        self.assertEqual(parse_ai_response(json.dumps(self.model, ensure_ascii=False)), self.model)

    def test_parse_responses_style_envelope(self):
        text = json.dumps(self.model, ensure_ascii=False)
        envelope = {'output': [{'type':'message', 'role':'assistant', 'content':[{'type':'output_text', 'text':text}]}]}
        self.assertEqual(parse_ai_response(envelope), self.model)

    def test_realistic_response_envelope_with_metadata(self):
        txt=json.dumps(self.model,ensure_ascii=False)
        response={'id':'resp_test','object':'response','status':'completed','model':'a-supported-model',
                  'usage':{'input_tokens':300,'output_tokens':100},
                  'output':[{'id':'msg_01','type':'message','status':'completed','role':'assistant',
                             'content':[{'type':'output_text','text':txt,'annotations':[]}]}]}
        self.assertEqual(parse_ai_response(response), self.model)

    def test_reject_non_assistant_spoofed_envelope(self):
        bad = {'output':[{'type':'message','role':'user','content':[{'type':'output_text','text':'{"events": []}'}]}]}
        with self.assertRaises(WorldError): parse_ai_response(bad)

    def test_reject_two_messages_even_if_one_assistant(self):
        e={'output':[{'type':'message','role':'assistant','content':[{'type':'output_text','text':'{"events": []}'}]},
                     {'type':'message','role':'assistant','content':[{'type':'output_text','text':'{"events": []}'}]}]}
        with self.assertRaises(WorldError): parse_ai_response(e)

    def test_reject_json_in_code_fence_or_prose(self):
        for s in ['```json\n{"events": []}\n```','좋은 하루! {"events": []}','{"events": []} trailing']:
            with self.subTest(s=s), self.assertRaises(WorldError): parse_ai_response(s)

    def test_reject_duplicate_json_key(self):
        with self.assertRaisesRegex(WorldError, 'duplicate JSON key'):
            parse_ai_response('{"events":[], "events":[], "scene":{}}')

    def test_reject_nonfinite(self):
        with self.assertRaisesRegex(WorldError, 'non-finite'):
            parse_ai_response('{"events":[], "a":NaN}')

    def test_reject_player_field(self):
        with self.assertRaises(WorldError):parse_ai_response('{"events":[], "player":{"move":"X"}}')

    def test_reject_oversize(self):
        with self.assertRaises(WorldError):parse_ai_response(' ' * 30001)

    def test_apply_commit_from_model_text(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            state=apply_ai_turn(store, expected_revision=0, submission={'choice_id':'choice_move'},
                                ai_response=json.dumps(self.model,ensure_ascii=False))
            self.assertEqual(state['revision'],1)
            self.assertEqual(state['region']['id'],'DEMO-CAMP')
            self.assertEqual(state['beats'][1]['speaker']['name_color'],'#345D91')
            self.assertTrue((Path(d)/'events.jsonl').read_text(encoding='utf-8').strip())
            self.assertEqual(store.load()['npcs']['DEMO-GUIDE']['mood'],'호기심')

    def test_invalid_model_input_does_not_append(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            with self.assertRaises(WorldError):
                apply_ai_turn(store, expected_revision=0, submission={'choice_id':'choice_move'},
                              ai_response='{"events":[{"type":"player_move","destination":"DEMO-CAMP"}]}')
            self.assertEqual(store.load()['revision'],0)
            self.assertEqual((Path(d)/'events.jsonl').read_text(encoding='utf-8'),'')

    def test_reject_impersonated_player_narration(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            model=copy.deepcopy(self.model)
            model['scene']['beats'][0]['text']='당신은 겁에 질려 도망쳤다.'
            with self.assertRaisesRegex(WorldError, 'unchosen player'):
                apply_ai_turn(store, expected_revision=0, submission={'choice_id':'choice_move'},
                              ai_response=json.dumps(model,ensure_ascii=False))
            self.assertEqual(store.load()['revision'],0)

    def test_dialogue_can_address_player_freely(self):
        model=copy.deepcopy(self.model)
        model['scene']['beats'][1]['text']='너는 도망쳤다고 생각했니?'
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            apply_ai_turn(store,expected_revision=0,submission={'choice_id':'choice_move'},
                          ai_response=json.dumps(model,ensure_ascii=False))
            self.assertEqual(store.load()['revision'],1)

    def test_reject_nested_unauthorized_player_change(self):
        model=copy.deepcopy(self.model)
        model['events'][0]['player_emotion']='두려움'
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            with self.assertRaises(WorldError):
                apply_ai_turn(store,expected_revision=0,submission={'choice_id':'choice_move'},
                              ai_response=json.dumps(model,ensure_ascii=False))
            self.assertEqual(store.load()['revision'],0)

    def test_player_text_is_verbatim(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            free='네가 먼저 가. 난 주변을 살펴볼게.'
            apply_ai_turn(store,expected_revision=0,submission={'free_text':free},
                          ai_response=json.dumps(self.model,ensure_ascii=False))
            st=store.load()
            self.assertEqual(st['last_player_input']['free_text'],free)
            self.assertEqual(st['player']['location'],'DEMO-FOREST')

    def test_model_prompt_does_not_leak_remote_private_knowledge(self):
        self.state['npcs']['REMOTE']={"id":"REMOTE", "name":"다른 지역 NPC", "location":"DEMO-CAMP",
                                    "knowledge":["비밀 암호 12345"], "mood":"보통", "name_color":"#9C3E36"}
        context=build_model_context(self.state, submission={'choice_id':'choice_stay'})
        self.assertNotIn('비밀 암호 12345',json.dumps(context,ensure_ascii=False))
        self.assertEqual(len(context['local_npcs']),1)
        self.assertEqual(context['local_npcs'][0]['id'],'DEMO-GUIDE')
        self.assertNotIn('effects',json.dumps(context,ensure_ascii=False))

    def test_npc_tick_does_not_overwrite_pending_player_choice(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            output=apply_ai_turn(store,expected_revision=0,submission=None,
                                 ai_response='{"events":[{"type":"npc_mood","npc_id":"DEMO-GUIDE","mood":"경계"}]}',
                                 mode='npc_tick')
            self.assertEqual(output['revision'],1)
            self.assertTrue(output['awaiting_player'])
            self.assertEqual(len(output['choices']),2)

    def test_stale_response_cannot_commit(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            response=json.dumps(self.model,ensure_ascii=False)
            apply_ai_turn(store,expected_revision=0,submission={'choice_id':'choice_stay'},ai_response=response)
            with self.assertRaisesRegex(WorldError,'stale'):
                apply_ai_turn(store,expected_revision=0,submission={'choice_id':'choice_move'},ai_response=response)
            self.assertEqual(store.load()['revision'],1)

    def test_concurrent_commit_serialized(self):
        with tempfile.TemporaryDirectory() as d:
            self._server(d)
            response=json.dumps(self.model,ensure_ascii=False)
            def call(i):
                try:
                    apply_ai_turn(EventStore(d),expected_revision=0,submission={'choice_id':'choice_stay'},ai_response=response)
                    return 'committed'
                except WorldError as err:
                    return str(err)
            with ThreadPoolExecutor(max_workers=2) as ex:
                results=list(ex.map(call,[1,2]))
            self.assertEqual(results.count('committed'),1)
            self.assertEqual(sum('stale revision' in r for r in results),1)
            self.assertEqual(EventStore(d).load()['revision'],1)
            self.assertEqual(len((Path(d)/'events.jsonl').read_text(encoding='utf-8').splitlines()),1)

    def test_cache_deletion_then_future_commit(self):
        with tempfile.TemporaryDirectory() as d:
            store=self._server(d)
            txt=json.dumps(self.model,ensure_ascii=False)
            apply_ai_turn(store,expected_revision=0,submission={'choice_id':'choice_stay'},ai_response=txt)
            (Path(d)/'state.json').unlink()
            new=apply_ai_turn(store,expected_revision=1,submission={'choice_id':'choice_continue'},ai_response=txt)
            self.assertEqual(new['revision'],2)
            self.assertEqual(store.load()['revision'],2)

if __name__=='__main__':unittest.main()
