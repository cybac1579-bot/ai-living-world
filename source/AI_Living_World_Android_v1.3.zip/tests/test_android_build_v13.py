"""Regression tests for local build preparation, not a substitute for Gradle."""
from __future__ import annotations
import shutil
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from tools.android_build_preflight import run
from tools.verify_debug_apk import inspect_apk

BASE=Path(__file__).resolve().parents[1]

class AndroidBuildPreflightV13(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        for name in ('android_native','tools','web','examples'):
            shutil.copytree(BASE/name,self.root/name)
        for p in (BASE/'android_native/app/src/main/python').glob('*.py'):
            # Source of truth is packaged in native Python bundle.
            shutil.copy2(BASE/p.name,self.root/p.name)

    def test_baseline_preflight_passes(self):
        self.assertTrue(run(self.root)['ok'])

    def test_source_bundle_staleness_fails_closed(self):
        p=self.root/'android_native/app/src/main/python/world_engine.py'
        p.write_text(p.read_text()+'\n# stale\n')
        self.assertIn('Stale bundled Python world_engine',run(self.root)['errors'])

    def test_asset_bundle_staleness_fails_closed(self):
        p=self.root/'android_native/app/src/main/assets/web/app.js'
        p.write_text(p.read_text()+'\n// stale\n')
        self.assertIn('Stale bundled asset web/app.js',run(self.root)['errors'])

    def test_backup_enabled_fails(self):
        p=self.root/'android_native/app/src/main/AndroidManifest.xml'
        p.write_text(p.read_text().replace('android:allowBackup="false"','android:allowBackup="true"'))
        self.assertIn('Android backup not disabled',run(self.root)['errors'])

    def test_non_loopback_cleartext_fails(self):
        p=self.root/'android_native/app/src/main/res/xml/network_security_config.xml'
        p.write_text(p.read_text().replace('<domain>127.0.0.1</domain>','<domain>example.com</domain>'))
        self.assertIn('Unexpected network security host',run(self.root)['errors'])

    def test_unpinned_crypto_fails(self):
        p=self.root/'android_native/app/build.gradle'
        p.write_text(p.read_text().replace('cryptography==42.0.8','cryptography>=42.0.8'))
        self.assertTrue(any('Pinned Android dependency' in e for e in run(self.root)['errors']))

    def test_user_credential_file_fails(self):
        p=self.root/'android_native/app/credentials.json'
        p.write_text('{}')
        self.assertTrue(any('Sensitive/local build file' in e for e in run(self.root)['errors']))

    def test_wrong_gradle_version_fails(self):
        p=self.root/'android_native/gradle/wrapper/gradle-wrapper.properties'
        p.write_text(p.read_text().replace('gradle-9.6.0','gradle-9.4.0'))
        self.assertTrue(any('Gradle 9.6' in e for e in run(self.root)['errors']))

    def test_fake_incomplete_apk_rejected(self):
        p=self.root/'bad.apk'
        with ZipFile(p,'w') as z:
            z.writestr('AndroidManifest.xml','something')
        with self.assertRaises(ValueError):inspect_apk(p)

    def test_mock_archive_structure_check_is_only_zip_check(self):
        # We deliberately DO NOT claim this test creates a real APK.
        p=self.root/'mock.apk'
        with ZipFile(p,'w') as z:
            for name in ('AndroidManifest.xml','classes.dex','assets/web/index.html',
                         'assets/web/app.js','assets/web/style.css',
                         'assets/web/assets/forest.jpg','lib/arm64-v8a/libpython3.11.so'):
                z.writestr(name,b'x')
        self.assertEqual('mock.apk',inspect_apk(p)['apk_name'])

if __name__=='__main__':unittest.main()
