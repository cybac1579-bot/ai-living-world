"""Chaquopy embedded bridge tests. Run without Android/Gradle or real OAuth."""
import http.client
import json
import tempfile
import unittest
from pathlib import Path
from urllib.parse import urlsplit
from unittest.mock import patch
import shutil
import mobile_embedded as me
from world_engine import EventStore

ROOT = Path(__file__).resolve().parents[1]

class EmbeddedRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.private = self.base/'app-private'; self.private.mkdir()
        self.res = self.private/'resources';self.res.mkdir()
        shutil.copytree(ROOT/'web',self.res/'web')
        (self.res/'examples').mkdir()
        shutil.copy2(ROOT/'examples/live_demo_world.json',self.res/'examples/live_demo_world.json')
        me.stop_engine()
        self.addCleanup(me.stop_engine)

    def fetch(self,url):
        part=urlsplit(url)
        conn=http.client.HTTPConnection(part.hostname,part.port,timeout=3)
        origin=f'{part.hostname}:{part.port}'
        conn.request('GET',f'/?{part.query}',headers={'Host':origin})
        boot=conn.getresponse();cookie=boot.getheader('Set-Cookie');boot.read()
        self.assertEqual(boot.status,200)
        self.assertIn('HttpOnly',cookie)
        conn.request('GET','/api/state',headers={'Host':origin,'Cookie':cookie.split(';')[0]})
        resp=conn.getresponse();value=(resp.status,json.loads(resp.read().decode()))
        conn.close()
        return value

    def test_no_network_or_server_on_import(self):
        self.assertFalse(me.status()['running'])

    def test_unauthorized_local_app_cannot_read_or_call_gpt(self):
        url=me.start_engine(self.private,self.res,True)
        part=urlsplit(url)
        c=http.client.HTTPConnection(part.hostname,part.port,timeout=3)
        origin=f'http://{part.hostname}:{part.port}'
        def req(method, path,headers=None,body=None):
            c.request(method,path,body=body,headers={'Host':f'{part.hostname}:{part.port}',**(headers or {})})
            r=c.getresponse();data=r.read();return r.status,data
        self.assertEqual(req('GET','/api/state')[0],403)
        self.assertEqual(req('GET','/app.js')[0],403)
        self.assertEqual(req('GET','/?access=wrong')[0],403)
        self.assertEqual(req('POST','/api/turn',{'Origin':origin,'Content-Type':'application/json'},b'{}')[0],403)
        c.close()

    def test_fake_cookie_denied_even_with_valid_csrf(self):
        url=me.start_engine(self.private,self.res,True)
        part=urlsplit(url)
        c=http.client.HTTPConnection(part.hostname,part.port,timeout=3)
        origin=f'http://{part.hostname}:{part.port}'
        c.request('POST','/api/turn',body=b'{}',headers={'Host':f'{part.hostname}:{part.port}',
          'Origin':origin,'Content-Type':'application/json','Cookie':'alw_session=fake',
          'X-ALW-CSRF':me._SERVER.bridge.csrf})
        r=c.getresponse();r.read();self.assertEqual(r.status,403);c.close()

    def test_offline_server_returns_scene_without_credentials(self):
        url=me.start_engine(self.private,self.res,True)
        self.assertTrue(url.startswith('http://127.0.0.1:'))
        status,data=self.fetch(url)
        self.assertEqual(status,200)
        self.assertEqual(data['mode'],'DEMO')
        self.assertFalse(data['connected'])
        self.assertEqual(data['world']['revision'],0)
        self.assertNotIn('credentials',str(data))
        self.assertFalse((self.private/'auth'/'credentials.json').exists())

    def test_repeated_start_returns_same_server_and_no_overwrite(self):
        first=me.start_engine(self.private,self.res,offline=True)
        save=self.private/'saves'/'DEMO'
        expected=(save/'initial_state.json').read_bytes()
        second=me.start_engine(self.private,self.res,offline=True)
        self.assertEqual(first,second)
        self.assertEqual(expected,(save/'initial_state.json').read_bytes())
        self.assertTrue(me.status()['running'])

    def test_stop_closes_server(self):
        url=me.start_engine(self.private,self.res,offline=True)
        me.stop_engine()
        self.assertFalse(me.status()['running'])
        self.assertIsNone(me.status()['port'])
        with self.assertRaises((ConnectionRefusedError,TimeoutError,OSError)):
            self.fetch(url)

    def test_switch_online_denied_if_no_auth_without_leaking_or_api(self):
        previous=me.start_engine(self.private,self.res,offline=True)
        with self.assertRaisesRegex(ValueError,'로그인'):
            me.start_engine(self.private,self.res,False,catalog=lambda **_:self.fail('network must not be called'))
        self.assertFalse(me.status()['running'])
        self.assertEqual(EventStore(self.private/'saves'/'DEMO').load()['revision'],0)

    def test_online_from_dummy_credential_catalog_never_returns_token(self):
        (self.private/'auth').mkdir(); (self.private/'auth'/'credentials.json').write_text('{"not":"real"}')
        token='SIMULATED_SECRET_NO_REAL_OAUTH_98765'
        url=me.start_engine(self.private,self.res,offline=False,
                            catalog=lambda **kw:(token,[{'slug':'test-model','name':'Test'}]))
        code,doc=self.fetch(url)
        self.assertEqual(code,200)
        self.assertTrue(doc['connected'])
        self.assertNotIn(token,json.dumps(doc))
        self.assertEqual(doc['models'][0]['slug'],'test-model')
        self.assertEqual(me.status()['mode'],'online')
        # Return to offline and verify no bypass.
        second=me.start_engine(self.private,self.res,offline=True)
        self.assertFalse(self.fetch(second)[1]['connected'])

    def test_resources_must_be_private_and_complete(self):
        other=self.base/'public'; shutil.copytree(self.res,other)
        with self.assertRaisesRegex(ValueError,'private'):
            me.start_engine(self.private,other,True)
        (self.res/'web'/'index.html').unlink()
        with self.assertRaisesRegex(ValueError,'missing'):
            me.start_engine(self.private,self.res,True)

    def test_non_demo_world_rejected_without_overwriting(self):
        sample=self.res/'examples'/'live_demo_world.json'
        data=json.loads(sample.read_text(encoding='utf-8'))
        data['world_id']='PRODUCTION-WORLD'
        sample.write_text(json.dumps(data),encoding='utf-8')
        with self.assertRaises(ValueError):
            me.start_engine(self.private,self.res,True)
        self.assertFalse((self.private/'saves'/'DEMO'/'initial_state.json').exists())

    def test_login_calls_external_system_browser_only_for_approved_url(self):
        called=[]
        class NativeBridge:
            def openSystemBrowser(self,url):
                called.append(url)
                return True
        def fake_login(folder,timeout,browser_open):
            self.assertEqual(folder,self.private/'auth')
            self.assertEqual(timeout,240)
            self.assertFalse(browser_open('https://evil.invalid/api/accounts/authorize?a=b'))
            self.assertFalse(browser_open('http://127.0.0.1:8765/?code=secret'))
            self.assertTrue(browser_open('https://auth.openai.com/api/accounts/authorize?fake=1'))
            return {'plan_usage_permission':True}
        message=me.login(self.private,NativeBridge(),auth_fn=fake_login)
        self.assertIn('로그인',message)
        self.assertEqual(len(called),1)
        self.assertTrue(called[0].startswith('https://auth.openai.com/'))

    def test_login_permission_missing_never_succeeds(self):
        with self.assertRaisesRegex(ValueError,'permission'):
            me.login(self.private,lambda u:True,auth_fn=lambda *a,**kw:{'plan_usage_permission':False})

    def test_embedded_python_modules_match_root_sources(self):
        native=ROOT/'android_native/app/src/main/python'
        for name in ('mobile_embedded.py','vn_server.py','world_engine.py','siwc_client.py','live_story.py'):
            with self.subTest(name=name):
                self.assertEqual((ROOT/name).read_bytes(),(native/name).read_bytes())

    def test_native_ui_assets_match_root_and_bootstrap_restricted(self):
        assets=ROOT/'android_native/app/src/main/assets'
        for name in ('index.html','app.js','style.css','assets/forest.jpg'):
            with self.subTest(name=name):
                self.assertEqual((ROOT/'web'/name).read_bytes(),(assets/'web'/name).read_bytes())
        source=(ROOT/'vn_server.py').read_text()
        self.assertIn('HttpOnly; SameSite=Strict',source)
        self.assertIn('_has_app_session',source)
        self.assertIn("if not self._has_app_session()",source)

    def test_native_login_waits_for_browser_result_and_uses_atomic_resources(self):
        java=(ROOT/'android_native/app/src/main/java/com/ailivingworld/mobile/MainActivity.java').read_text()
        self.assertIn('opened.await(8, TimeUnit.SECONDS) && didOpen.get()',java)
        self.assertIn('StandardCopyOption.ATOMIC_MOVE',java)
        self.assertIn('fos.getFD().sync()',java)

    def test_native_android_project_whitelisted_network_and_no_secrets(self):
        native=ROOT/'android_native'
        manifest=(native/'app/src/main/AndroidManifest.xml').read_text()
        config=(native/'app/src/main/res/xml/network_security_config.xml').read_text()
        java=(native/'app/src/main/java/com/ailivingworld/mobile/MainActivity.java').read_text()
        build=(native/'app/build.gradle').read_text()
        self.assertIn('android:allowBackup="false"',manifest)
        self.assertIn('android:networkSecurityConfig="@xml/network_security_config"',manifest)
        self.assertIn('<base-config cleartextTrafficPermitted="false"',config)
        self.assertIn('<domain>127.0.0.1</domain>',config)
        self.assertNotIn('addJavascriptInterface',java)
        self.assertIn('settings.setAllowFileAccess(false)',java)
        self.assertIn('"auth.openai.com".equals(uri.getHost())',java)
        self.assertIn("minSdk 28",build)
        self.assertIn("id 'com.chaquo.python'",build)
        self.assertNotIn('OPENAI_API_KEY',java+build)

if __name__=='__main__': unittest.main()
