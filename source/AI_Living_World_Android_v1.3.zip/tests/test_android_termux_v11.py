"""Android phone-only runtime tests (no real Android, OAuth or paid inference)."""
from __future__ import annotations
import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import mobile_android as ma
import siwc_client as sc
from live_story import initial_demo_store
from sync_bridge import inspect_bundle

ROOT = Path(__file__).resolve().parents[1]


class AndroidRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.home = Path(self.t.name)

    def test_android_env_detects_real_termux_style(self):
        self.assertTrue(ma.is_termux({'PREFIX':'/data/data/com.termux/files/usr','HOME':'/data/data/com.termux/files/home'}))
        self.assertFalse(ma.is_termux({'PREFIX':'/usr','HOME':'/home/user'}))

    def test_browser_uses_direct_android_command_no_shell(self):
        calls=[]
        def fake_run(argv,**kwargs):
            calls.append((argv,kwargs));return SimpleNamespace(returncode=0)
        good='https://auth.openai.com/api/accounts/authorize?client_id=dynamic_agent_client&state=redacted'
        self.assertTrue(ma.termux_browser_open(good,which=lambda _:'yes',run=fake_run))
        self.assertEqual(calls[0][0],['termux-open-url',good])
        self.assertFalse(calls[0][1].get('shell',False))
        self.assertEqual(calls[0][1]['stdout'],ma.subprocess.DEVNULL)

    def test_browser_only_allows_official_authorize_and_localhost(self):
        urls=[
            'https://evil.invalid/api/accounts/authorize?state=s',
            'http://127.0.0.2:8765/',
            'http://0.0.0.0:8765/',
            'http://127.0.0.1:123/internal',
            'https://auth.openai.com.evil.invalid/api/accounts/authorize',
            'https://auth.openai.com/api/accounts/oauth/token',
            'file:///sdcard/Download/a.html',
            'http://127.0.0.1:8765/?x=1#fragment',
        ]
        for url in urls:
            with self.subTest(url=url):
                self.assertFalse(ma.termux_browser_open(url,which=lambda _:'yes',run=lambda *a,**k:self.fail('network/browser')))
        self.assertTrue(ma.termux_browser_open('http://127.0.0.1:8765/',which=lambda _:'yes',run=lambda *a,**k:SimpleNamespace(returncode=0)))

    def test_missing_android_openurl_does_not_print_oauth_url(self):
        data='https://auth.openai.com/api/accounts/authorize?state=PRIVATE-STATE-1234'
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            result=ma.termux_browser_open(data,which=lambda _:None)
        self.assertFalse(result)
        self.assertNotIn('PRIVATE-STATE',out.getvalue())

    def test_client_login_supports_android_browser_callback(self):
        # Source-level API contract (actual OAuth cannot run in sandbox).
        import inspect
        sig=inspect.signature(sc.oauth_login)
        self.assertIn('browser_open',sig.parameters)
        self.assertIsNone(sig.parameters['browser_open'].default)
        self.assertIn('opener(attempt.url)',inspect.getsource(sc.oauth_login))

    def test_login_without_android_stops_before_network(self):
        login_calls=[]
        with patch.object(ma,'is_termux',return_value=False):
            result=ma.run_login(login=lambda *a,**kw:login_calls.append((a,kw)))
        self.assertEqual(result,2)
        self.assertFalse(login_calls)

    def test_login_starts_phone_scoped_oauth_with_browser_opener(self):
        state=[]
        def login(*args,**kwargs):
            state.append((args,kwargs));return {'signed_in':True,'plan_usage_permission':True}
        with patch.object(ma,'is_termux',return_value=True):
            self.assertEqual(ma.run_login(opener=lambda u:True,login=login),0)
        self.assertEqual(state[0][0][0],ma.AUTH)
        self.assertEqual(state[0][1]['timeout'],240)
        self.assertTrue(callable(state[0][1]['browser_open']))

    def test_login_missing_permission_does_not_count_success(self):
        with patch.object(ma,'is_termux',return_value=True):
            self.assertEqual(ma.run_login(opener=lambda u:True,login=lambda *a,**k:{'signed_in':True,'plan_usage_permission':False}),2)

    def test_no_auth_no_model_or_server_and_no_paid_fallback(self):
        with patch.object(ma,'is_termux',return_value=True), patch.object(ma,'AUTH',self.home/'missing'),patch.object(ma,'authorized_catalog',side_effect=AssertionError('Do not call')):
            code=ma.serve(offline=False,offline_store=self.home/'save',open_browser=lambda u:self.fail('No browser'))
        self.assertEqual(code,2)
        self.assertFalse((self.home/'save'/'initial_state.json').exists())

    def test_offline_android_server_uses_private_save_loopback(self):
        used=[]
        class FakeServer:
            def __init__(self,address,bridge):
                used.append((address,bridge));self.server_port=address[1]
            def __enter__(self):return self
            def __exit__(self,*a):return False
            def serve_forever(self,**kwargs):used.append(('running',kwargs))
        save=self.home/'private'/'save'
        with patch.object(ma,'is_termux',return_value=True),patch.object(ma,'LoopbackServer',FakeServer):
            self.assertEqual(ma.serve(offline=True,port=8765,offline_store=save,open_browser=lambda u:used.append(u) or True),0)
        self.assertEqual(used[0][0],('127.0.0.1',8765))
        self.assertFalse(used[0][1].page_state()['connected'])
        self.assertTrue((save/'initial_state.json').exists())
        self.assertEqual(used[1],'http://127.0.0.1:8765/')

    def test_phone_login_not_packaged_in_public_save(self):
        save=initial_demo_store(self.home/'private'/'demo',sample_file=ma.SAMPLE)
        downloads=self.home/'downloads';downloads.mkdir()
        with patch.object(ma,'is_termux',return_value=True):
            self.assertEqual(ma.backup(downloads=downloads,save=self.home/'private'/'demo'),0)
        archives=list(downloads.glob('*.zip'))
        self.assertEqual(len(archives),1)
        self.assertEqual(inspect_bundle(archives[0])['revision'],0)
        import zipfile
        with zipfile.ZipFile(archives[0]) as z:
            self.assertEqual(set(z.namelist()),{'initial_state.json','events.jsonl','manifest.json'})
            self.assertNotIn('credentials.json',str(z.namelist()))

    def test_android_backup_fails_without_storage_permission(self):
        initial_demo_store(self.home/'save',sample_file=ma.SAMPLE)
        with patch.object(ma,'is_termux',return_value=True):
            self.assertEqual(ma.backup(downloads=self.home/'not-granted',save=self.home/'save'),2)

    def test_scripts_no_paid_keys_and_termux_guard(self):
        for name in ('ANDROID_INSTALL_ONCE.sh','ANDROID_GAME_MENU.sh'):
            source=(ROOT/name).read_text(encoding='utf-8')
            self.assertIn('com.termux/files/usr',source)
            self.assertNotIn('OPENAI_API_KEY',source)
            self.assertNotIn('curl | sh',source)
        self.assertIn('python-cryptography',(ROOT/'ANDROID_INSTALL_ONCE.sh').read_text())
        self.assertIn('PyJWT',(ROOT/'ANDROID_INSTALL_ONCE.sh').read_text())

    def test_android_static_manifest_not_required_for_login(self):
        # No remotely exposed HTTP, and no password/token stored in the web tree.
        from vn_server import LoopbackServer
        with self.assertRaises(ValueError):
            LoopbackServer(('0.0.0.0',8765),None)
        for file in (ROOT/'web').rglob('*'):
            if file.is_file() and file.suffix in ('.html','.css','.js'):
                self.assertNotIn('credentials.json',file.read_text(encoding='utf-8'))

class AndroidTransportIntegrationTests(unittest.TestCase):
    def test_phone_runtime_real_http_loopback_offline_contract(self):
        import http.client
        import threading
        import time
        from unittest.mock import patch
        from vn_server import LoopbackServer
        requests = []
        class InspectServer(LoopbackServer):
            def serve_forever(self, **kwargs):
                # Stand up the *real* HTTP server from the phone launcher and test
                # from a real TCP client, without contacting OpenAI or starting a browser.
                ready = threading.Thread(target=super().serve_forever, kwargs=kwargs, daemon=True)
                ready.start()
                try:
                    conn = http.client.HTTPConnection('127.0.0.1', self.server_port, timeout=5)
                    conn.request('GET','/api/state',headers={'Host':f'127.0.0.1:{self.server_port}'})
                    r=conn.getresponse();data=json.loads(r.read());conn.close()
                    requests.append((r.status,data))
                finally:
                    self.shutdown();ready.join(timeout=3)
        with tempfile.TemporaryDirectory() as d, patch.object(ma,'is_termux',return_value=True),patch.object(ma,'LoopbackServer',InspectServer):
            code=ma.serve(offline=True,port=0,offline_store=Path(d)/'private-save',open_browser=lambda url:True)
            self.assertEqual(code,0)
        self.assertEqual(len(requests),1)
        self.assertEqual(requests[0][0],200)
        self.assertEqual(requests[0][1]['world']['revision'],0)
        self.assertFalse(requests[0][1]['connected'])
        self.assertNotIn('access_token',json.dumps(requests[0][1]))

if __name__=='__main__':
    unittest.main()
