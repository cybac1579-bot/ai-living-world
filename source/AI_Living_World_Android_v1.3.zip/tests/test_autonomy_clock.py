"""World clock and offline NPC agency integration tests; all DEMO world only."""
import copy
import json
import sys
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from world_engine import EventStore, WorldError, transition, render_contract
from ai_adapter import build_model_context
from sync_bridge import export_bundle, apply_bundle


def world():
    base = json.loads((ROOT/'examples'/'test_world.json').read_text(encoding='utf-8'))
    base['regions']['DEMO-FOREST']['neighbors'] = ['DEMO-CAMP']
    base['regions']['DEMO-CAMP']['neighbors'] = ['DEMO-FOREST']
    base['npcs']['OFFSCREEN'] = {**copy.deepcopy(base['npcs']['DEMO-GUIDE']),
                               'id':'OFFSCREEN', 'name':'비공개 방문자', 'location':'DEMO-CAMP',
                               'knowledge':['야영지 비밀']} 
    return base


def plan_for(npc='DEMO-GUIDE', *, path=None, interval=10):
    return {'type':'npc_plan_set','npc_id':npc,'goal_id':'G1',
            'path':path or ['DEMO-CAMP','DEMO-FOREST'],
            'interval_minutes':interval}


def prepared():
    s=world()
    return transition(s, None, {'events':[{'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'G1','description':'야영지를 점검하고 귀환한다'}]},mode='npc_tick')


def planned():
    return transition(prepared(),None,{'events':[plan_for()]},mode='npc_tick')


class TestAutonomyClock(unittest.TestCase):
    def test_time_does_not_pass_automatically(self):
        s=planned()
        self.assertEqual(s.get('world_minutes',0),0)
        self.assertEqual(s['npcs']['DEMO-GUIDE']['location'],'DEMO-FOREST')
        self.assertTrue(s['scene']['awaiting_player'])

    def test_minute_threshold_and_return_goal(self):
        s=planned()
        p=transition(s,None,{'events':[{'type':'world_advance','minutes':9}]},mode='world_tick')
        self.assertEqual(p['world_minutes'],9)
        self.assertEqual(p['npcs']['DEMO-GUIDE']['location'],'DEMO-FOREST')
        p=transition(p,None,{'events':[{'type':'world_advance','minutes':1}]},mode='world_tick')
        self.assertEqual(p['npcs']['DEMO-GUIDE']['location'],'DEMO-CAMP')
        self.assertEqual(p['npcs']['DEMO-GUIDE']['goals'][0]['status'],'active')
        p=transition(p,None,{'events':[{'type':'world_advance','minutes':10}]},mode='world_tick')
        self.assertEqual(p['world_minutes'],20)
        self.assertEqual(p['npcs']['DEMO-GUIDE']['location'],'DEMO-FOREST')
        self.assertEqual(p['npcs']['DEMO-GUIDE']['goals'][0]['status'],'completed')
        self.assertIsNone(p['npcs']['DEMO-GUIDE']['autonomy'])
        self.assertEqual([e['minute'] for e in p['world_events']],[10,20,20])

    def test_big_tick_and_replay_equal_small_steps(self):
        a=planned()
        large=transition(a,None,{'events':[{'type':'world_advance','minutes':120}]},mode='world_tick')
        small=copy.deepcopy(a)
        for _ in range(12):
            small=transition(small,None,{'events':[{'type':'world_advance','minutes':10}]},mode='world_tick')
        self.assertEqual(large['world_events'],small['world_events'])
        self.assertEqual(large['npcs'],small['npcs'])
        self.assertEqual(large['world_minutes'],small['world_minutes'])
        self.assertEqual(large['player'],small['player'])
        self.assertEqual(large['scene'],small['scene'])

    def test_same_due_acts_in_stable_id_order(self):
        s=world()
        e=[{'type':'npc_goal_set','npc_id':nid,'goal_id':'G1','description':'왕복'} for nid in ('OFFSCREEN','DEMO-GUIDE')]
        s=transition(s,None,{'events':e},mode='npc_tick')
        s=transition(s,None,{'events':[plan_for(),plan_for('OFFSCREEN',path=['DEMO-FOREST','DEMO-CAMP'])]},mode='npc_tick')
        s=transition(s,None,{'events':[{'type':'world_advance','minutes':10}]},mode='world_tick')
        self.assertEqual([e['npc_id'] for e in s['world_events']],['DEMO-GUIDE','OFFSCREEN'])

    def test_pending_player_choice_never_disappears(self):
        s=planned(); old=copy.deepcopy(s['scene']); player=copy.deepcopy(s['player'])
        t=transition(s,None,{'events':[{'type':'world_advance','minutes':20}]},mode='world_tick')
        self.assertEqual(t['scene'],old)
        self.assertEqual(t['player'],player)
        self.assertEqual(t['revision'],s['revision']+1)

    def test_offscreen_not_visible_in_model_context(self):
        s=world()
        s=transition(s,None,{'events':[{'type':'npc_goal_set','npc_id':'OFFSCREEN','goal_id':'G1','description':'비밀 왕복'}]},mode='npc_tick')
        s=transition(s,None,{'events':[plan_for('OFFSCREEN',path=['DEMO-FOREST','DEMO-CAMP'])]},mode='npc_tick')
        s=transition(s,None,{'events':[{'type':'world_advance','minutes':20}]},mode='world_tick')
        ctx=build_model_context(s,submission={'choice_id':'choice_stay'})
        self.assertNotIn('비밀 왕복',json.dumps(ctx,ensure_ascii=False))
        self.assertEqual(ctx['visible_world_events'],[e for e in s['world_events'] if e['region']=='DEMO-FOREST'])
        contract=render_contract(s)
        self.assertTrue(all(e['region']=='DEMO-FOREST' for e in contract['visible_world_events']))
        self.assertNotIn('야영지 비밀',json.dumps(ctx,ensure_ascii=False))

    def test_unknown_route_or_teleport_refused(self):
        for p in (plan_for(path=['UNKNOWN']), plan_for(path=['DEMO-FOREST']), plan_for(interval=0),plan_for(interval=True)):
            with self.subTest(p=p), self.assertRaises(WorldError):
                transition(prepared(),None,{'events':[p]},mode='npc_tick')

    def test_route_requires_prior_active_goal(self):
        with self.assertRaises(WorldError):
            transition(world(),None,{'events':[plan_for()]},mode='npc_tick')

    def test_second_active_plan_refused(self):
        with self.assertRaises(WorldError):
            transition(planned(),None,{'events':[plan_for()]},mode='npc_tick')

    def test_cancel_stops_progress(self):
        s=planned()
        s=transition(s,None,{'events':[{'type':'npc_plan_cancel','npc_id':'DEMO-GUIDE'}]},mode='npc_tick')
        s=transition(s,None,{'events':[{'type':'world_advance','minutes':40}]},mode='world_tick')
        self.assertEqual(s['npcs']['DEMO-GUIDE']['location'],'DEMO-FOREST')
        self.assertEqual(s['npcs']['DEMO-GUIDE']['goals'][0]['status'],'active')
        self.assertEqual(s['world_events'],[])

    def test_complete_goal_terminates_route(self):
        s=transition(planned(),None,{'events':[{'type':'npc_goal_complete','npc_id':'DEMO-GUIDE','goal_id':'G1'}]},mode='npc_tick')
        self.assertIsNone(s['npcs']['DEMO-GUIDE']['autonomy'])
        self.assertEqual(s['npcs']['DEMO-GUIDE']['goals'][0]['status'],'completed')

    def test_model_cannot_advance_clock(self):
        for mode, sub in (('player',{'choice_id':'choice_stay'}),('npc_tick',None)):
            with self.subTest(mode=mode),self.assertRaises(WorldError):
                transition(planned(),sub,{'events':[{'type':'world_advance','minutes':30}]},mode=mode)

    def test_clock_validated_and_no_player_actions(self):
        for minutes in (0,-1,1441,True,'ten',None):
            with self.subTest(minutes=minutes), self.assertRaises(WorldError):
                transition(planned(),None,{'events':[{'type':'world_advance','minutes':minutes}]},mode='world_tick')
        with self.assertRaises(WorldError):
            transition(planned(),None,{'events':[{'type':'world_advance','minutes':10}], 'scene':planned()['scene']},mode='world_tick')
        with self.assertRaises(WorldError):
            transition(planned(),{'free_text':'가겠다'},{'events':[{'type':'world_advance','minutes':10}]},mode='world_tick')

    def test_stale_world_tick_refused_and_replay(self):
        with tempfile.TemporaryDirectory() as tmp:
            st=EventStore(Path(tmp)/'a');st.create(world())
            a=st.commit(0,None,{'events':[{'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'G1','description':'순찰'}]},mode='npc_tick')
            a=st.commit(1,None,{'events':[plan_for()]},mode='npc_tick')
            a=st.advance_time(2,120)
            self.assertEqual(a['world_minutes'],120)
            self.assertEqual(a,st.load())
            with self.assertRaisesRegex(WorldError,'stale'):
                st.advance_time(2,5)
            with self.assertRaisesRegex(WorldError,'invalid'):
                st.advance_time(3,999999)
            self.assertEqual(st.load()['revision'],3)
            archive=Path(tmp)/'bundle.zip'
            export_bundle(st,archive)
            other=EventStore(Path(tmp)/'b');apply_bundle(other,archive)
            self.assertEqual(other.load(),st.load())
            self.assertEqual(other.load()['world_minutes'],120)

    def test_cli_advance_time_without_paid_api(self):
        import subprocess
        with tempfile.TemporaryDirectory() as tmp:
            st=EventStore(Path(tmp)/'a'); st.create(world())
            p=st.commit(0,None,{'events':[{'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'G1','description':'왕복'}]},mode='npc_tick')
            st.commit(1,None,{'events':[plan_for()]},mode='npc_tick')
            output=subprocess.run([sys.executable,'cli.py','advance-time','--store',str(st.dir),'--minutes','20'], cwd=ROOT, capture_output=True,text=True)
            self.assertEqual(output.returncode,0,output.stderr)
            response=json.loads(output.stdout)
            self.assertEqual(response['world_minutes'],20)
            self.assertEqual(st.load()['npcs']['DEMO-GUIDE']['location'],'DEMO-FOREST')
            self.assertEqual(st.load()['revision'],3)

    def test_visible_event_window_expires(self):
        s=planned()
        s=transition(s,None,{'events':[{'type':'world_advance','minutes':20}]},mode='world_tick')
        self.assertTrue(render_contract(s)['visible_world_events'])
        s=transition(s,None,{'events':[{'type':'world_advance','minutes':121}]},mode='world_tick')
        self.assertEqual(render_contract(s)['visible_world_events'],[])

    def test_world_news_cannot_smuggle_private_fields(self):
        from world_engine import validate_state
        a=planned()
        a=transition(a,None,{'events':[{'type':'world_advance','minutes':20}]},mode='world_tick')
        a['world_events'][0]['secret']='다른 NPC의 비밀 정보'
        with self.assertRaises(WorldError):validate_state(a)

    def test_invalid_neighbor_data_fails_cleanly(self):
        from world_engine import validate_state
        a=world()
        a['regions']['DEMO-CAMP']['neighbors']=[{'bad':'object'}]
        with self.assertRaises(WorldError):validate_state(a)

    def test_legacy_v04_world_replays_without_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            st=EventStore(tmp);st.create(json.loads((ROOT/'examples'/'test_world.json').read_text(encoding='utf-8')))
            st.commit(0,None,{'events':[{'type':'npc_mood','npc_id':'DEMO-GUIDE','mood':'호기심'}]},mode='npc_tick')
            self.assertNotIn('world_minutes',st.load())
            self.assertEqual(st.load()['revision'],1)

    def test_forged_time_event_in_journal_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            st=EventStore(tmp);st.create(world());st.advance_time(0,10)
            j=json.loads(st.journal.read_text(encoding='utf-8'))
            j['model_output']['events'][0]['minutes']=1441
            st.journal.write_text(json.dumps(j,ensure_ascii=False)+'\n',encoding='utf-8')
            with self.assertRaises(WorldError):st.load()

if __name__=='__main__': unittest.main()
