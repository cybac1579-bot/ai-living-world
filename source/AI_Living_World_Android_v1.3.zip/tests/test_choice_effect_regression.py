"""Regression for real PC log: 2nd GPT turn failed with invalid choice effect.

Reproduces a two-turn world flow *without* contacting OpenAI: forest ->
camp -> inspect camp outskirts, where model labels a future choice with
its own read-only effect type instead of the engine's `none` type.
"""
import copy
import json
import tempfile
import unittest
from pathlib import Path

from live_story import initial_demo_store, run_turn, verify_proposed_turn, build_request
from world_engine import WorldError

SAMPLE = Path(__file__).resolve().parents[1] / "examples" / "live_demo_world.json"


def camp_scene():
    return {
        'events': [],
        'scene': {
            'id': 'DEMO-CAMP-V1',
            'beats': [{'kind': 'narration', 'text': '화덕과 텅 빈 공터가 보인다.'}],
            'choices': [
                {'id': 'inspect_fire', 'label': '화덕을 살펴본다', 'effect': {'type': 'none'}},
                {'id': 'survey_camp', 'label': '공터 가장자리를 둘러본다', 'effect': {'type': 'none'}},
                {'id': 'return_forest', 'label': '테스트 숲으로 돌아간다',
                 'effect': {'type': 'player_move', 'destination': 'DEMO-FOREST'}},
            ],
            'awaiting_player': True,
            'event_image_id': None,
            'character_image_id': None,
        },
    }


def outskirts_scene():
    return {
        'events': [],
        'scene': {
            'id': 'DEMO-CAMP-V2',
            'beats': [
                {'kind': 'narration', 'text': '공터 가장자리에는 낡은 발자국이 이어져 있다.'},
                {'kind': 'narration', 'text': '조사할지 이동할지는 플레이어가 정한다.'},
            ],
            'choices': [
                {'id': 'footprints', 'label': '발자국을 자세히 살펴본다',
                 'effect': {'type': 'inspect_area', 'target': 'footprints'}},
                {'id': 'edge', 'label': '주변을 조금 더 둘러본다',
                 'effect': {'type': 'look_around'}},
                {'id': 'return_forest', 'label': '숲으로 돌아간다',
                 'effect': {'type': 'player_move', 'destination': 'DEMO-FOREST'}},
            ],
            'awaiting_player': True,
            'event_image_id': None,
            'character_image_id': None,
        },
    }


class RealWorldChoiceEffectRegression(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = initial_demo_store(Path(self.temp.name) / 'save', sample_file=SAMPLE)

    def _to_camp(self):
        result = run_turn(self.store, submission={'choice_id': 'choice_move'},
                          model='m', token='test-no-network',
                          sender=lambda *args: json.dumps(camp_scene(), ensure_ascii=False))
        self.assertEqual(result['revision'], 1)
        self.assertEqual(result['region']['id'], 'DEMO-CAMP')

    def test_two_turn_real_log_scenario_journal_replay(self):
        self._to_camp()
        result = run_turn(self.store, submission={'choice_id': 'survey_camp'},
                          model='m', token='test-no-network',
                          sender=lambda *args: json.dumps(outskirts_scene(), ensure_ascii=False))
        self.assertEqual(result['revision'], 2)
        self.assertEqual(result['region']['id'], 'DEMO-CAMP')
        state = self.store.load()
        self.assertEqual(state['scene']['choices'][0]['effect'], {'type': 'none'})
        self.assertEqual(state['scene']['choices'][1]['effect'], {'type': 'none'})
        self.assertEqual(state['scene']['choices'][2]['effect'],
                         {'type': 'player_move', 'destination': 'DEMO-FOREST'})
        self.assertEqual(state['last_player_input']['text'], '공터 가장자리를 둘러본다')
        self.store.cache.unlink()
        self.assertEqual(self.store.load(), state)

    def test_unknown_mutating_effect_remains_rejected_no_commit(self):
        self._to_camp()
        bad = outskirts_scene()
        bad['scene']['choices'][0]['effect'] = {'type': 'change_inventory', 'item': 'money'}
        with self.assertRaisesRegex(WorldError, 'invalid choice effect'):
            run_turn(self.store, submission={'choice_id': 'survey_camp'},
                     model='m', token='test-no-network',
                     sender=lambda *args: json.dumps(bad, ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'], 1)

    def test_player_move_destination_does_not_get_normalized(self):
        self._to_camp()
        bad = outskirts_scene()
        bad['scene']['choices'][0]['effect'] = {'type': 'player_move', 'destination': 'UNKNOWN'}
        with self.assertRaises(WorldError):
            run_turn(self.store, submission={'choice_id': 'survey_camp'},
                     model='m', token='test-no-network',
                     sender=lambda *args: json.dumps(bad, ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'], 1)

    def test_read_only_effect_with_hidden_mutation_not_normalized(self):
        self._to_camp()
        bad = outskirts_scene()
        bad['scene']['choices'][0]['effect']['amount'] = 999
        with self.assertRaisesRegex(WorldError, 'invalid choice effect'):
            run_turn(self.store, submission={'choice_id': 'survey_camp'},
                     model='m', token='test-no-network',
                     sender=lambda *args: json.dumps(bad, ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'], 1)

    def test_nonstring_effect_type_refuses_cleanly(self):
        self._to_camp()
        bad = outskirts_scene()
        bad['scene']['choices'][0]['effect'] = {'type': ['inspect']}
        with self.assertRaisesRegex(WorldError, 'invalid choice effect'):
            run_turn(self.store, submission={'choice_id': 'survey_camp'},
                     model='m', token='test-no-network',
                     sender=lambda *args: json.dumps(bad, ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'], 1)

    def test_normalization_does_not_mutate_original_player_input(self):
        self._to_camp()
        raw=json.dumps(outskirts_scene(), ensure_ascii=False)
        proposal=verify_proposed_turn(self.store.load(), {'choice_id':'survey_camp'}, raw)
        self.assertEqual(proposal['scene']['choices'][0]['effect']['type'], 'none')
        self.assertEqual(self.store.load()['revision'], 1)

    def test_prompt_prohibits_unregistered_choice_effect_types(self):
        data=build_request('m', {'world_id': 'DEMO', 'local_npcs': []})
        self.assertIn('inspect', data['instructions'])
        self.assertIn('player_move', data['instructions'])
        self.assertIn('none', data['instructions'])

    def test_uncorrupted_prior_world_record_still_loads(self):
        self._to_camp()
        self.assertEqual(self.store.load()['revision'], 1)
        self.assertEqual(self.store.load()['scene']['choices'][1]['id'], 'survey_camp')


if __name__ == '__main__':
    unittest.main()

class MalformedReadOnlyChoiceRegression(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store=initial_demo_store(Path(self.temp.name)/'save',sample_file=SAMPLE)

    def test_none_with_safe_hint_is_canonicalized(self):
        model=camp_scene()
        model['scene']['choices'][0]['effect']={'type':'none','target':'hearth'}
        out=run_turn(self.store,submission={'choice_id':'choice_move'},model='m',token='oauth',
                     sender=lambda *args:json.dumps(model,ensure_ascii=False))
        self.assertEqual(out['revision'],1)
        self.assertEqual(self.store.load()['scene']['choices'][0]['effect'],{'type':'none'})

    def test_target_hint_cannot_contain_hidden_non_string_data(self):
        model=camp_scene()
        model['scene']['choices'][0]['effect']={'type':'inspect','target':{'move_to':'DEMO-FOREST'}}
        with self.assertRaisesRegex(WorldError,'invalid choice effect'):
            run_turn(self.store,submission={'choice_id':'choice_move'},model='m',token='oauth',
                     sender=lambda *args:json.dumps(model,ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'],0)

    def test_no_automatic_second_model_call_after_rejection(self):
        model=camp_scene()
        model['scene']['choices'][0]['effect']={'type':'increase_player_stat','amount':100}
        call_count=[0]
        def send(*args):
            call_count[0]+=1
            return json.dumps(model,ensure_ascii=False)
        with self.assertRaises(WorldError):
            run_turn(self.store,submission={'choice_id':'choice_move'},model='m',token='oauth',sender=send)
        self.assertEqual(call_count[0],1)
        self.assertEqual(self.store.load()['revision'],0)
