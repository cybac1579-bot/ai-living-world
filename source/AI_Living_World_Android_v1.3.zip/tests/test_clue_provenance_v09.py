"""Tests for explicit clue transfer and anti-stagnation context. All local, no GPT calls."""
import copy
import json
import tempfile
import unittest
from pathlib import Path

from world_engine import EventStore, WorldError, resolve_explicit_clue_share, transition
from ai_adapter import build_model_context
from live_story import run_turn, build_request

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples' / 'live_demo_world.json'
CLUE_ID = 'CLUE-DEMO-FOOTPRINT-001'


def reply(state, *, events=None, choices=None, label='숲의 상황이 변한다'):
    return {'events': events or [], 'scene': {
        'id': f'DEMO-NEXT-{state["revision"]}',
        'beats': [{'kind': 'narration', 'text': label}],
        'choices': choices if choices is not None else [
            {'id': 'wait', 'label': '잠시 기다린다', 'effect': {'type': 'none'}},
            {'id': 'tell', 'label': '시험 안내인에게 발자국을 알려준다', 'effect': {'type': 'none'}}],
        'awaiting_player': True, 'event_image_id': None, 'character_image_id': None}}


class ProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = EventStore(self.tmp.name)
        self.start = json.loads(SOURCE.read_text(encoding='utf8'))
        self.store.create(self.start)

    def clue(self):
        self.store.commit(0, {'choice_id': 'choice_stay'},
            reply(self.start, events=[{'type': 'clue_discover', 'id': CLUE_ID,
                'region': 'DEMO-FOREST', 'title': '신선한 발자국',
                'detail': '화덕 옆에서 숲길로 이어지는 새로운 발자국'}]))
        return self.store.load()

    def share(self, submission=None, event=None):
        return self.store.commit(1, submission or {'free_text': '시험 안내인에게 발자국을 알려준다'},
            reply(self.store.load(), events=[event or {'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID}]))

    def test_player_explicitly_shares_a_discovered_clue(self):
        self.clue()
        final = self.share()
        self.assertEqual(final['revision'], 2)
        self.assertEqual(len(final['npcs']['DEMO-GUIDE']['knowledge']), 2)
        self.assertIn(f'단서 [{CLUE_ID}]:', final['npcs']['DEMO-GUIDE']['knowledge'][-1])
        self.assertEqual(self.store.load(), final)
        self.store.cache.unlink()
        self.assertEqual(self.store.load(), final)

    def test_explicit_choice_label_can_authorize_share(self):
        self.clue()
        final = self.share(submission={'choice_id': 'tell'})
        self.assertEqual(final['revision'], 2)
        self.assertIn(CLUE_ID, final['npcs']['DEMO-GUIDE']['knowledge'][-1])

    def test_context_includes_share_only_for_explicit_action(self):
        state = self.clue()
        yes = build_model_context(state, submission={'free_text': '시험 안내인에게 발자국을 알려준다'})
        self.assertEqual(yes['authorized_clue_share'], {'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID})
        by_choice = build_model_context(state, submission={'choice_id': 'tell'})
        self.assertEqual(by_choice['authorized_clue_share'], yes['authorized_clue_share'])
        no = build_model_context(state, submission={'choice_id': 'wait'})
        self.assertIsNone(no['authorized_clue_share'])
        self.assertIn('authorized_clue_share', build_request('mock', yes)['instructions'])

    def test_free_text_references_but_does_not_share(self):
        state = self.clue()
        for sentence in ('안내인에게 발자국을 알려줄까?',
                         '안내인에게 발자국을 알려주지 않는다',
                         '시험 안내인에게 발자국을 물어본다',
                         '시험 안내인에게 발자국을 알려준다는 이야기를 들었다'):
            with self.subTest(sentence=sentence):
                self.assertIsNone(resolve_explicit_clue_share(state, sentence))

    def test_player_did_not_speak_npc_does_not_know(self):
        self.clue()
        with self.assertRaisesRegex(WorldError, 'unauthorized clue transfer'):
            self.share(submission={'free_text': '숲길을 계속 살펴본다'})
        self.assertEqual(self.store.load()['revision'], 1)
        self.assertEqual(len(self.store.load()['npcs']['DEMO-GUIDE']['knowledge']), 1)

    def test_clue_id_cannot_be_invented(self):
        self.clue()
        with self.assertRaisesRegex(WorldError, 'undiscovered clue'):
            self.share(event={'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': 'CLUE-FAKE'})

    def test_cannot_share_with_faraway_npc(self):
        self.clue()
        state = self.store.load()
        state['npcs']['DEMO-GUIDE']['location'] = 'DEMO-CAMP'
        self.assertIsNone(resolve_explicit_clue_share(state, '시험 안내인에게 발자국을 알려준다'))
        with self.assertRaises(WorldError):
            transition(state, {'free_text': '시험 안내인에게 발자국을 알려준다'},
                reply(state, events=[{'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID}]))

    def test_repeated_sharing_is_rejected(self):
        self.clue()
        self.share()
        with self.assertRaisesRegex(WorldError, 'already shared'):
            self.store.commit(2, {'free_text': '시험 안내인에게 발자국을 알려준다'},
                reply(self.store.load(), events=[{'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID}]))
        self.assertEqual(self.store.load()['revision'], 2)

    def test_npc_tick_cannot_share_player_clue(self):
        self.clue()
        with self.assertRaisesRegex(WorldError, 'NPC tick cannot fake'):
            self.store.commit(1, None, {'events': [{'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID}]}, mode='npc_tick')

    def test_model_extra_forged_fields_rejected(self):
        self.clue()
        with self.assertRaisesRegex(WorldError, 'unknown model event field'):
            self.share(event={'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID,
                              'player_mood': '감격'})

    def test_ambiguous_two_clues_not_shared(self):
        state = self.clue()
        state['discoveries'].append({'id': 'CLUE-OTHER', 'region': 'DEMO-FOREST',
            'title': '사라진 발자국', 'detail': '흔적이 지워졌다', 'revision': 1})
        self.assertIsNone(resolve_explicit_clue_share(state, '시험 안내인에게 발자국을 알려준다'))

    def test_repeating_action_without_new_clue_has_pace_warning(self):
        s = self.clue()
        s['player_action_history'] = [
            {'revision': 1, 'region': 'DEMO-FOREST', 'text': '화덕을 살펴본다', 'kind': 'free_text'},
            {'revision': 2, 'region': 'DEMO-FOREST', 'text': '화덕을 살펴본다', 'kind': 'free_text'}]
        s['revision'] = 2
        c = build_model_context(s, submission={'free_text': '자세히 둘러본다'})
        self.assertFalse(c['repeated_no_discovery'])
        s['discoveries'] = []
        c2 = build_model_context(s, submission={'free_text': '자세히 둘러본다'})
        self.assertTrue(c2['repeated_no_discovery'])

    def test_invalid_share_does_not_bill_repeated_model_request(self):
        self.clue()
        requests = []
        def model(token, slug, ctx):
            requests.append(ctx)
            return json.dumps(reply(self.store.load(), events=[
                {'type': 'clue_share', 'npc_id': 'DEMO-GUIDE', 'clue_id': CLUE_ID}]), ensure_ascii=False)
        with self.assertRaisesRegex(WorldError, 'unauthorized clue transfer'):
            run_turn(self.store, submission={'free_text': '나는 아무것도 말하지 않는다'}, model='mock', token='test', sender=model)
        self.assertEqual(len(requests), 1)
        self.assertEqual(self.store.load()['revision'], 1)


if __name__ == '__main__':
    unittest.main()
