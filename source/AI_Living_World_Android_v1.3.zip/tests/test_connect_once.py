import contextlib
import io
import json
import tempfile
import urllib.error
import unittest
from pathlib import Path
from unittest.mock import patch

from connect_once import choose_model, connect_once, send_probe
from siwc_client import SIWCError

class FakeSSE:
    def __init__(self, events):
        self.lines=events
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def __iter__(self): return iter(self.lines)

def completed(text='연결 성공!'):
    return FakeSSE([
        b'data: '+json.dumps({'type':'response.output_text.delta','delta':text},ensure_ascii=False).encode()+b'\n',
        b'data: '+json.dumps({'type':'response.completed','response':{'status':'completed','output':[]}}).encode()+b'\n',
        b'data: [DONE]\n'])

class ConnectTests(unittest.TestCase):
    def test_real_probe_requires_oauth_token(self):
        with self.assertRaises(SIWCError): send_probe('','any')
    def test_probe_completes_with_correct_endpoint_and_no_api_key(self):
        def fake_open(req, timeout):
            self.assertEqual(req.full_url,'https://api.openai.com/v1/responses')
            self.assertEqual(req.get_method(),'POST')
            body=json.loads(req.data)
            self.assertTrue(body['stream']); self.assertFalse(body['store'])
            self.assertNotIn('api_key',body)
            self.assertIsInstance(body['input'], list)
            self.assertEqual(body['input'][0]['role'],'user')
            self.assertIsInstance(body['input'][0]['content'], str)
            self.assertEqual(body['instructions'],'연결 확인용 테스트야. 한국어로 한 문장으로 간결하게 대답해.')
            self.assertEqual(req.get_header('Authorization'),'Bearer oauth-test-token')
            return completed('연결 성공!')
        self.assertEqual(send_probe('oauth-test-token','test-model',urlopen=fake_open),'연결 성공!')
    def test_http400_supported_capability_error_gives_safe_code_param(self):
        import io
        raw=json.dumps({'error':{'code':'subscription_sharing_unsupported_capability',
                                   'param':'input', 'message':'SECRET-ABC-123 / raw request may include user text'}}).encode()
        def f(req,timeout):
            raise urllib.error.HTTPError(req.full_url,400,'Bad Request',{'x-request-id':'req_testAB123'},io.BytesIO(raw))
        with self.assertRaises(SIWCError) as context:
            send_probe('oauth-test-secret','gpt-6.2-sol',urlopen=f)
        info=str(context.exception)
        self.assertIn('HTTP 400',info)
        self.assertIn('subscription_sharing_unsupported_capability',info)
        self.assertIn('param=input',info)
        self.assertIn('request_id=req_testAB123',info)
        self.assertNotIn('SECRET',info)
        self.assertNotIn('oauth-test-secret',info)
        self.assertNotIn('raw request',info)

    def test_http400_untrusted_error_fields_suppressed(self):
        import io
        raw=json.dumps({'error':{'code':'BEARER_SECRET_NOT_WHITELISTED',
                                   'param':'password=secrets', 'message':'token-DO-NOT-LEAK'}}).encode()
        def f(req,timeout):
            raise urllib.error.HTTPError(req.full_url,400,'Bad Request',{},io.BytesIO(raw))
        with self.assertRaises(SIWCError) as context:
            send_probe('oauth-test-secret','test-model',urlopen=f)
        info=str(context.exception)
        self.assertIn('HTTP 400',info)
        for sensitive in ('password','SECRET','token-DO-NOT-LEAK','oauth-test-secret'):
            self.assertNotIn(sensitive,info)

    def test_http400_non_json_body_still_safe(self):
        import io
        def f(req,timeout):
            raise urllib.error.HTTPError(req.full_url,400,'Bad Request',{},io.BytesIO(b'<html>server bad request</html>'))
        with self.assertRaisesRegex(SIWCError,'HTTP 400'):
            send_probe('oauth-test-secret','test-model',urlopen=f)

    def test_missing_completion_does_not_report_success(self):
        def f(req,timeout): return FakeSSE([b'data: '+json.dumps({'type':'response.output_text.delta','delta':'partial'}).encode()+b'\n'])
        with self.assertRaisesRegex(SIWCError,'without response.completed'):
            send_probe('token','model',urlopen=f)
    def test_model_cancel(self):
        self.assertIsNone(choose_model([{'slug':'a','display_name':'A'}],lambda _: '0'))
    def test_login_not_started_without_explicit_user_confirmation(self):
        with tempfile.TemporaryDirectory() as folder:
            with contextlib.redirect_stdout(io.StringIO()):
                result=connect_once(private_dir=Path(folder),input_func=lambda _:'n',sign_in=lambda _:self.fail('unexpected login'))
            self.assertEqual(result['outcome'],'cancelled_before_login')
    def test_complete_approved_oauth_probe_without_real_network(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)
            creds={'access_token':'oauth-token','refresh_token':'ref','client_id':'c','scopes':['chatgpt.tokens.use.direct'],'expires_at':9999999999}
            def fake_sign_in(_):
                (p/'credentials.json').write_text(json.dumps(creds),encoding='utf-8')
                return {'plan_usage_permission':True}
            args=iter(['y','1','y'])
            logs=io.StringIO()
            with patch('connect_once.read_credentials',return_value=creds),contextlib.redirect_stdout(logs):
                result=connect_once(private_dir=p,input_func=lambda _:next(args),sign_in=fake_sign_in,
                        models_getter=lambda _: [{'slug':'test-model','display_name':'Test Model'}],
                        sender=lambda token,slug: '테스트 성공')
            self.assertEqual(result['outcome'],'live_model_response_completed')
            self.assertNotIn('oauth-token',logs.getvalue());self.assertNotIn('ref',logs.getvalue())
    def test_no_inference_if_no_sharing_scope(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'credentials.json').write_text('{}')
            creds={'access_token':'token','scopes':[],'expires_at':9999999999}
            with patch('connect_once.read_credentials',return_value=creds),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(SIWCError):
                    connect_once(private_dir=p,input_func=lambda _:'y',sender=lambda *_:self.fail('should not infer'))

if __name__=='__main__': unittest.main()
