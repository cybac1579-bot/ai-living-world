import json, tempfile, unittest
from pathlib import Path
from world_engine import EventStore, WorldError, transition, render_contract, select_image
ROOT=Path(__file__).resolve().parents[1]

def read(n):return json.loads((ROOT/'examples'/n).read_text(encoding='utf-8'))

class EngineTests(unittest.TestCase):
    def setUp(self):
        self.state=read('test_world.json')
        self.scene=read('ai_scene_after_choice.json')
    def test_player_action_cannot_be_invented(self):
        with self.assertRaises(WorldError):transition(self.state,None,self.scene)
    def test_choice_commits_player_move(self):
        x=transition(self.state,{'choice_id':'choice_move'},self.scene)
        self.assertEqual(x['player']['location'],'DEMO-CAMP')
        self.assertEqual(self.state['player']['location'],'DEMO-FOREST')
        self.assertEqual(x['npcs']['DEMO-GUIDE']['mood'],'호기심')
        self.assertEqual(x['last_player_input']['choice_id'],'choice_move')
    def test_unknown_choice_rejected(self):
        with self.assertRaises(WorldError):transition(self.state,{'choice_id':'fake'},self.scene)
    def test_forbidden_ai_player_action_rejected(self):
        with self.assertRaises(WorldError):transition(self.state,{'choice_id':'choice_move'},{'events':[{'type':'player_move','destination':'DEMO-CAMP'}],'scene':self.scene['scene']})
    def test_model_cannot_write_player_or_history(self):
        with self.assertRaises(WorldError):transition(self.state,{'choice_id':'choice_stay'},{'events':[],'scene':self.scene['scene'],'player':{'location':'DEMO-CAMP'}})
    def test_npc_tick_without_input_and_block_scene_override_while_pending(self):
        x=transition(self.state,None,{'events':[{'type':'npc_mood','npc_id':'DEMO-GUIDE','mood':'불안함'}]},mode='npc_tick')
        self.assertEqual(x['player']['location'],'DEMO-FOREST')
        self.assertEqual(x['scene'],self.state['scene'])
        with self.assertRaises(WorldError):transition(self.state,None,self.scene,mode='npc_tick')
    def test_image_priority_and_fallback(self):
        self.assertEqual(select_image(self.state)['kind'],'region')
        self.state['scene']['character_image_id']='DEMO-IMG-GUIDE'
        self.assertEqual(select_image(self.state)['kind'],'character')
        self.state['scene']['event_image_id']='DEMO-IMG-EVENT'
        self.assertEqual(select_image(self.state)['kind'],'event')
        self.state['scene']['event_image_id']='no-file'
        self.assertEqual(select_image(self.state)['kind'],'character')
        self.state['scene']['character_image_id']=None
        self.assertTrue(select_image(self.state)['fallback'])
    def test_dialogue_name_color_and_no_player_voice(self):
        o=render_contract(self.state)
        self.assertEqual(o['beats'][1]['speaker']['name_color'],'#345D91')
        s=read('ai_scene_after_choice.json');s['scene']['beats'][1]['speaker_id']='PLAYER'
        with self.assertRaises(WorldError):transition(self.state,{'choice_id':'choice_move'},s)
    def test_free_text_does_not_invent_effects(self):
        x=transition(self.state,{'free_text':'숲 주변을 관찰한다'},self.scene)
        self.assertEqual(x['player']['location'],'DEMO-FOREST')
        self.assertEqual(x['last_player_input']['free_text'],'숲 주변을 관찰한다')
    def test_journal_save_replay_after_cache_deleted(self):
        with tempfile.TemporaryDirectory() as d:
            s=EventStore(d);s.create(self.state)
            x=s.commit(0,{'choice_id':'choice_move'},self.scene)
            self.assertEqual(s.load(),x)
            Path(d,'state.json').unlink()
            self.assertEqual(s.load(),x)
    def test_stale_revision_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            s=EventStore(d);s.create(self.state)
            s.commit(0,{'choice_id':'choice_stay'},self.scene)
            with self.assertRaisesRegex(WorldError,'stale revision'):s.commit(0,{'choice_id':'choice_move'},self.scene)
    def test_journal_tamper_detection(self):
        with tempfile.TemporaryDirectory() as d:
            s=EventStore(d);s.create(self.state)
            s.commit(0,{'choice_id':'choice_stay'},self.scene)
            p=Path(d,'events.jsonl'); p.write_text(p.read_text(encoding='utf-8').replace('호기심','거짓상태'),encoding='utf-8')
            with self.assertRaisesRegex(WorldError,'tampered'):s.load()
    def test_duplicate_npc_knowledge_not_repeated(self):
        event={'events':[{'type':'npc_learn','npc_id':'DEMO-GUIDE','fact':'숲의 출구는 동쪽에 있다'}], 'scene':self.scene['scene']}
        x=transition(self.state,{'choice_id':'choice_move'},event)
        self.assertEqual(x['npcs']['DEMO-GUIDE']['knowledge'].count('숲의 출구는 동쪽에 있다'),1)
    def test_invalid_npc_knowledge(self):
        bad={'events':[{'type':'npc_learn','npc_id':'NONEXISTENT','fact':'foo'}], 'scene':self.scene['scene']}
        with self.assertRaises(WorldError):transition(self.state,{'choice_id':'choice_move'},bad)

if __name__=='__main__':unittest.main()
