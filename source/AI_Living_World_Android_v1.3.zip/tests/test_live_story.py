import io
import json
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

from live_story import (build_request, request_story, authorized_catalog,
                        verify_proposed_turn, run_turn, initial_demo_store)
from world_engine import WorldError
from siwc_client import SIWCError

EXAMPLE=Path(__file__).resolve().parents[1]/'examples'/'test_world.json'


class FakeSSE:
    def __init__(self, text=None, *, completed=True):
        self.text=text
        self.completed=completed
    def __enter__(self):return self
    def __exit__(self,*a):return False
    def __iter__(self):
        yield b'data: '+json.dumps({'type':'response.output_text.delta','delta':self.text},ensure_ascii=False).encode()+b'\n'
        if self.completed:
            yield b'data: '+json.dumps({'type':'response.completed','response':{'status':'completed','output':[]}}).encode()+b'\n'
        yield b'data: [DONE]\n'


def proposal(scene_id='NEXT'):
    return {'events':[{'type':'npc_mood','npc_id':'DEMO-GUIDE','mood':'경계'}],
            'scene':{'id':scene_id,'beats':[
                  {'kind':'narration','text':'나뭇잎 사이로 햇살이 천천히 흔들린다.'},
                  {'kind':'dialogue','speaker_id':'DEMO-GUIDE','text':'먼저 갈지, 이곳에 남을지 네가 결정해.'}],
                     'choices':[{'id':'continue','label':'나무 사이를 살펴본다','effect':{'type':'none'}}],
                     'awaiting_player':True,'event_image_id':None,'character_image_id':None}}


class StoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store=initial_demo_store(Path(self.tmp.name)/'demo',sample_file=EXAMPLE)
        self.state=self.store.load()

    def test_request_contract_matches_successful_connection(self):
        context={'world_id':'DEMO-1','local_npcs':[],'player_submission':{'choice_id':'choice_stay'}}
        data=build_request('gpt-6.2-sol',context)
        self.assertIsInstance(data['input'],list)
        self.assertEqual(data['input'][0]['role'],'user')
        self.assertEqual(data['store'],False)
        self.assertEqual(data['stream'],True)
        self.assertNotIn('api_key',json.dumps(data))
        self.assertIn('beats',data['instructions'])

    def test_successful_sse_oauth_only(self):
        result=json.dumps(proposal(),ensure_ascii=False)
        def fake_open(req,timeout):
            self.assertEqual(req.full_url,'https://api.openai.com/v1/responses')
            self.assertEqual(req.get_header('Authorization'),'Bearer oauth-test')
            self.assertEqual(req.get_method(),'POST')
            data=json.loads(req.data)
            self.assertIsInstance(data['input'],list)
            self.assertFalse(data['store'])
            return FakeSSE(result)
        out=request_story('oauth-test','model',{'world_id':'DEMO-1'},urlopen=fake_open)
        self.assertEqual(out,result)

    def test_incomplete_stream_refuses_state_change(self):
        def fake_open(req,timeout):return FakeSSE('{}',completed=False)
        with self.assertRaises(SIWCError):
            request_story('oauth','model',{'world_id':'DEMO-1'},urlopen=fake_open)
        self.assertEqual(self.store.load()['revision'],0)

    def test_error_redacts_server_body_and_bearer(self):
        def fake_open(req,timeout):
            raw=b'{"error":{"message":"SECRET TOKEN FROM SERVER","code":"invalid_request_error","param":"input"}}'
            raise urllib.error.HTTPError(req.full_url,400,'Bad Request',{},io.BytesIO(raw))
        with self.assertRaises(SIWCError) as e:
            request_story('oauth-super-secret','model',{'world_id':'DEMO-1'},urlopen=fake_open)
        self.assertIn('param=input',str(e.exception))
        self.assertNotIn('SECRET',str(e.exception))
        self.assertNotIn('oauth-super-secret',str(e.exception))

    def test_model_narration_and_npc_mood_committed(self):
        raw=json.dumps(proposal(),ensure_ascii=False)
        rendered=run_turn(self.store,submission={'choice_id':'choice_stay'},
                          model='m',token='oauth',sender=lambda *args:raw)
        self.assertEqual(rendered['revision'],1)
        self.assertEqual(rendered['beats'][1]['speaker']['name'],'시험 안내인')
        self.assertEqual(rendered['dialogue_background'],'#EAF1FB')
        self.assertEqual(self.store.load()['npcs']['DEMO-GUIDE']['mood'],'경계')
        self.assertEqual(self.store.load()['player']['location'],'DEMO-FOREST')
        self.assertEqual(len(self.store.journal.read_text(encoding='utf-8').splitlines()),1)
        self.store.cache.unlink()
        self.assertEqual(self.store.load()['revision'],1)

    def test_invalid_json_zero_commit(self):
        with self.assertRaises(WorldError):
            run_turn(self.store,submission={'choice_id':'choice_stay'},
                     model='m',token='oauth',sender=lambda *args:'```json\n{}\n```')
        self.assertEqual(self.store.load()['revision'],0)
        self.assertFalse(self.store.journal.read_text().strip())

    def test_remote_npc_dialogue_rejected(self):
        scene=proposal(); scene['events']=[]
        raw=json.dumps(scene,ensure_ascii=False)
        with self.assertRaisesRegex(WorldError,'다른 지역'):
            run_turn(self.store,submission={'choice_id':'choice_move'},
                     model='m',token='oauth',sender=lambda *args:raw)
        self.assertEqual(self.store.load()['revision'],0)

    def test_unregistered_cutscene_rejected(self):
        doc=proposal();doc['scene']['event_image_id']='made-up-event'
        with self.assertRaisesRegex(WorldError,'이미지'):
            run_turn(self.store,submission={'choice_id':'choice_stay'},
                     model='m',token='oauth',sender=lambda *args:json.dumps(doc,ensure_ascii=False))
        self.assertEqual(self.store.load()['revision'],0)

    def test_free_text_does_not_mysteriously_move_player(self):
        raw=json.dumps(proposal(),ensure_ascii=False)
        run_turn(self.store,submission={'free_text':'나는 야영지로 가고 싶어'},
                 model='m',token='oauth',sender=lambda *args:raw)
        self.assertEqual(self.store.load()['player']['location'],'DEMO-FOREST')
        self.assertEqual(self.store.load()['last_player_input']['free_text'],'나는 야영지로 가고 싶어')

    def test_stale_response_rejected_if_store_changes_during_request(self):
        raw=json.dumps(proposal(),ensure_ascii=False)
        def race(*args):
            self.store.advance_time(0,5)
            return raw
        with self.assertRaisesRegex(WorldError,'stale revision'):
            run_turn(self.store,submission={'choice_id':'choice_stay'},model='m',token='oauth',sender=race)
        self.assertEqual(self.store.load()['revision'],1)
        self.assertEqual(self.store.load()['world_minutes'],5)
        self.assertEqual(self.store.load()['scene']['id'],'DEMO-SCENE-START')

    def test_preflight_rejects_unknown_choice_without_ai_call(self):
        with self.assertRaises(WorldError):
            run_turn(self.store,submission={'choice_id':'UNKNOWN'},model='m',token='oauth',
                     sender=lambda *args:self.fail('Never call model'))
        self.assertEqual(self.store.load()['revision'],0)

    def test_completed_response_no_autoretry_after_invalid_scene(self):
        count=[0]
        def sender(*args):
            count[0]+=1
            return '{"events":[],"scene":{}}'
        with self.assertRaises(WorldError):
            run_turn(self.store,submission={'choice_id':'choice_stay'},model='m',token='oauth',sender=sender)
        self.assertEqual(count[0],1)

    def test_no_other_world_accepts_demo_cli(self):
        st=json.loads(EXAMPLE.read_text(encoding='utf-8'))
        st['world_id']='CANON-WORLD'
        path=Path(self.tmp.name)/'official.json'
        path.write_text(json.dumps(st,ensure_ascii=False),encoding='utf-8')
        with self.assertRaises(WorldError):
            initial_demo_store(Path(self.tmp.name)/'wrong',sample_file=path)

    def test_missing_oauth_credential_never_hits_model_catalog(self):
        with self.assertRaises(SIWCError):
            authorized_catalog(credentials_dir=Path(self.tmp.name)/'none',catalog=lambda _:self.fail('Catalog call'))

    def test_missing_plan_share_scope_blocks_model_catalog(self):
        folder=Path(self.tmp.name)/'private';folder.mkdir()
        (folder/'credentials.json').write_text('{}',encoding='utf-8')
        with patch('live_story.read_credentials',return_value={'access_token':'private','expires_at':9999999999,'scopes':[]}):
            with self.assertRaises(SIWCError):
                authorized_catalog(credentials_dir=folder,catalog=lambda _:self.fail('Catalog call'))

if __name__=='__main__':unittest.main()

class SecurityChecks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store=initial_demo_store(Path(self.tmp.name)/'demo',sample_file=EXAMPLE)
        self.state=self.store.load()

    def test_remote_npc_mutation_rejected_even_when_json_schema_valid(self):
        self.state['npcs']['REMOTE']={'id':'REMOTE','name':'다른 NPC','location':'DEMO-CAMP',
                                     'mood':'평온','knowledge':['비공개 정보'], 'name_color':'#9C3E36'}
        # Create a fresh store with remote NPC known to engine but not visible to model.
        self.tmp2=tempfile.TemporaryDirectory();self.addCleanup(self.tmp2.cleanup)
        from world_engine import EventStore
        store=EventStore(self.tmp2.name);store.create(self.state)
        p=proposal();p['events']=[{'type':'npc_mood','npc_id':'REMOTE','mood':'긴장'}]
        with self.assertRaisesRegex(WorldError,'바깥'):
            run_turn(store,submission={'choice_id':'choice_stay'},model='m',token='oauth',
                     sender=lambda *args:json.dumps(p,ensure_ascii=False))
        self.assertEqual(store.load()['revision'],0)

    def test_remote_move_choice_not_added(self):
        state=self.state
        state['regions']['DEMO-REMOTE']={'id':'DEMO-REMOTE','name':'먼 지역'}
        from world_engine import EventStore
        self.tmp2=tempfile.TemporaryDirectory();self.addCleanup(self.tmp2.cleanup)
        st=EventStore(self.tmp2.name);st.create(state)
        p=proposal();p['scene']['choices']=[{'id':'teleport','label':'순간이동','effect':{'type':'player_move','destination':'DEMO-REMOTE'}}]
        with self.assertRaisesRegex(WorldError,'이동 선택지'):
            run_turn(st,submission={'choice_id':'choice_stay'},model='m',token='oauth',
                     sender=lambda *args:json.dumps(p,ensure_ascii=False))
        self.assertEqual(st.load()['revision'],0)

class CacheRecovery(unittest.TestCase):
    def test_cache_write_lock_after_journal_commit_does_not_report_failure(self):
        import tempfile
        from world_engine import EventStore
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as t:
            store=initial_demo_store(Path(t)/'demo',sample_file=EXAMPLE)
            original=store._atomic_json
            def fail_cache(path,obj):
                if path==store.cache:
                    raise PermissionError(32, 'fake Windows transient cache lock')
                return original(path,obj)
            p=proposal()
            with patch.object(store, '_atomic_json', side_effect=fail_cache):
                out=run_turn(store,submission={'choice_id':'choice_stay'},model='m',token='oauth',
                             sender=lambda *args:json.dumps(p,ensure_ascii=False))
            self.assertEqual(out['revision'],1)
            self.assertEqual(store.load()['revision'],1)
