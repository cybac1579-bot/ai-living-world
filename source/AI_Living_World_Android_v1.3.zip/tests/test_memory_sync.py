"""Long-term NPC memory and offline Drive transport regression tests."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from world_engine import EventStore, WorldError, transition
from ai_adapter import build_model_context
from sync_bridge import export_bundle, inspect_bundle, apply_bundle

EXAMPLE = Path(__file__).resolve().parents[1] / 'examples' / 'test_world.json'


def seed():
    return json.loads(EXAMPLE.read_text(encoding='utf-8'))


def npc_tick(events):
    return {'events':events}


class TestMemory(unittest.TestCase):
    def test_remember_and_goal_are_separate_from_player(self):
        base = seed()
        result = transition(base, None, npc_tick([
            {'type':'npc_remember','npc_id':'DEMO-GUIDE','memory_id':'M1','text':'이방인이 숲 입구에 나타났다','priority':3},
            {'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'G1','description':'숲 동쪽 출구를 확인한다'},
        ]), mode='npc_tick')
        npc = result['npcs']['DEMO-GUIDE']
        self.assertEqual(npc['memories'][0]['revision'], 1)
        self.assertEqual(npc['goals'][0]['status'], 'active')
        self.assertEqual(result['player'], base['player'])
        self.assertEqual(result['scene'], base['scene'])
        self.assertEqual(result['revision'], 1)

    def test_goal_completion_preserves_completed_history(self):
        base = transition(seed(), None, npc_tick([
            {'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'G1','description':'목표'}]), mode='npc_tick')
        after = transition(base, None, npc_tick([{'type':'npc_goal_complete','npc_id':'DEMO-GUIDE','goal_id':'G1'}]), mode='npc_tick')
        self.assertEqual(after['npcs']['DEMO-GUIDE']['goals'][0]['status'], 'completed')
        self.assertEqual(build_model_context(after, submission=None, mode='npc_tick')['local_npcs'][0]['active_goals'], [])

    def test_unknown_goal_cannot_complete(self):
        with self.assertRaises(WorldError):
            transition(seed(), None, npc_tick([{'type':'npc_goal_complete','npc_id':'DEMO-GUIDE','goal_id':'missing'}]), mode='npc_tick')

    def test_duplicate_memory_and_goal_rejected(self):
        for evt in (
            {'type':'npc_remember','npc_id':'DEMO-GUIDE','memory_id':'same','text':'중요','priority':3},
            {'type':'npc_goal_set','npc_id':'DEMO-GUIDE','goal_id':'same','description':'목표'}):
            with self.subTest(evt=evt['type']):
                with self.assertRaises(WorldError):
                    transition(seed(),None,npc_tick([evt,copy.deepcopy(evt)]),mode='npc_tick')

    def test_bad_memory_priority(self):
        for priority in (0, 4, True, 'high'):
            with self.subTest(priority=priority), self.assertRaises(WorldError):
                transition(seed(),None,npc_tick([{'type':'npc_remember','npc_id':'DEMO-GUIDE','memory_id':'m','text':'t','priority':priority}]),mode='npc_tick')

    def test_private_memory_only_for_present_npcs(self):
        base = seed()
        base['npcs']['OFFSCREEN'] = {**copy.deepcopy(base['npcs']['DEMO-GUIDE']), 'id':'OFFSCREEN', 'name':'비공개 인물', 'location':'DEMO-CAMP', 'knowledge':['비밀'], 'memories':[{'id':'secret','text':'아무도 몰라','priority':3,'revision':0}], 'goals':[{'id':'secretgoal','description':'숨겨진 목표','status':'active'}]}
        ctx = build_model_context(base, submission={'choice_id':'choice_stay'})
        self.assertEqual(len(ctx['local_npcs']),1)
        self.assertNotIn('아무도 몰라', json.dumps(ctx,ensure_ascii=False))
        ctx_camp = build_model_context(base, submission={'choice_id':'choice_move'})
        self.assertEqual(ctx_camp['local_npcs'][0]['id'],'OFFSCREEN')
        self.assertEqual(ctx_camp['local_npcs'][0]['memories'][0]['text'],'아무도 몰라')

    def test_memory_priority_sorted_for_context(self):
        base = seed()
        base['npcs']['DEMO-GUIDE']['memories'] = [
            {'id':'a','text':'낮은 기억','priority':1,'revision':0},
            {'id':'b','text':'높은 기억','priority':3,'revision':0}]
        ctx = build_model_context(base,submission={'choice_id':'choice_stay'})
        self.assertEqual(ctx['local_npcs'][0]['memories'][0]['id'],'b')

    def test_model_cannot_claim_player_goal_or_memory(self):
        for e in (
            {'type':'npc_remember','npc_id':'PLAYER','memory_id':'x','text':'뜻','priority':1},
            {'type':'player_goal_set','goal':'승리'}):
            with self.subTest(e=e), self.assertRaises(WorldError):
                transition(seed(),None,npc_tick([e]),mode='npc_tick')


class TestSyncBridge(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='alw-v04-test-')
        self.root = Path(self.tmp.name)
        self.left = EventStore(self.root/'left')
        self.left.create(seed())
        self.bundle = self.root/'backup.zip'

    def tearDown(self):
        self.tmp.cleanup()

    def save_turn(self, store=None, idx=1, memory=None):
        store = store or self.left
        current = store.load()
        e = memory or {'type':'npc_mood','npc_id':'DEMO-GUIDE','mood':f'기분-{idx}'}
        return store.commit(current['revision'],None,{'events':[e]},mode='npc_tick')

    def test_bundle_creation_and_inspect(self):
        self.save_turn()
        exported = export_bundle(self.left,self.bundle)
        self.assertEqual(exported['revision'],1)
        self.assertEqual(inspect_bundle(self.bundle),exported)
        with zipfile.ZipFile(self.bundle) as z:
            self.assertEqual(len(z.namelist()),3)

    def test_import_into_fresh_store(self):
        self.save_turn(memory={'type':'npc_remember','npc_id':'DEMO-GUIDE','memory_id':'m','text':'절대 잊지 말아야 할 기억','priority':3})
        export_bundle(self.left,self.bundle)
        dest=EventStore(self.root/'right')
        result=apply_bundle(dest,self.bundle)
        self.assertEqual(result['status'],'restored')
        self.assertEqual(dest.load(),self.left.load())
        self.assertEqual(len(dest.load()['npcs']['DEMO-GUIDE']['memories']),1)

    def test_import_same_bundle_twice_is_idempotent(self):
        self.save_turn()
        export_bundle(self.left,self.bundle)
        dest=EventStore(self.root/'right')
        apply_bundle(dest,self.bundle)
        self.assertEqual(apply_bundle(dest,self.bundle)['status'],'unchanged')
        self.assertEqual(dest.load()['revision'],1)

    def test_fast_forward_only_new_records(self):
        self.save_turn(idx=1)
        export_bundle(self.left,self.bundle)
        dest=EventStore(self.root/'right')
        apply_bundle(dest,self.bundle)
        self.save_turn(idx=2)
        export_bundle(self.left,self.bundle)
        self.assertEqual(apply_bundle(dest,self.bundle)['status'],'fast_forward')
        self.assertEqual(dest.load(),self.left.load())

    def test_older_archive_refuses_to_rollback(self):
        export_bundle(self.left,self.bundle)
        self.save_turn()
        self.assertRaisesRegex(WorldError,'divergent or older',apply_bundle,self.left,self.bundle)
        self.assertEqual(self.left.load()['revision'],1)

    def test_two_branches_same_rev_refuse_overwrite(self):
        export_bundle(self.left,self.bundle)
        other=EventStore(self.root/'right')
        apply_bundle(other,self.bundle)
        self.save_turn(self.left,idx=1)
        self.save_turn(other,idx=999)
        export_bundle(self.left,self.bundle)
        self.assertRaisesRegex(WorldError,'divergent',apply_bundle,other,self.bundle)
        self.assertEqual(other.load()['npcs']['DEMO-GUIDE']['mood'],'기분-999')

    def test_different_world_initial_refused(self):
        foreign=seed();foreign['world_id']='ANOTHER'
        other=EventStore(self.root/'right');other.create(foreign)
        export_bundle(self.left,self.bundle)
        self.assertRaisesRegex(WorldError,'different genesis',apply_bundle,other,self.bundle)

    def test_tampered_bundle_detected_before_writing(self):
        export_bundle(self.left,self.bundle)
        with zipfile.ZipFile(self.bundle) as z:
            data={n:z.read(n) for n in z.namelist()}
        data['events.jsonl'] += b'garbage'
        with zipfile.ZipFile(self.bundle,'w') as z:
            for n,v in data.items():z.writestr(n,v)
        dest=EventStore(self.root/'right')
        with self.assertRaises(WorldError):apply_bundle(dest,self.bundle)
        self.assertFalse(dest.initial.exists())

    def test_forged_manifest_digest_does_not_bypass_journal_replay(self):
        self.save_turn()
        export_bundle(self.left,self.bundle)
        with zipfile.ZipFile(self.bundle) as z:
            data={n:z.read(n) for n in z.namelist()}
        j=json.loads(data['events.jsonl'].decode().strip())
        j['model_output']['events'][0]['mood']='위조 기분'
        import hashlib
        data['events.jsonl']=(json.dumps(j,ensure_ascii=False)+'\n').encode()
        m=json.loads(data['manifest.json']);m['journal_sha256']=hashlib.sha256(data['events.jsonl']).hexdigest()
        data['manifest.json']=json.dumps(m).encode()
        with zipfile.ZipFile(self.bundle,'w') as z:
            for n,v in data.items():z.writestr(n,v)
        with self.assertRaises(WorldError):inspect_bundle(self.bundle)

    def test_path_traversal_zip_refused(self):
        with zipfile.ZipFile(self.bundle,'w') as z:
            z.writestr('../../evil','oops')
        with self.assertRaises(WorldError):inspect_bundle(self.bundle)

    def test_broken_partial_local_save_refused(self):
        export_bundle(self.left,self.bundle)
        dest=EventStore(self.root/'right')
        dest.initial.write_text('{}')
        with self.assertRaises(WorldError):apply_bundle(dest,self.bundle)

    def test_same_genesis_bytes_preserved_across_restore(self):
        export_bundle(self.left,self.bundle)
        dest=EventStore(self.root/'right')
        apply_bundle(dest,self.bundle)
        self.assertEqual(dest.initial.read_bytes(),self.left.initial.read_bytes())

    def test_bundle_manifest_revision_mismatch(self):
        self.save_turn()
        export_bundle(self.left,self.bundle)
        with zipfile.ZipFile(self.bundle) as z:data={n:z.read(n) for n in z.namelist()}
        m=json.loads(data['manifest.json']);m['revision']=1_000_000
        data['manifest.json']=json.dumps(m).encode()
        with zipfile.ZipFile(self.bundle,'w') as z:
            for n,v in data.items():z.writestr(n,v)
        with self.assertRaises(WorldError):inspect_bundle(self.bundle)

if __name__=='__main__':unittest.main()

class TestCliBackup(unittest.TestCase):
    def test_cli_backup_restore_into_fresh_world(self):
        import subprocess
        base = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            store = Path(tmp)/'demo'
            archive = Path(tmp)/'demo.zip'
            target = Path(tmp)/'recovered'
            for args in (
                ['init','--store',str(store)],
                ['backup','--store',str(store),'--archive',str(archive)],
                ['inspect-backup','--archive',str(archive)],
                ['restore','--store',str(target),'--archive',str(archive)]):
                p = subprocess.run([sys.executable,'cli.py',*args],cwd=base,capture_output=True,text=True)
                self.assertEqual(p.returncode,0,f'{args}: {p.stderr}')
            self.assertEqual(EventStore(store).load(),EventStore(target).load())
