import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).parents[1]))
import siwc_client as sc
import siwc_cli as cli
from world_engine import EventStore, WorldError

ROOT = Path(__file__).parents[1]

class TestSIWC(unittest.TestCase):
    def setup(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)

    def test_auth_uses_state_nonce_pkce_and_loopback(self):
        a = sc.create_auth_attempt('urn:uuid:13f31a26-e495-4425-b725-b96dc57ac498', port=19873)
        from urllib.parse import parse_qs, urlparse
        q = parse_qs(urlparse(a.url).query)
        self.assertEqual(q['redirect_uri'][0], 'http://127.0.0.1:19873/auth/callback')
        self.assertEqual(q['client_id'][0], 'dynamic_agent_client')
        self.assertEqual(q['code_challenge_method'][0], 'S256')
        self.assertIn('chatgpt.tokens.use.direct', q['scope'][0]); self.assertNotIn('localhost',a.url)
        self.assertNotIn(a.verifier,a.url)

    def test_callback_valid_and_replay_state_rejected(self):
        a=sc.create_auth_attempt('urn:uuid:13f31a26-e495-4425-b725-b96dc57ac498', port=19873)
        self.assertEqual(sc.read_callback(a, {'state':a.state,'code':'abc','client_id':'oaiapp_demo'}), ('abc','oaiapp_demo'))
        with self.assertRaisesRegex(sc.SIWCError, 'state mismatch'):
            sc.read_callback(a, {'state':'wrong','code':'abc','client_id':'oaiapp_demo'})
        with self.assertRaisesRegex(sc.SIWCError, 'missing issued'):
            sc.read_callback(a, {'state':a.state,'code':'abc'})
        with self.assertRaisesRegex(sc.SIWCError, 'declined'):
            sc.read_callback(a, {'state':a.state,'error':'access_denied'})

    def test_existing_client_id_mismatch_refused(self):
        a=sc.create_auth_attempt('urn:uuid:13f31a26-e495-4425-b725-b96dc57ac498', port=19873,client_id='oaiapp_saved')
        with self.assertRaisesRegex(sc.SIWCError, 'unexpected'):
            sc.read_callback(a, {'state':a.state,'code':'abc','client_id':'oaiapp_other'})
        self.assertEqual(sc.read_callback(a, {'state':a.state,'code':'abc'}), ('abc','oaiapp_saved'))

    def test_reject_ungranted_scope(self):
        a=sc.create_auth_attempt('urn:uuid:13f31a26-e495-4425-b725-b96dc57ac498', port=19873)
        with self.assertRaisesRegex(sc.SIWCError, 'permission'):
            sc.finalize_tokens(a, {'state':a.state,'code':'abc','client_id':'oaiapp_test'},
                               {'scope':'openid email'}, {})

    def test_jwt_reject_non_signed_token(self):
        import jwt
        payload={'sub':'x','iss':sc.AUTH_BASE,'aud':'oaiapp_demo','exp':9999999999,'iat':1,'nonce':'abc'}
        unsafe=jwt.encode(payload,key='test-key-must-not-be-accepted-in-oauth-flow-123456',algorithm='HS256')
        with self.assertRaisesRegex(sc.SIWCError, 'unsupported'):
            sc.validate_identity(unsafe,'oaiapp_demo','abc',{'keys':[]})

    def test_host_id_stays_constant_and_permissions(self):
        self.setup()
        a=sc.read_or_create_host_id(self.path/'private')
        b=sc.read_or_create_host_id(self.path/'private')
        self.assertEqual(a,b)
        if os.name!='nt': self.assertEqual((self.path/'private'/'host-id.txt').stat().st_mode&0o777,0o600)

    def test_credentials_private_and_never_logging(self):
        self.setup()
        f=self.path/'private'/'credentials.json'
        data={'scopes':['chatgpt.tokens.use.direct'],'access_token':'secret-token',
              'refresh_token':'other-secret','client_id':'oaiapp_x'}
        sc.write_credentials(f,data)
        self.assertEqual(sc.read_credentials(f),data)
        if os.name!='nt': self.assertEqual(f.stat().st_mode&0o777,0o600)
        if os.name!='nt':
            f.chmod(0o644)
            with self.assertRaisesRegex(sc.SIWCError,'insecure'):
                sc.read_credentials(f)

    def test_no_paid_api_key_fallback(self):
        self.setup()
        f=self.path/'missing.json'
        with patch.dict(os.environ,{'OPENAI_API_KEY':'sk-paid-api-key'}):
            with self.assertRaisesRegex(sc.SIWCError,'Not signed in'):
                sc.read_credentials(f)

    def test_models_only_list_visible(self):
        with patch.object(sc,'_json_request',return_value={'models':[
            {'slug':'model-1','display_name':'One','visibility':'list'},
            {'slug':'hidden','visibility':'hidden'}]}):
            self.assertEqual(sc.list_models('oauth-access'),[{'slug':'model-1','display_name':'One'}])

    def test_stream_requires_completed(self):
        ok=[b'data: {"type":"response.output_text.delta","delta":"{\\"events\\":[]}"}\n',
            b'data: {"type":"response.completed","response":{"status":"completed"}}\n',b'data: [DONE]\n']
        self.assertEqual(sc.collect_response_events(ok), '{"events":[]}')
        with self.assertRaisesRegex(sc.SIWCError,'without response.completed'):
            sc.collect_response_events(ok[:1])
        with self.assertRaisesRegex(sc.SIWCError, 'response.failed'):
            sc.collect_response_events([b'data: {"type":"response.failed","response":{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}}\n'])
        with self.assertRaisesRegex(sc.SIWCError,'too long'):
            sc.collect_response_events([b'data: {"type":"response.output_text.delta","delta":"12345678"}\n'],max_chars=4)

    def test_stream_failure_never_changes_world(self):
        self.setup()
        store=EventStore(self.path/'store'); store.create(json.loads((ROOT/'examples'/'test_world.json').read_text()))
        f=self.path/'private'/'credentials.json'; sc.write_credentials(f,{
            'scopes':['chatgpt.tokens.use.direct'],'access_token':'oauth','refresh_token':'refresh',
            'client_id':'oaiapp_valid', 'expires_at':9999999999})
        with patch.object(cli,'list_models',return_value=[{'slug':'test-model'}]),patch.object(cli,'stream_response',side_effect=sc.SIWCError('interrupted')):
            with self.assertRaises(sc.SIWCError):
                cli.one_authenticated_turn(credentials_file=f,store_dir=self.path/'store',model='test-model',
                                           submission={'choice_id':'choice_stay'},expected_revision=0)
        self.assertEqual(store.load()['revision'],0)

    def test_fake_stream_full_turn_commits_once(self):
        self.setup()
        store=EventStore(self.path/'store'); store.create(json.loads((ROOT/'examples'/'test_world.json').read_text()))
        f=self.path/'private'/'credentials.json'; sc.write_credentials(f,{
            'scopes':['chatgpt.tokens.use.direct'],'access_token':'oauth','refresh_token':'refresh',
            'client_id':'oaiapp_valid','expires_at':9999999999})
        response=(ROOT/'examples'/'ai_scene_after_choice.json').read_text()
        with patch.object(cli,'list_models',return_value=[{'slug':'test-model'}]),patch.object(cli,'stream_response',return_value=response) as mocked:
            rendered=cli.one_authenticated_turn(credentials_file=f,store_dir=self.path/'store',model='test-model',
                                           submission={'choice_id':'choice_move'},expected_revision=0)
        self.assertEqual(rendered['revision'],1);self.assertEqual(rendered['region']['id'],'DEMO-CAMP')
        self.assertEqual(store.load()['revision'],1)
        self.assertEqual(mocked.call_args.args[1],'test-model')

    def test_missing_token_stops_before_network(self):
        self.setup()
        store=EventStore(self.path/'store'); store.create(json.loads((ROOT/'examples'/'test_world.json').read_text()))
        with patch.object(cli,'list_models',side_effect=AssertionError('should not call')):
            with self.assertRaises(sc.SIWCError):
                cli.one_authenticated_turn(credentials_file=self.path/'missing.json',store_dir=self.path/'store',
                                       model='no-model',submission={'choice_id':'choice_stay'},expected_revision=0)
        self.assertEqual(store.load()['revision'],0)

    def test_wrong_model_rejected_before_inference(self):
        self.setup()
        store=EventStore(self.path/'store'); store.create(json.loads((ROOT/'examples'/'test_world.json').read_text()))
        f=self.path/'private'/'credentials.json'; sc.write_credentials(f,{
            'scopes':['chatgpt.tokens.use.direct'],'access_token':'oauth','refresh_token':'refresh','client_id':'oaiapp_valid','expires_at':9999999999})
        with patch.object(cli,'list_models',return_value=[{'slug':'available'}]),patch.object(cli,'stream_response',side_effect=AssertionError('should not call')):
            with self.assertRaisesRegex(sc.SIWCError,'not available'):
                cli.one_authenticated_turn(credentials_file=f,store_dir=self.path/'store',model='missing',
                                          submission={'choice_id':'choice_stay'},expected_revision=0)
        self.assertEqual(store.load()['revision'],0)

    def test_stale_revision_before_api(self):
        self.setup()
        store=EventStore(self.path/'store'); store.create(json.loads((ROOT/'examples'/'test_world.json').read_text()))
        with patch.object(cli,'current_credentials',side_effect=AssertionError('should not call')):
            with self.assertRaisesRegex(WorldError,'outdated'):
                cli.one_authenticated_turn(credentials_file=self.path/'missing',store_dir=self.path/'store',model='x',
                                           submission={'choice_id':'choice_stay'},expected_revision=8)

class TestContextPreflight(unittest.TestCase):
    def setUp(self):
        self.state=json.loads((ROOT/'examples'/'test_world.json').read_text())

    def test_move_context_uses_arrival_location(self):
        from ai_adapter import build_model_context
        c=build_model_context(self.state,submission={'choice_id':'choice_move'})
        self.assertEqual(c['origin_location']['id'],'DEMO-FOREST')
        self.assertEqual(c['location']['id'],'DEMO-CAMP')
        self.assertEqual(c['selected_player_effect']['destination'],'DEMO-CAMP')
        self.assertEqual(c['local_npcs'],[])

    def test_free_text_does_not_assume_move(self):
        from ai_adapter import build_model_context
        c=build_model_context(self.state,submission={'free_text':'야영지로 달려간다'})
        self.assertEqual(c['location']['id'],'DEMO-FOREST')
        self.assertEqual(c['selected_player_effect'],{'type':'none'})
        self.assertEqual(len(c['local_npcs']),1)

    def test_invalid_choice_before_model_call(self):
        from ai_adapter import build_model_context
        with self.assertRaisesRegex(WorldError,'stale choice'):
            build_model_context(self.state,submission={'choice_id':'invented'})

    def test_malicious_multi_action_rejected(self):
        from ai_adapter import build_model_context
        with self.assertRaisesRegex(WorldError,'invalid player submission'):
            build_model_context(self.state,submission={'choice_id':'choice_move','free_text':'attack'})

    def test_new_region_npc_private_knowledge_only_after_choice(self):
        from ai_adapter import build_model_context
        self.state['npcs']['DEMO-HERMIT']={'id':'DEMO-HERMIT','name':'은둔자','name_color':'#17715D',
            'location':'DEMO-CAMP','knowledge':['야영지 비밀'], 'mood':'침착'}
        original=build_model_context(self.state,submission={'free_text':'아직 이동하지 않는다'})
        self.assertNotIn('야영지 비밀',json.dumps(original,ensure_ascii=False))
        moved=build_model_context(self.state,submission={'choice_id':'choice_move'})
        self.assertIn('야영지 비밀',json.dumps(moved,ensure_ascii=False))
        self.assertNotIn('숲의 출구는 동쪽에 있다',json.dumps(moved,ensure_ascii=False))

    def test_invalid_choice_stops_before_credentials(self):
        import siwc_cli as cli
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); store=EventStore(root/'store');store.create(self.state)
            with patch.object(cli,'current_credentials',side_effect=AssertionError('should not call')):
                with self.assertRaisesRegex(WorldError,'stale choice'):
                    cli.one_authenticated_turn(credentials_file=root/'no-creds.json',store_dir=root/'store',
                           model='no-model',submission={'choice_id':'nonexistent'},expected_revision=0)
            self.assertEqual(store.load()['revision'],0)

class TestOAuthSigningAndHttp(unittest.TestCase):
    def setUp(self):
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        import jwt
        self.private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(self.private.public_key()))
        public_jwk['kid']='demo-signing-key'
        self.jwks={'keys':[public_jwk]}
        self.client_id='oaiapp_testing'
        self.nonce='test-oidc-nonce'

    def token(self, **updates):
        import jwt
        payload={'iss':sc.AUTH_BASE,'aud':self.client_id, 'sub':'account-001', 'exp':int(__import__('time').time())+3600,
                 'iat':int(__import__('time').time()), 'nonce':self.nonce}
        payload.update(updates)
        return jwt.encode(payload,self.private,algorithm='RS256',headers={'kid':'demo-signing-key'})

    def test_valid_signed_id_token(self):
        data=sc.validate_identity(self.token(),self.client_id,self.nonce,self.jwks)
        self.assertEqual(data['subject'],'account-001')

    def test_reject_wrong_audience(self):
        with self.assertRaisesRegex(sc.SIWCError,'verification failed'):
            sc.validate_identity(self.token(aud='oaiapp_other'),self.client_id,self.nonce,self.jwks)

    def test_reject_wrong_nonce(self):
        with self.assertRaisesRegex(sc.SIWCError,'nonce mismatch'):
            sc.validate_identity(self.token(nonce='not-it'),self.client_id,self.nonce,self.jwks)

    def test_approved_scope_creates_credentials(self):
        a=sc.create_auth_attempt('urn:uuid:13f31a26-e495-4425-b725-b96dc57ac498',port=19873)
        creds=sc.finalize_tokens(a,{'code':'abc','state':a.state,'client_id':self.client_id},
            {'scope':sc.SCOPES,'access_token':'token','refresh_token':'refresh','id_token':self.token(nonce=a.nonce),'expires_in':3600},self.jwks)
        self.assertEqual(creds['client_id'],self.client_id)
        self.assertEqual(creds['subject'],'account-001')
        self.assertEqual(creds['scopes'].count('chatgpt.tokens.use.direct'),1)

    def test_http_stream_request_uses_oauth_only_and_no_store(self):
        import io
        events=b'data: {"type":"response.output_text.delta","delta":"{\\"events\\":[]}"}\n\ndata: {"type":"response.completed","response":{"status":"completed"}}\n\ndata: [DONE]\n'
        requests=[]
        class Stream:
            def __enter__(self): return io.BytesIO(events)
            def __exit__(self,*_): pass
        def fake_urlopen(req, timeout=120):
            requests.append(req)
            return Stream()
        with patch.object(sc.urllib.request,'urlopen',side_effect=fake_urlopen):
            result=sc.stream_response('oauth-only','demo-model',{'revision':0})
        self.assertEqual(result,'{"events":[]}')
        req=requests[0]
        self.assertEqual(req.full_url,sc.API_BASE+'/responses')
        self.assertEqual(req.get_header('Authorization'),'Bearer oauth-only')
        body=json.loads(req.data)
        self.assertIs(body['store'],False)
        self.assertIs(body['stream'],True)
        self.assertNotIn('previous_response_id',body)
        self.assertNotIn('temperature',body)
        self.assertEqual(body['model'],'demo-model')
