"""End-to-end regression for free action travel and observable clue progression."""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from ai_adapter import build_model_context
from live_story import run_turn, build_request, verify_proposed_turn
from world_engine import EventStore, WorldError, render_contract, resolve_explicit_movement, validate_state

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "examples" / "live_demo_world.json"


def camp_scene(*, events=None, choices=None, label="야영지의 새로운 장면"):
    return {
        "events": events if events is not None else [],
        "scene": {
            "id": "DEMO-SCENE-NEXT",
            "beats": [{"kind": "narration", "text": label}],
            "awaiting_player": True,
            "choices": choices if choices is not None else [
                {"id": "inspect", "label": "화덕을 살펴본다", "effect": {"type": "none"}},
                {"id": "return", "label": "테스트 숲으로 돌아간다", "effect": {"type": "player_move", "destination": "DEMO-FOREST"}},
            ],
            "event_image_id": None, "character_image_id": None,
        },
    }


class StoryProgressTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = EventStore(self.tmp.name)
        self.start = json.loads(EXAMPLE.read_text(encoding="utf-8"))
        self.store.create(self.start)

    def sender(self, proposal, seen=None):
        def f(token, model, context):
            if seen is not None:
                seen.append(copy.deepcopy(context))
            return json.dumps(proposal, ensure_ascii=False)
        return f

    def move_to_camp(self):
        return run_turn(self.store, submission={"free_text": "동쪽으로 이동한다"},
                        model="model", token="fake-token", sender=self.sender(camp_scene()))

    def test_explicit_direction_is_authorized_and_persisted(self):
        seen = []
        rendered = run_turn(self.store, submission={"free_text": "동쪽으로 이동한다"},
                            model="model", token="fake-token", sender=self.sender(camp_scene(), seen))
        self.assertEqual(rendered["revision"], 1)
        self.assertEqual(rendered["region"]["id"], "DEMO-CAMP")
        self.assertEqual(seen[0]["location"]["id"], "DEMO-CAMP")
        self.assertEqual(seen[0]["selected_player_effect"], {"type": "player_move", "destination": "DEMO-CAMP"})
        st = self.store.load()
        self.assertEqual(st["last_player_input"]["free_text"], "동쪽으로 이동한다")
        self.assertEqual(st["player_action_history"][-1]["kind"], "free_text")
        self.store.cache.unlink()
        self.assertEqual(self.store.load(), st)

    def test_exact_registered_destination_name_is_supported(self):
        self.assertEqual(resolve_explicit_movement(self.start, "테스트 야영지로 이동한다"), "DEMO-CAMP")

    def test_unknown_direction_stops_before_model(self):
        self.move_to_camp()
        calls = []
        with self.assertRaisesRegex(WorldError, "확인된 길이 없어"):
            run_turn(self.store, submission={"free_text": "동쪽으로 이동한다"},
                     model="model", token="fake-token", sender=self.sender(camp_scene(), calls))
        self.assertEqual(calls, [])
        self.assertEqual(self.store.load()["revision"], 1)

    def test_unknown_destination_stops_before_model(self):
        calls = []
        with self.assertRaisesRegex(WorldError, "등록되지 않아"):
            run_turn(self.store, submission={"free_text": "미지의 동굴로 이동한다"},
                     model="model", token="fake-token", sender=self.sender(camp_scene(), calls))
        self.assertEqual(calls, [])

    def test_unconnected_named_region_stops_before_model(self):
        self.start["regions"]["DEMO-CAVE"] = {"id": "DEMO-CAVE", "name": "테스트 동굴", "neighbors": []}
        self.assertEqual(resolve_explicit_movement(self.start, "테스트 야영지로 이동한다"), "DEMO-CAMP")
        with self.assertRaisesRegex(WorldError, "연결되지 않아"):
            resolve_explicit_movement(self.start, "테스트 동굴로 이동한다")

    def test_ordinary_free_text_does_not_move(self):
        seen = []
        st = run_turn(self.store, submission={"free_text": "동쪽에 무엇이 있는지 물어본다"},
                      model="model", token="fake-token",
                      sender=self.sender({"events": [], "scene": self.start["scene"]}, seen))
        self.assertEqual(st["region"]["id"], "DEMO-FOREST")
        self.assertEqual(seen[0]["selected_player_effect"], {"type": "none"})

    def test_compound_action_is_not_silently_interpreted_as_move(self):
        self.assertIsNone(resolve_explicit_movement(self.start, "야영지로 이동해 화덕을 살펴본다"))
        self.assertIsNone(resolve_explicit_movement(self.start, "안내인에게 '동쪽으로 이동한다'라고 말한다"))

    def test_spoofed_move_to_rejected(self):
        with self.assertRaisesRegex(WorldError, "unapproved free text movement"):
            build_model_context(self.start, submission={"free_text": "여기서 기다린다", "move_to": "DEMO-CAMP"})
        with self.assertRaisesRegex(WorldError, "unapproved free text movement"):
            self.store.commit(0, {"free_text": "여기서 기다린다", "move_to": "DEMO-CAMP"}, camp_scene())
        self.assertEqual(self.store.load()["revision"], 0)

    def test_legacy_raw_move_text_preserves_historical_no_move_semantics(self):
        # Existing v0.7.1 save journals contain user-entered travel text in
        # 'free_text' only; those were not applied as movements by the engine.
        # Never retroactively alter the user's historical position.
        rendered = self.store.commit(0, {"free_text": "동쪽으로 이동한다"},
                                     {"events": [], "scene": self.start["scene"]})
        self.assertEqual(rendered["player"]["location"], "DEMO-FOREST")
        self.store.cache.unlink()
        self.assertEqual(self.store.load()["player"]["location"], "DEMO-FOREST")

    def test_clue_is_persistent_and_model_visible(self):
        self.move_to_camp()
        clue = {"type": "clue_discover", "id": "CLUE-ASH-001", "region": "DEMO-CAMP",
                "title": "최근 불을 피운 흔적", "detail": "화덕의 그을음 아래 새로 난 발자국이 있다."}
        proposed = camp_scene(events=[clue], label="그을음 주변에서 신선한 발자국을 발견한다.")
        result = run_turn(self.store, submission={"choice_id": "inspect"},
                          model="model", token="fake-token", sender=self.sender(proposed))
        self.assertEqual(result["revision"], 2)
        self.assertEqual(result["discovered_clues"][0]["id"], "CLUE-ASH-001")
        ctx = build_model_context(self.store.load(), submission={"choice_id": "inspect"})
        self.assertEqual(ctx["known_discoveries"][0]["id"], "CLUE-ASH-001")
        self.assertIn("최근 불을 피운 흔적", json.dumps(ctx, ensure_ascii=False))
        self.assertEqual(len(ctx["previous_actions_here"]), 2)
        before = self.store.load()
        self.store.cache.unlink()
        self.assertEqual(self.store.load(), before)

    def test_clue_cannot_repeat(self):
        self.move_to_camp()
        clue = {"type": "clue_discover", "id": "CLUE-ASH-001", "region": "DEMO-CAMP",
                "title": "발자국", "detail": "새로 찍힌 발자국"}
        self.store.commit(1, {"choice_id": "inspect"}, camp_scene(events=[clue]))
        with self.assertRaisesRegex(WorldError, "already discovered"):
            self.store.commit(2, {"choice_id": "inspect"}, camp_scene(events=[clue]))
        self.assertEqual(self.store.load()["revision"], 2)

    def test_clue_duplicate_in_one_turn_is_rejected(self):
        self.move_to_camp()
        clue = {"type": "clue_discover", "id": "CLUE-SAME", "region": "DEMO-CAMP",
                "title": "관찰", "detail": "같은 발견"}
        with self.assertRaisesRegex(WorldError, "duplicate clue"):
            self.store.commit(1, {"choice_id": "inspect"}, camp_scene(events=[clue, clue]))
        self.assertEqual(self.store.load()["revision"], 1)

    def test_clue_cannot_be_found_in_distant_region(self):
        self.move_to_camp()
        bad = {"type": "clue_discover", "id": "CLUE-FOREST", "region": "DEMO-FOREST",
               "title": "산길", "detail": "숲길이 달라졌다"}
        with self.assertRaisesRegex(WorldError, "offscreen clue"):
            self.store.commit(1, {"choice_id": "inspect"}, camp_scene(events=[bad]))

    def test_npc_tick_cannot_discover_for_player(self):
        evt = {"type": "clue_discover", "id": "CLUE-TEST", "region": "DEMO-FOREST",
               "title": "산길", "detail": "숲길의 흔적"}
        with self.assertRaisesRegex(WorldError, "NPC tick cannot"):
            self.store.commit(0, None, {"events": [evt]}, mode="npc_tick")

    def test_model_cannot_insert_player_inventory_as_clue(self):
        self.move_to_camp()
        evt = {"type": "clue_discover", "id": "CLUE-TEST", "region": "DEMO-CAMP",
               "title": "보물", "detail": "반지" ,"player_inventory": "반지"}
        with self.assertRaisesRegex(WorldError, "unknown model event field"):
            self.store.commit(1, {"choice_id": "inspect"}, camp_scene(events=[evt]))

    def test_discovery_cannot_claim_unselected_player_emotion(self):
        malicious = {"type": "clue_discover", "id": "CLUE-INVALID", "region": "DEMO-FOREST",
                     "title": "감정", "detail": "당신은 두려움에 떨었다"}
        with self.assertRaisesRegex(WorldError, "unchosen player"):
            self.store.commit(0, {"choice_id": "choice_stay"},
                              {"events": [malicious], "scene": self.start["scene"]})

    def test_story_prompt_includes_progress_and_prevents_repeated_ashes(self):
        ctx = build_model_context(self.start, submission={"choice_id": "choice_stay"})
        request = build_request("mock-model", ctx)
        self.assertIn("previous_actions_here", request["instructions"])
        self.assertIn("clue_discover", request["instructions"])
        self.assertEqual(request["store"], False)

    def test_backward_compatible_old_state_without_new_fields(self):
        s = copy.deepcopy(self.start)
        for r in s["regions"].values():
            r.pop("exits", None)
        validate_state(s)
        self.assertEqual(s.get("discoveries"), None)
        # Existing v0.7.1 saves can still be loaded without fields.
        with tempfile.TemporaryDirectory() as folder:
            store = EventStore(folder)
            store.create(s)
            self.assertEqual(store.load()["revision"], 0)


    def test_actual_v071_journal_replays_without_retroactive_movement(self):
        # Fixture was generated by the real v0.7.1 engine, including hashes.
        # The user's observed free-text east movement had no mechanical effect.
        fixture = ROOT / "tests" / "fixtures" / "legacy_v071_save"
        with tempfile.TemporaryDirectory() as folder:
            for name in ("initial_state.json", "events.jsonl"):
                shutil.copyfile(fixture / name, Path(folder) / name)
            old_state = EventStore(folder).load()
            self.assertEqual(old_state["revision"], 2)
            self.assertEqual(old_state["player"]["location"], "DEMO-CAMP")
            self.assertEqual(old_state["last_player_input"]["free_text"], "동쪽으로 이동한다")
            self.assertEqual(len(old_state["player_action_history"]), 2)
            # A further v0.8 read-only action must append safely to old journal.
            after = EventStore(folder).commit(2, {"choice_id": "observe"}, camp_scene())
            self.assertEqual(after["revision"], 3)
            self.assertEqual(EventStore(folder).load()["player"]["location"], "DEMO-CAMP")

    def test_forged_direction_exit_mapping_is_rejected(self):
        s = copy.deepcopy(self.start)
        s["regions"]["DEMO-FOREST"]["exits"] = {"북쪽": "DEMO-FOREST"}
        with self.assertRaisesRegex(WorldError, "invalid directional exit"):
            validate_state(s)

    def test_false_agency_in_clue_event_rejected_by_field_shape(self):
        bad = {"type": "clue_discover", "id": "F", "region": "DEMO-FOREST",
               "title": "흥미로운 돌", "detail": "오래된 돌", "player_emotion": "두려움"}
        with self.assertRaises(WorldError):
            self.store.commit(0, {"choice_id": "choice_stay"},
                              {"events": [bad], "scene": self.start["scene"]})


if __name__ == "__main__":
    unittest.main()
