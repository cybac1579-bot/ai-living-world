"""Regression for real Python engine -> loopback HTML contract (no paid request)."""
from __future__ import annotations
import http.client
import json
import re
import tempfile
import threading
import unittest
from pathlib import Path

from live_story import initial_demo_store
from vn_server import LoopbackServer, StoryBridge, WEB
from world_engine import WorldError

SAMPLE = Path(__file__).resolve().parents[1] / 'examples' / 'live_demo_world.json'


def demo_answer(*_args):
    return json.dumps({'events': [], 'scene': {
        'id':'DEMO-AFTER-MOVE',
        'beats':[{'kind':'narration', 'text':'화덕에 재가 남아 있어. 길은 숲 쪽으로 이어져.'}],
        'choices':[{'id':'back','label':'테스트 숲으로 돌아간다',
                    'effect':{'type':'player_move','destination':'DEMO-FOREST'}}],
        'awaiting_player':True,
        'event_image_id':None,
        'character_image_id':None,
    }},ensure_ascii=False)


class VNServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = initial_demo_store(Path(self.temp.name)/'save',sample_file=SAMPLE)
        self.calls = []
        def sender(*args):
            self.calls.append(args)
            return demo_answer()
        self.bridge = StoryBridge(self.store,token='PRIVATE-OAUTH-TOKEN',
                                  models=[{'slug':'gpt-demo','name':'Demo GPT'}],sender=sender)
        self.server = LoopbackServer(('127.0.0.1', 0),self.bridge)
        self.thread = threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(lambda: (self.server.shutdown(),self.server.server_close(),self.thread.join(timeout=4)))

    def request(self, method='GET',path='/api/state',body=None,headers=None):
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        data = None if body is None else json.dumps(body,ensure_ascii=False).encode('utf-8')
        connection.request(method,path,body=data,headers={'Host':f'127.0.0.1:{self.server.server_port}',**(headers or {})})
        response=connection.getresponse()
        raw=response.read()
        status=response.status
        conn_type=response.getheader('Content-Type')
        connection.close()
        return status,json.loads(raw) if conn_type and 'application/json' in conn_type else raw

    def authorized_headers(self):
        return {'Origin':f'http://127.0.0.1:{self.server.server_port}',
                'X-ALW-CSRF':self.bridge.csrf,'Content-Type':'application/json'}

    def payload(self,**overrides):
        return {'revision':0,'model':'gpt-demo','submission':{'choice_id':'choice_move'},'approve':True,**overrides}

    def test_demo_scene_has_correct_vn_contract(self):
        status, data=self.request()
        self.assertEqual(status,200)
        self.assertEqual(data['world']['revision'],0)
        self.assertEqual(data['world']['image']['src'],'/assets/forest.jpg')
        self.assertEqual(data['world']['beats'][1]['speaker']['name'],'시험 안내인')
        self.assertEqual(data['world']['beats'][1]['speaker']['name_color'],'#345D91')
        self.assertNotIn('PRIVATE-OAUTH-TOKEN',json.dumps(data))
        self.assertNotIn('credentials.json',json.dumps(data))

    def test_model_request_commits_and_reloads_real_engine(self):
        status,data=self.request('POST','/api/turn',self.payload(),self.authorized_headers())
        self.assertEqual(status,200,data)
        self.assertEqual(data['world']['revision'],1)
        self.assertEqual(data['world']['region']['id'],'DEMO-CAMP')
        self.assertEqual(data['world']['image']['kind'],'missing')
        self.assertIsNone(data['world']['image']['src'])
        self.assertEqual(len(self.calls),1)
        self.assertEqual(self.store.load()['revision'],1)
        self.store.cache.unlink()
        self.assertEqual(self.store.load()['player']['location'],'DEMO-CAMP')
        code,data=self.request()
        self.assertEqual(code,200)
        self.assertEqual(data['world']['revision'],1)

    def test_stale_turn_rejected_before_request(self):
        self.request('POST','/api/turn',self.payload(),self.authorized_headers())
        status,data=self.request('POST','/api/turn',self.payload(),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertIn('오래됐어',data['error'])
        self.assertEqual(len(self.calls),1)

    def test_no_consent_no_model(self):
        status,data=self.request('POST','/api/turn',self.payload(approve=False),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertEqual(len(self.calls),0)

    def test_unlisted_model_no_model(self):
        status,data=self.request('POST','/api/turn',self.payload(model='other'),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertEqual(len(self.calls),0)

    def test_non_string_model_no_model(self):
        status,data=self.request('POST','/api/turn',self.payload(model=['not-string']),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertEqual(len(self.calls),0)

    def test_bad_json_no_model(self):
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        connection.request('POST','/api/turn',body=b'{not json}',headers={**self.authorized_headers()})
        response=connection.getresponse();response.read()
        self.assertEqual(response.status,422)
        connection.close()
        self.assertEqual(len(self.calls),0)

    def test_no_csrf_no_model(self):
        heads=self.authorized_headers();heads.pop('X-ALW-CSRF')
        status,_=self.request('POST','/api/turn',self.payload(),heads)
        self.assertEqual(status,403)
        self.assertEqual(len(self.calls),0)

    def test_foreign_origin_no_model(self):
        heads=self.authorized_headers();heads['Origin']='https://other.example'
        status,_=self.request('POST','/api/turn',self.payload(),heads)
        self.assertEqual(status,403)
        self.assertEqual(len(self.calls),0)

    def test_wrong_host_refused(self):
        status,_=self.request('GET','/',headers={'Host':'attacker.example'})
        self.assertEqual(status,403)

    def test_invalid_type_no_model(self):
        status,_=self.request('POST','/api/turn',self.payload(submission={'move_to':'DEMO-CAMP'}),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertEqual(len(self.calls),0)

    def test_invalid_action_no_model(self):
        status,_=self.request('POST','/api/turn',self.payload(submission={'choice_id':'make_up_choice'}),self.authorized_headers())
        self.assertEqual(status,422)
        self.assertEqual(len(self.calls),0)

    def test_body_size_limit_no_model(self):
        data=self.payload(submission={'free_text':'t'*5000})
        status,_=self.request('POST','/api/turn',data,self.authorized_headers())
        self.assertEqual(status,413)
        self.assertEqual(len(self.calls),0)

    def test_offline_bridge_never_uses_model(self):
        bridge=StoryBridge(self.store,models=[],token=None,sender=lambda *args:self.fail('No GPT'))
        self.assertFalse(bridge.page_state()['connected'])
        with self.assertRaises(WorldError):
            bridge.turn(self.payload())

    def test_static_whitelist_no_file_leak(self):
        for p in ('/', '/app.js', '/style.css', '/assets/forest.jpg'):
            status,_=self.request('GET',p)
            self.assertEqual(status,200,p)
        for p in ('/siwc_client.py','/credentials.json','/../siwc_client.py','/my_demo_save/initial_state.json'):
            status,_=self.request('GET',p)
            self.assertEqual(status,404,p)

    def test_browser_will_never_inject_gpt_html(self):
        js=(WEB/'app.js').read_text('utf-8')
        self.assertIn("$('story-content').textContent=p.text",js)
        self.assertIn("btn.textContent=c.label",js)
        self.assertNotIn('.innerHTML',js)
        self.assertIn("window.confirm",js)
        self.assertIn("currentPage<pages.length-1",js)

    def test_duplicate_request_lock_rejects_before_model(self):
        self.assertTrue(self.bridge.turn_lock.acquire(False))
        try:
            with self.assertRaisesRegex(WorldError,'이미 처리 중'):
                self.bridge.turn(self.payload())
        finally:
            self.bridge.turn_lock.release()
        self.assertEqual(len(self.calls),0)

    def test_server_cannot_bind_all_interfaces(self):
        with self.assertRaises(ValueError):
            LoopbackServer(('0.0.0.0',0),self.bridge)

if __name__=='__main__': unittest.main()
