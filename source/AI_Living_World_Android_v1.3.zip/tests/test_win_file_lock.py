"""Regression tests for the Windows WinError 32 reported by an actual user.
No real token or browser connection required.
"""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).parents[1]))
import siwc_client as sc


class WindowsTempFileLockTests(unittest.TestCase):
    def setUp(self):
        self.ctx = tempfile.TemporaryDirectory()
        self.addCleanup(self.ctx.cleanup)
        self.path = Path(self.ctx.name) / 'private' / 'credentials.json'
        self.creds = {"scopes": [sc.SCOPE_REQUIRED], "access_token": "dummy-access", "refresh_token": "dummy-refresh", "client_id": "oaiapp-test"}

    @staticmethod
    def locked():
        e = PermissionError(13, 'process cannot access the file because it is being used by another process')
        e.winerror = 32
        return e

    def test_intermitten_winerror_32_at_replace_recovers(self):
        real_replace = os.replace
        seen = []
        def flaky(src, dst):
            seen.append((src, dst))
            if len(seen) <= 3:
                raise self.locked()
            return real_replace(src, dst)
        with patch.object(sc.os, 'replace', side_effect=flaky), patch.object(sc.time, 'sleep') as sleeper:
            sc.write_credentials(self.path, self.creds)
        self.assertEqual(len(seen), 4)
        self.assertEqual(sleeper.call_count, 3)
        self.assertEqual(sc.read_credentials(self.path), self.creds)
        self.assertEqual(list(self.path.parent.glob('.siwc-*')), [])

    def test_permanent_winerror_32_never_corrupts_previous_login(self):
        sc.write_credentials(self.path, self.creds)
        with patch.object(sc.os, 'replace', side_effect=self.locked()), patch.object(sc.time, 'sleep'):
            with self.assertRaisesRegex(sc.SIWCError, 'Windows locked') as error:
                sc.write_credentials(self.path, {**self.creds, 'access_token': 'must-not-appear'})
        self.assertEqual(sc.read_credentials(self.path), self.creds)
        self.assertNotIn('must-not-appear', str(error.exception))
        self.assertEqual(list(self.path.parent.glob('.siwc-*')), [])

    def test_non_sharing_error_is_not_infinite_retry(self):
        with patch.object(sc.os, 'replace', side_effect=OSError(28, 'no space')), patch.object(sc.time, 'sleep') as sleeper:
            with self.assertRaises(OSError):
                sc.write_credentials(self.path, self.creds)
        sleeper.assert_not_called()
        self.assertFalse(self.path.exists())
        self.assertEqual(list(self.path.parent.glob('.siwc-*')), [])

if __name__ == '__main__':
    unittest.main()
