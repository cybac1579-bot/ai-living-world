"""Offline preflight for ALW Android build-candidate: no network or secrets.

This does NOT validate Android SDK binary compilation; CI's Gradle step does.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

MODULES = ('ai_adapter', 'autonomy', 'connect_once', 'live_story', 'mobile_embedded',
           'siwc_client', 'sync_bridge', 'vn_server', 'world_engine')
ASSETS = ('web/index.html', 'web/app.js', 'web/style.css',
          'web/assets/forest.jpg', 'examples/live_demo_world.json')


def run(root: Path) -> dict:
    root = root.resolve()
    andir = root/'android_native'
    errors=[]
    def check(condition, reason):
        if not condition: errors.append(reason)
    build=(andir/'app/build.gradle').read_text()
    top=(andir/'build.gradle').read_text()
    settings=(andir/'settings.gradle').read_text()
    check("id 'com.chaquo.python' version '17.2.0'" in top,'Chaquopy version differs')
    check("id 'com.android.application' version '9.5.0'" in top,'Android Gradle plugin differs')
    check("compileSdk 36" in build and "targetSdk 35" in build, 'Android SDK mismatch')
    check("abiFilters 'arm64-v8a'" in build, 'ARM64 target missing')
    check("version = '3.11'" in build, 'Python build version mismatched')
    for dep in ("'PyJWT[crypto]==2.15.1'", "'cryptography==42.0.8'", "'cffi==1.17.1'"):
        check(dep in build, 'Pinned Android dependency missing: '+dep)
    check('mavenCentral()' in settings, 'Maven Central needed for Chaquopy')
    props=(andir/'gradle/wrapper/gradle-wrapper.properties').read_text()
    check('gradle-9.6.0-bin.zip' in props, 'AGP 9.5 requires Gradle 9.6')
    manifest=ET.parse(andir/'app/src/main/AndroidManifest.xml').getroot()
    ns='{http://schemas.android.com/apk/res/android}'
    app=manifest.find('application')
    check(app is not None, 'Android application missing')
    if app is not None:
        check(app.get(ns+'allowBackup') == 'false', 'Android backup not disabled')
        check(app.get(ns+'name') == 'com.chaquo.python.android.PyApplication', 'Chaquopy startup missing')
    network=(andir/'app/src/main/res/xml/network_security_config.xml')
    config=ET.parse(network).getroot()
    domains=[(v.text,v.get('cleartextTrafficPermitted')) for v in config.findall('.//domain-config/domain')]
    check(domains==[('127.0.0.1',None)], 'Unexpected network security host')
    source=andir/'app/src/main/python'
    for module in MODULES:
        local=(root/(module+'.py'))
        bundled=source/(module+'.py')
        check(local.is_file() and bundled.is_file(), 'Missing Python module '+module)
        if local.is_file() and bundled.is_file():
            check(local.read_bytes()==bundled.read_bytes(),'Stale bundled Python '+module)
    for asset in ASSETS:
        bundled=andir/'app/src/main/assets'/asset
        src=(root/asset)
        check(bundled.is_file() and src.is_file(), 'Missing web asset '+asset)
        if src.is_file() and bundled.is_file():
            check(bundled.read_bytes()==src.read_bytes(),'Stale bundled asset '+asset)
    forbidden=('credentials.json','host-id.txt','events.jsonl','secret.env','local.properties','.env')
    for filename in forbidden:
        check(not list(andir.rglob(filename)), 'Sensitive/local build file included: '+filename)
    # Ensure no genuine secret values get packed (source code may mention safe field names).
    result={'ok':not errors,'errors':errors,'android':'1.3 candidate','gradle':'9.6.0','agp':'9.5.0',
            'chaquopy':'17.2.0','python':'3.11','device_abi':'arm64-v8a'}
    return result


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    args=parser.parse_args(argv)
    result=run(args.root)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['ok'] else 1

if __name__=='__main__':
    sys.exit(main())
