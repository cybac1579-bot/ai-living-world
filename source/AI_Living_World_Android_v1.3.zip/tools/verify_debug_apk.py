"""CI artifact sanity-check; a valid ZIP is NOT equivalent to device success."""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile

def inspect_apk(path: Path) -> dict:
    path=path.resolve()
    with ZipFile(path) as z:
        errors=z.testzip()
        names=set(z.namelist())
        if errors:
            raise ValueError('APK archive CRC failure')
        for required in ('AndroidManifest.xml','classes.dex',
                         'assets/web/index.html','assets/web/app.js',
                         'assets/web/style.css','assets/web/assets/forest.jpg'):
            if required not in names:
                raise ValueError('APK asset missing: '+required)
        if not any(n.startswith('lib/arm64-v8a/') and n.endswith('.so') for n in names):
            raise ValueError('Embedded Android ARM64 native runtime missing')
    return {'apk_name':path.name,'size_bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'status':'ZIP CRC / manifest / assets / ARM64 native libs verified; no install test'}

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: verify_debug_apk.py path/to/app-debug.apk')
    print(json.dumps(inspect_apk(Path(sys.argv[1])),indent=2))
